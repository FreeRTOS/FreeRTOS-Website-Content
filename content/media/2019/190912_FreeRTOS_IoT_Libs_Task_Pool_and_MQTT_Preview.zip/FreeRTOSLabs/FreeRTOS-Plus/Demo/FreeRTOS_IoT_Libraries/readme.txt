*** INTRODUCTION ***

This distribution only contains FreeRTOS IoT Library example projects, currently
for the MQTT library and utility libraries used by the MQTT library.

The pre-configured projects projects use the FreeRTOS kernel Windows port (often
called the Windows simulator) to enable their evaluation using the free Visual
Studio tools and without needing specific microcontroller hardware.

NOTE: At this time the projects ARE A WORK IN PROGRESS and will be release in
the main FreeRTOS kernel download following full review and completion of the
documentation.


*** INSTRUCTIONS ***

Instructions for configuring and using the task pool and MQTT libraries are on
the following links respectively:

  + https://www.FreeRTOS.org/task-pool/
  + https://www.FreeRTOS.org/mqtt/index.html


*** LOCATING THE EXAMPLE PROJECTS ***

The Visual Studio projects for the task pool and MQTT libraries are located in
sub-directories of the following directories respectively:

  + /FreeRTOS-Plus/Demo/FreeRTOS_IoT_Libraries/utilities
  + /FreeRTOS-Plus/Demo/FreeRTOS_IoT_Libraries/mqtt


*** ADDITIONAL INFORMATION ***

See http://www.freertos.org/a00017.html for full details of the FreeRTOS
directory structure

See also -
http://www.freertos.org/FreeRTOS-quick-start-guide.html
http://www.freertos.org/FAQHelp.html
