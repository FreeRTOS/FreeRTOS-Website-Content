/*
 * Amazon FreeRTOS Platform V1.0.0
 * Copyright (C) 2019 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * http://aws.amazon.com/freertos
 * http://www.FreeRTOS.org
 */

/**
 * @file iot_network_freertos.c
 * @brief Implementation of the network-related functions from iot_network_freertos.h
 * for FreeRTOS+TCP sockets.
 */

/* The config header is always included first. */
#include "iot_config.h"

/* Standard includes. */
#include <string.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "atomic.h"
#include "semphr.h"

/* FreeRTOS+TCP includes. */
#include "FreeRTOS_IP.h"
#include "FreeRTOS_Sockets.h"

/* FreeRTOS-IoT-Libraries includes. */
#include "private/iot_error.h"
#include "platform/iot_network_freertos.h"
#include "iot_taskpool.h"

#if ( IOT_NETWORK_ENABLE_TLS == 1 )
    /* mbed TLS includes. */
    #include "mbedtls/ctr_drbg.h"
    #include "mbedtls/entropy.h"
    #include "mbedtls/ssl.h"
    #include "mbedtls/threading.h"
    #include "mbedtls/x509.h"
#endif

/* Configure logs for the functions in this file. */
#ifdef IOT_LOG_LEVEL_NETWORK
    #define LIBRARY_LOG_LEVEL        IOT_LOG_LEVEL_NETWORK
#else
    #ifdef IOT_LOG_LEVEL_GLOBAL
        #define LIBRARY_LOG_LEVEL    IOT_LOG_LEVEL_GLOBAL
    #else
        #define LIBRARY_LOG_LEVEL    IOT_LOG_NONE
    #endif
#endif

#define LIBRARY_LOG_NAME    ( "NET" )
#include "iot_logging_setup.h"

/* Provide a default value for socket timeout. */
#ifndef IOT_NETWORK_SOCKET_TIMEOUT_MS
    #define IOT_NETWORK_SOCKET_TIMEOUT_MS    ( 5000 )
#endif

/**
 * @brief The event group bit that flags a socket event job as active.
 */
#define SOCKET_JOB_ACTIVE_BITMASK       ( 1UL )

/**
 * @brief The event group bit that flags a connection as destroyed.
 */
#define CONNECTION_DESTROYED_BITMASK    ( 1UL << 1UL )

/**
 *
 */
#define CONNECTION_SECURED_BITMASK      ( 1UL << 2UL )

/**
 * @brief Maximum length of a DNS name.
 *
 * Per https://tools.ietf.org/html/rfc1035, 253 is the maximum string length
 * of a DNS name.
 */
#define MAX_DNS_NAME_LENGTH             ( 253 )
/*-----------------------------------------------------------*/

/**
 * @brief Internal network context.
 */
typedef struct _networkConnection
{
    uint32_t flags;                              /**< @brief Connection flags. */
    Socket_t socket;                             /**< @brief FreeRTOS+TCP sockets handle. */
    SocketSet_t socketSet;                       /**< @brief Socket set for calls to FreeRTOS_select. */
    SemaphoreHandle_t socketMutex;               /**< @brief Prevents concurrent threads from using a socket. */
    StaticSemaphore_t socketMutexStorage;        /**< @brief Storage space for socketMutex. */
    IotTaskPoolJob_t receiveJob;                 /**< @brief Task pool job for receive callback. */
    IotTaskPoolJobStorage_t receiveJobStorage;   /**< @brief Storage space for receiveJob. */
    IotNetworkReceiveCallback_t receiveCallback; /**< @brief Network receive callback, if any. */
    void * pReceiveContext;                      /**< @brief The context for the receive callback. */

    #if ( IOT_NETWORK_ENABLE_TLS == 1 )
        BaseType_t secured; /**< @brief Flag that marks a connection as secured. */

        /**
         * @brief Secured connection context. Valid if `secured` is `pdTRUE`.
         */
        struct
        {
            mbedtls_ssl_config config;            /**< @brief SSL connection configuration. */
            mbedtls_ssl_context context;          /**< @brief SSL connection context */
            mbedtls_x509_crt_profile certProfile; /**< @brief Certificate security profile for this connection. */
            mbedtls_x509_crt rootCa;              /**< @brief Root CA certificate. */
        } ssl;
    #endif /* if ( IOT_NETWORK_ENABLE_TLS == 1 ) */
} _networkConnection_t;
/*-----------------------------------------------------------*/

#if ( IOT_NETWORK_ENABLE_TLS == 1 )

/**
 * @brief mbed TLS entropy context for generation of random numbers.
 */
    static mbedtls_entropy_context _entropyContext;

/**
 * @brief mbed TLS CTR DRBG context for generation of random numbers.
 */
    static mbedtls_ctr_drbg_context _ctrDrgbContext;
#endif

/**
 * @brief An #IotNetworkInterface_t that uses the functions in this file.
 */
const IotNetworkInterface_t IotNetworkFreeRTOS =
{
    .create             = IotNetworkFreeRTOS_Create,
    .setReceiveCallback = IotNetworkFreeRTOS_SetReceiveCallback,
    .send               = IotNetworkFreeRTOS_Send,
    .receive            = IotNetworkFreeRTOS_Receive,
    .close              = IotNetworkFreeRTOS_Close,
    .destroy            = IotNetworkFreeRTOS_Destroy
};
/*-----------------------------------------------------------*/

#if ( IOT_NETWORK_ENABLE_TLS == 1 )

/**
 * @brief Initialize the mbed TLS structures in a network connection.
 *
 * @param[in] pNetworkConnection The network connection to initialize.
 */
    static void _sslContextInit( _networkConnection_t * pNetworkConnection )
    {
        mbedtls_ssl_config_init( &( pNetworkConnection->ssl.config ) );
        mbedtls_x509_crt_init( &( pNetworkConnection->ssl.rootCa ) );
        mbedtls_ssl_init( &( pNetworkConnection->ssl.context ) );
    }
/*-----------------------------------------------------------*/

/**
 * @brief Free the mbed TLS structures in a network connection.
 *
 * @param[in] pNetworkConnection The network connection with the contexts to free.
 */
    static void _sslContextFree( _networkConnection_t * pNetworkConnection )
    {
        mbedtls_ssl_free( &( pNetworkConnection->ssl.context ) );
        mbedtls_x509_crt_free( &( pNetworkConnection->ssl.rootCa ) );
        mbedtls_ssl_config_free( &( pNetworkConnection->ssl.config ) );
    }
/*-----------------------------------------------------------*/

/**
 * @brief Set up TLS on a TCP connection.
 *
 * @param[in] pNetworkConnection An established TCP connection.
 * @param[in] pServerName Remote host name, used for server name indication.
 * @param[in] pMbedtlsCredentials TLS setup parameters.
 *
 * @return #IOT_NETWORK_SUCCESS, #IOT_NETWORK_FAILURE, #IOT_NETWORK_NO_MEMORY,
 * or #IOT_NETWORK_SYSTEM_ERROR.
 */
    static IotNetworkError_t _tlsSetup( _networkConnection_t * pNetworkConnection,
                                        const char * pServerName,
                                        const IotNetworkCredentials_t * pCredentials )
    {
        IOT_FUNCTION_ENTRY( IotNetworkError_t, IOT_NETWORK_SUCCESS );
        int mbedtlsError = 0;

        /* This simple example does not use a client certificate or any TLS extensions.
         * Ensure that those parameters are not set. */
        configASSERT( pCredentials->pClientCert == NULL );
        configASSERT( pCredentials->clientCertSize == 0 );
        configASSERT( pCredentials->pPrivateKey == NULL );
        configASSERT( pCredentials->privateKeySize == 0 );
        configASSERT( pCredentials->maxFragmentLength == 0 );
        configASSERT( pCredentials->pAlpnProtos == NULL );

        /* Initialize the mbed TLS context structures. */
        _sslContextInit( pNetworkConnection );

        mbedtlsError = mbedtls_ssl_config_defaults( &( pNetworkConnection->ssl.config ),
                                                    MBEDTLS_SSL_IS_CLIENT,
                                                    MBEDTLS_SSL_TRANSPORT_STREAM,
                                                    MBEDTLS_SSL_PRESET_DEFAULT );

        if( mbedtlsError != 0 )
        {
            IotLogError( "Failed to set default SSL configuration, error %d.", mbedtlsError );

            /* Per mbed TLS docs, mbedtls_ssl_config_defaults only fails on memory allocation. */
            IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_NO_MEMORY );
        }

        /* Set up the certificate security profile, starting from the default value. */
        pNetworkConnection->ssl.certProfile = mbedtls_x509_crt_profile_default;

        /* test.mosquitto.org only provides a 1024-bit RSA certificate, which is
         * not acceptable by the default mbed TLS certificate security profile.
         * For the purposes of this demo, allow the use of 1024-bit RSA certificates.
         * This block should be removed otherwise. */
        if( strncmp( pServerName, "test.mosquitto.org", strlen( pServerName ) ) == 0 )
        {
            pNetworkConnection->ssl.certProfile.rsa_min_bitlen = 1024;
        }

        /* Set SSL authmode and the RNG context. */
        mbedtls_ssl_conf_authmode( &( pNetworkConnection->ssl.config ),
                                   MBEDTLS_SSL_VERIFY_REQUIRED );
        mbedtls_ssl_conf_rng( &( pNetworkConnection->ssl.config ),
                              mbedtls_ctr_drbg_random,
                              &_ctrDrgbContext );
        mbedtls_ssl_conf_cert_profile( &( pNetworkConnection->ssl.config ),
                                       &( pNetworkConnection->ssl.certProfile ) );

        /* Parse the server root CA certificate into the SSL context. */
        mbedtlsError = mbedtls_x509_crt_parse( &( pNetworkConnection->ssl.rootCa ),
                                               ( const unsigned char * ) pCredentials->pRootCa,
                                               pCredentials->rootCaSize );

        if( mbedtlsError != 0 )
        {
            IotLogError( "Failed to parse server root CA certificate, error %d.",
                         mbedtlsError );

            IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_SYSTEM_ERROR );
        }

        mbedtls_ssl_conf_ca_chain( &( pNetworkConnection->ssl.config ),
                                   &( pNetworkConnection->ssl.rootCa ),
                                   NULL );

        /* Initialize the mbed TLS secured connection context. */
        mbedtlsError = mbedtls_ssl_setup( &( pNetworkConnection->ssl.context ),
                                          &( pNetworkConnection->ssl.config ) );

        if( mbedtlsError != 0 )
        {
            IotLogError( "Failed to set up mbed TLS SSL context, error %d.",
                         mbedtlsError );

            IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_SYSTEM_ERROR );
        }

        /* Set the underlying IO for the TLS connection. */
        mbedtls_ssl_set_bio( &( pNetworkConnection->ssl.context ),
                             pNetworkConnection->socket,
                             mbedtls_platform_send,
                             mbedtls_platform_recv,
                             NULL );

        /* Enable SNI if requested. */
        if( pCredentials->disableSni == false )
        {
            mbedtlsError = mbedtls_ssl_set_hostname( &( pNetworkConnection->ssl.context ),
                                                     pServerName );

            if( mbedtlsError != 0 )
            {
                IotLogError( "Failed to set server name, error %d.", mbedtlsError );

                IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_SYSTEM_ERROR );
            }
        }

        /* Perform the TLS handshake. */
        do
        {
            mbedtlsError = mbedtls_ssl_handshake( &( pNetworkConnection->ssl.context ) );
        } while( ( mbedtlsError == MBEDTLS_ERR_SSL_WANT_READ ) ||
                 ( mbedtlsError == MBEDTLS_ERR_SSL_WANT_WRITE ) );

        if( mbedtlsError != 0 )
        {
            IotLogError( "Failed to perform TLS handshake, error %d.", mbedtlsError );

            IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_FAILURE );
        }

        /* Clean up on error. */
        IOT_FUNCTION_CLEANUP_BEGIN();

        if( status != IOT_NETWORK_SUCCESS )
        {
            _sslContextFree( pNetworkConnection );
        }
        else
        {
            pNetworkConnection->secured = pdTRUE;

            IotLogInfo( "(Network connection %p) TLS handshake successful.",
                        pNetworkConnection );
        }

        IOT_FUNCTION_CLEANUP_END();
    }
#endif /* if ( IOT_NETWORK_ENABLE_TLS == 1 ) */
/*-----------------------------------------------------------*/

/**
 * @brief Task pool job that handles network events, such as incoming data or
 * connection destruction.
 *
 * @param[in] pTaskPool Ignored.
 * @param[in] pJob Ignored.
 * @param[in] pContext Pointer to the network connection context.
 */
static void _socketEventJob( IotTaskPool_t pTaskPool,
                             IotTaskPoolJob_t pJob,
                             void * pContext )
{
    BaseType_t socketStatus = 0;
    uint32_t connectionFlags = 0;

    /* Silence warnings about unused parameters. */
    ( void ) pTaskPool;
    ( void ) pJob;

    /* Cast context to the correct type. */
    _networkConnection_t * pNetworkConnection = ( _networkConnection_t * ) pContext;

    /* Check if the connection is destroyed. Perform cleanup if it is. */
    connectionFlags = Atomic_OR_u32( &( pNetworkConnection->flags ), 0 );

    if( ( connectionFlags & CONNECTION_DESTROYED_BITMASK ) != 0 )
    {
        /* Close socket and delete the socket set for FreeRTOS_select. */
        FreeRTOS_closesocket( pNetworkConnection->socket );
        FreeRTOS_DeleteSocketSet( pNetworkConnection->socketSet );

        #if ( IOT_NETWORK_ENABLE_TLS == 1 )
            /* Free mbed TLS contexts. */
            if( pNetworkConnection->secured == pdTRUE )
            {
                _sslContextFree( pNetworkConnection );
            }
        #endif

        /* Free memory used by network connection. */
        vPortFree( pNetworkConnection );

        IotLogInfo( "(Network connection %p) Connection destroyed.",
                    pNetworkConnection );
    }
    else
    {
        /* Loop on select to process all immediately available events. */
        for( ; ; )
        {
            socketStatus = FreeRTOS_select( pNetworkConnection->socketSet, 0 );

            /* Stop if no more events are available. */
            if( socketStatus == 0 )
            {
                break;
            }

            /* Check the socket event. At least one event bit must be set. */
            socketStatus = FreeRTOS_FD_ISSET( pNetworkConnection->socket,
                                              pNetworkConnection->socketSet );
            configASSERT( socketStatus != 0 );

            if( ( socketStatus & eSELECT_READ ) != 0 )
            {
                /* A receive callback must be set; otherwise, this job should not have
                 * been invoked. */
                configASSERT( pNetworkConnection->receiveCallback != NULL );

                pNetworkConnection->receiveCallback( pNetworkConnection,
                                                     pNetworkConnection->pReceiveContext );
            }
        }

        /* Mark the socket event job as finished. */
        ( void ) Atomic_AND_u32( &( pNetworkConnection->flags ), ~SOCKET_JOB_ACTIVE_BITMASK );
    }

    IotLogDebug( "(Network connection %p) Socket event job exiting.",
                 pNetworkConnection );
}
/*-----------------------------------------------------------*/

/**
 * @brief Socket wake callback, invoked by the network stack on an important
 * socket event.
 *
 * @param[in] socket The associated socket.
 * @param[in] pContext Pointer to the network connection context.
 */
static void _socketWakeCallback( Socket_t socket,
                                 void * pContext )
{
    uint32_t connectionFlags = 0;
    IotTaskPoolError_t taskPoolStatus = IOT_TASKPOOL_SUCCESS;

    /* The socket parameter is not used. */
    ( void ) socket;

    /* Cast context to the correct type. */
    _networkConnection_t * pNetworkConnection = ( _networkConnection_t * ) pContext;

    /* Read the current event bits of the connection. */
    connectionFlags = Atomic_OR_u32( &( pNetworkConnection->flags ), 0 );

    /* This callback must not modify the connection if the socket event job is
     * using it. If the socket event job is currently active, do nothing and
     * defer event handling to the next run of the socket wake callback. */
    if( ( connectionFlags & SOCKET_JOB_ACTIVE_BITMASK ) == 0 )
    {
        ( void ) Atomic_OR_u32( &( pNetworkConnection->flags ), SOCKET_JOB_ACTIVE_BITMASK );

        /* Create the task pool job to invoke the receive callback. This should never
         * fail when job storage is provided. */
        taskPoolStatus = IotTaskPool_CreateJob( _socketEventJob,
                                                pNetworkConnection,
                                                &( pNetworkConnection->receiveJobStorage ),
                                                &( pNetworkConnection->receiveJob ) );
        configASSERT( taskPoolStatus == IOT_TASKPOOL_SUCCESS );

        /* Schedule the task pool job to invoke the receive callback. This should never
         * fail with valid parameters. */
        taskPoolStatus = IotTaskPool_Schedule( IOT_SYSTEM_TASKPOOL,
                                               pNetworkConnection->receiveJob,
                                               0 );
        configASSERT( taskPoolStatus == IOT_TASKPOOL_SUCCESS );

        IotLogDebug( "(Network connection %p) Socket event job scheduled.",
                     pNetworkConnection );
    }
    else
    {
        IotLogDebug( "(Network connection %p) Socket event job currently active. "
                     "Deferring event to next run of socket wake callback.",
                     pNetworkConnection );
    }
}
/*-----------------------------------------------------------*/

IotNetworkError_t IotNetworkFreeRTOS_Init( void )
{
    #if ( IOT_NETWORK_ENABLE_TLS == 1 )
        IOT_FUNCTION_ENTRY( IotNetworkError_t, IOT_NETWORK_SUCCESS );
        int mbedtlsError = 0;

        /* Set the mutex functions for mbed TLS thread safety. */
        mbedtls_threading_set_alt( mbedtls_platform_mutex_init,
                                   mbedtls_platform_mutex_free,
                                   mbedtls_platform_mutex_lock,
                                   mbedtls_platform_mutex_unlock );

        /* Initialize contexts for random number generation. */
        mbedtls_entropy_init( &_entropyContext );
        mbedtls_ctr_drbg_init( &_ctrDrgbContext );

        /* Add a strong entropy source. At least one is required. */
        mbedtlsError = mbedtls_entropy_add_source( &_entropyContext,
                                                   mbedtls_platform_entropy_poll,
                                                   NULL,
                                                   32,
                                                   MBEDTLS_ENTROPY_SOURCE_STRONG );

        if( mbedtlsError != 0 )
        {
            IotLogError( "Failed to add entropy source, error %d.", mbedtlsError );

            IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_FAILURE );
        }

        /* Seed the random number generator. */
        mbedtlsError = mbedtls_ctr_drbg_seed( &_ctrDrgbContext,
                                              mbedtls_entropy_func,
                                              &_entropyContext,
                                              NULL,
                                              0 );

        if( mbedtlsError != 0 )
        {
            IotLogError( "Failed to seed PRNG, error %d.", mbedtlsError );

            IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_FAILURE );
        }

        IotLogInfo( "Network successfully initialized." );

        IOT_FUNCTION_EXIT_NO_CLEANUP();
    #else /* if ( IOT_NETWORK_ENABLE_TLS == 1 ) */
        /* No initialization needed if TLS is not used. */
        return IOT_NETWORK_SUCCESS;
    #endif /* if ( IOT_NETWORK_ENABLE_TLS == 1 ) */
}
/*-----------------------------------------------------------*/

void IotNetworkFreeRTOS_Cleanup( void )
{
    #if ( IOT_NETWORK_ENABLE_TLS == 1 )
        /* Free the contexts for random number generation. */
        mbedtls_ctr_drbg_free( &_ctrDrgbContext );
        mbedtls_entropy_free( &_entropyContext );

        /* Clear the mutex functions for mbed TLS thread safety. */
        mbedtls_threading_free_alt();
    #endif

    IotLogInfo( "Network cleanup done." );
}
/*-----------------------------------------------------------*/

IotNetworkError_t IotNetworkFreeRTOS_Create( void * pConnectionInfo,
                                             void * pCredentialInfo,
                                             void ** pConnection )
{
    IOT_FUNCTION_ENTRY( IotNetworkError_t, IOT_NETWORK_SUCCESS );
    Socket_t tcpSocket = FREERTOS_INVALID_SOCKET;
    BaseType_t socketStatus = 0;
    struct freertos_sockaddr serverAddress = { 0 };
    const TickType_t receiveTimeout = pdMS_TO_TICKS( IOT_NETWORK_SOCKET_TIMEOUT_MS );
    _networkConnection_t * pNewNetworkConnection = NULL;

    /* Cast function parameters to correct types. */
    const IotNetworkServerInfo_t * pServerInfo = pConnectionInfo;
    const IotNetworkCredentials_t * pCredentials = pCredentialInfo;
    _networkConnection_t ** pNetworkConnection = ( _networkConnection_t ** ) pConnection;

    /* Credentials are not used if TLS is disabled. */
    ( void ) pCredentials;

    /* Check host name length against the maximum length allowed. */
    const size_t hostnameLength = strlen( pServerInfo->pHostName );

    if( hostnameLength > ( size_t ) MAX_DNS_NAME_LENGTH )
    {
        IotLogError( "Host name length exceeds %d, which is the maximum allowed.",
                     MAX_DNS_NAME_LENGTH );
        IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_BAD_PARAMETER );
    }

    pNewNetworkConnection = pvPortMalloc( sizeof( _networkConnection_t ) );

    if( pNewNetworkConnection == NULL )
    {
        IotLogError( "Failed to allocate memory for new network connection." );
        IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_NO_MEMORY );
    }

    /* Clear the connection information. */
    ( void ) memset( pNewNetworkConnection, 0x00, sizeof( _networkConnection_t ) );

    /* Create a new TCP socket. */
    tcpSocket = FreeRTOS_socket( FREERTOS_AF_INET,
                                 FREERTOS_SOCK_STREAM,
                                 FREERTOS_IPPROTO_TCP );

    if( tcpSocket == FREERTOS_INVALID_SOCKET )
    {
        IotLogError( "Failed to create new socket." );
        IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_SYSTEM_ERROR );
    }

    /* Set the timeout for receive. */
    socketStatus = FreeRTOS_setsockopt( tcpSocket,
                                        0,
                                        FREERTOS_SO_RCVTIMEO,
                                        &receiveTimeout,
                                        sizeof( TickType_t ) );

    if( socketStatus != 0 )
    {
        IotLogError( "Failed to set socket receive timeout." );
        IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_SYSTEM_ERROR );
    }

    /* Establish connection. */
    serverAddress.sin_family = FREERTOS_AF_INET;
    serverAddress.sin_port = FreeRTOS_htons( pServerInfo->port );
    serverAddress.sin_addr = FreeRTOS_gethostbyname( pServerInfo->pHostName );
    serverAddress.sin_len = ( uint8_t ) sizeof( serverAddress );

    /* Check for errors from DNS lookup. */
    if( serverAddress.sin_addr == 0 )
    {
        IotLogError( "Failed to resolve %s.", pServerInfo->pHostName );
        IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_SYSTEM_ERROR );
    }

    socketStatus = FreeRTOS_connect( tcpSocket,
                                     &serverAddress,
                                     sizeof( serverAddress ) );

    if( socketStatus != 0 )
    {
        IotLogError( "Failed to establish new connection." );
        IOT_SET_AND_GOTO_CLEANUP( IOT_NETWORK_SYSTEM_ERROR );
    }

    /* Set the socket. */
    pNewNetworkConnection->socket = tcpSocket;

    #if ( IOT_NETWORK_ENABLE_TLS == 1 )
        /* Set up TLS if credentials are provided. */
        if( pCredentials != NULL )
        {
            status = _tlsSetup( pNewNetworkConnection,
                                pServerInfo->pHostName,
                                pCredentials );
        }
    #endif

    IOT_FUNCTION_CLEANUP_BEGIN();

    /* Clean up on failure. */
    if( status != IOT_NETWORK_SUCCESS )
    {
        if( tcpSocket != FREERTOS_INVALID_SOCKET )
        {
            FreeRTOS_closesocket( tcpSocket );
        }

        /* Clear the connection information. */
        if( pNewNetworkConnection != NULL )
        {
            vPortFree( pNewNetworkConnection );
        }
    }
    else
    {
        /* Create the socket mutex. */
        pNewNetworkConnection->socketMutex = xSemaphoreCreateMutexStatic( &( pNewNetworkConnection->socketMutexStorage ) );

        /* Set the output parameter. */
        *pNetworkConnection = pNewNetworkConnection;

        IotLogInfo( "(Network connection %p) Connection to %s established.",
                    pNewNetworkConnection,
                    pServerInfo->pHostName );
    }

    IOT_FUNCTION_CLEANUP_END();
}
/*-----------------------------------------------------------*/

IotNetworkError_t IotNetworkFreeRTOS_SetReceiveCallback( void * pConnection,
                                                         IotNetworkReceiveCallback_t receiveCallback,
                                                         void * pContext )
{
    IotNetworkError_t status = IOT_NETWORK_SUCCESS;
    BaseType_t socketStatus = 0;

    /* Cast network connection to the correct type. */
    _networkConnection_t * pNetworkConnection = ( _networkConnection_t * ) pConnection;

    /* Set the receive callback and context. */
    pNetworkConnection->receiveCallback = receiveCallback;
    pNetworkConnection->pReceiveContext = pContext;

    /* Create the socket set to use with FreeRTOS_select. */
    pNetworkConnection->socketSet = FreeRTOS_CreateSocketSet();

    if( pNetworkConnection->socketSet != NULL )
    {
        /* Select should return for read and disconnect events. */
        FreeRTOS_FD_SET( pNetworkConnection->socket,
                         pNetworkConnection->socketSet,
                         eSELECT_READ | eSELECT_EXCEPT );

        /* Set the socket wake callback and context. This should never fail. */
        socketStatus = FreeRTOS_setsockopt( pNetworkConnection->socket,
                                            0,
                                            FREERTOS_SO_WAKEUP_CALLBACK,
                                            ( void * ) _socketWakeCallback,
                                            0 );
        configASSERT( socketStatus == 0 );

        socketStatus = FreeRTOS_setsockopt( pNetworkConnection->socket,
                                            0,
                                            FREERTOS_SO_WAKE_CALLBACK_CONTEXT,
                                            pNetworkConnection,
                                            0 );
        configASSERT( socketStatus == 0 );
    }
    else
    {
        /* No memory for socket set. */
        status = IOT_NETWORK_NO_MEMORY;

        IotLogError( "(Network connection %p) No memory for receive callback.",
                     pNetworkConnection );
    }

    return status;
}
/*-----------------------------------------------------------*/

size_t IotNetworkFreeRTOS_Send( void * pConnection,
                                const uint8_t * pMessage,
                                size_t messageLength )
{
    size_t bytesSent = 0;
    BaseType_t socketStatus = 0;

    /* Cast network connection to the correct type. */
    _networkConnection_t * pNetworkConnection = ( _networkConnection_t * ) pConnection;

    /* Only one thread at a time may send on the connection. Lock the send
     * mutex to prevent other threads from sending. */
    if( xSemaphoreTake( pNetworkConnection->socketMutex,
                        IOT_NETWORK_SOCKET_TIMEOUT_MS ) == pdTRUE )
    {
        #if ( IOT_NETWORK_ENABLE_TLS == 1 )
            if( pNetworkConnection->secured == pdTRUE )
            {
                while( bytesSent < messageLength )
                {
                    socketStatus = ( BaseType_t ) mbedtls_ssl_write( &( pNetworkConnection->ssl.context ),
                                                                     pMessage + bytesSent,
                                                                     messageLength - bytesSent );

                    if( ( socketStatus == ( BaseType_t ) MBEDTLS_ERR_SSL_WANT_WRITE ) ||
                        ( socketStatus == ( BaseType_t ) MBEDTLS_ERR_SSL_WANT_READ ) )
                    {
                        /* Try again for WANT_WRITE and WANT_READ errors. */
                        continue;
                    }
                    else if( socketStatus < 0 )
                    {
                        /* Exit on other errors. */
                        break;
                    }
                    else
                    {
                        bytesSent += ( size_t ) socketStatus;
                        configASSERT( bytesSent <= messageLength );
                    }
                }
            }
            else
        #endif /* if ( IOT_NETWORK_ENABLE_TLS == 1 ) */
        {
            socketStatus = FreeRTOS_send( pNetworkConnection->socket,
                                          pMessage,
                                          messageLength,
                                          0 );
        }

        if( socketStatus > 0 )
        {
            bytesSent = ( size_t ) socketStatus;
        }

        xSemaphoreGive( pNetworkConnection->socketMutex );
    }

    IotLogDebug( "(Network connection %p) Sent %lu bytes.",
                 pNetworkConnection,
                 ( unsigned long ) bytesSent );

    return bytesSent;
}
/*-----------------------------------------------------------*/

size_t IotNetworkFreeRTOS_Receive( void * pConnection,
                                   uint8_t * pBuffer,
                                   size_t bytesRequested )
{
    BaseType_t socketStatus = 0;
    size_t bytesReceived = 0, bytesRemaining = bytesRequested;

    /* Cast network connection to the correct type. */
    _networkConnection_t * pNetworkConnection = ( _networkConnection_t * ) pConnection;

    /* Block and wait for incoming data. */
    while( bytesRemaining > 0 )
    {
        #if ( IOT_NETWORK_ENABLE_TLS == 1 )
            if( pNetworkConnection->secured == pdTRUE )
            {
                if( xSemaphoreTake( pNetworkConnection->socketMutex,
                                    IOT_NETWORK_SOCKET_TIMEOUT_MS ) == pdTRUE )
                {
                    socketStatus = ( BaseType_t ) mbedtls_ssl_read( &( pNetworkConnection->ssl.context ),
                                                                    pBuffer + bytesReceived,
                                                                    bytesRequested - bytesReceived );

                    xSemaphoreGive( pNetworkConnection->socketMutex );

                    if( ( socketStatus == ( BaseType_t ) MBEDTLS_ERR_SSL_WANT_READ ) ||
                        ( socketStatus == ( BaseType_t ) MBEDTLS_ERR_SSL_WANT_WRITE ) )
                    {
                        /* Try again for WANT_WRITE and WANT_READ errors. */
                        continue;
                    }
                }
                else
                {
                    /* Could not obtain socket mutex, exit. */
                    break;
                }
            }
            else
        #endif /* if ( IOT_NETWORK_ENABLE_TLS == 1 ) */
        {
            socketStatus = FreeRTOS_recv( pNetworkConnection->socket,
                                          pBuffer + bytesReceived,
                                          bytesRemaining,
                                          0 );

            if( socketStatus == FREERTOS_EWOULDBLOCK )
            {
                /* The return value EWOULDBLOCK means no data was received within
                 * the socket timeout. Ignore it and try again. */
                continue;
            }
        }

        if( socketStatus < 0 )
        {
            IotLogError( "Error %ld while receiving data.", ( long int ) socketStatus );
            break;
        }
        else
        {
            bytesReceived += ( size_t ) socketStatus;
            bytesRemaining -= ( size_t ) socketStatus;

            configASSERT( bytesReceived + bytesRemaining == bytesRequested );
        }
    }

    if( bytesReceived < bytesRequested )
    {
        IotLogWarn( "(Network connection %p) Receive requested %lu bytes, but %lu bytes received instead.",
                    pNetworkConnection,
                    ( unsigned long ) bytesRequested,
                    ( unsigned long ) bytesReceived );
    }
    else
    {
        IotLogDebug( "(Network connection %p) Successfully received %lu bytes.",
                     pNetworkConnection,
                     ( unsigned long ) bytesRequested );
    }

    return bytesReceived;
}
/*-----------------------------------------------------------*/

IotNetworkError_t IotNetworkFreeRTOS_Close( void * pConnection )
{
    BaseType_t socketStatus = 0;

    /* Cast network connection to the correct type. */
    _networkConnection_t * pNetworkConnection = ( _networkConnection_t * ) pConnection;

    #if ( IOT_NETWORK_ENABLE_TLS == 1 )
        /* Notify the peer that the TLS connection is being closed. */
        if( pNetworkConnection->secured == pdTRUE )
        {
            if( xSemaphoreTake( pNetworkConnection->socketMutex,
                                IOT_NETWORK_SOCKET_TIMEOUT_MS ) == pdTRUE )
            {
                socketStatus = ( BaseType_t ) mbedtls_ssl_close_notify( &( pNetworkConnection->ssl.context ) );

                /* Ignore the WANT_READ and WANT_WRITE return values. */
                if( ( socketStatus != ( BaseType_t ) MBEDTLS_ERR_SSL_WANT_READ ) &&
                    ( socketStatus != ( BaseType_t ) MBEDTLS_ERR_SSL_WANT_WRITE ) )
                {
                    if( socketStatus == 0 )
                    {
                        IotLogInfo( "(Network connection %p) TLS close-notify sent.",
                                    pNetworkConnection );
                    }
                    else
                    {
                        IotLogWarn( "(Network connection %p) Failed to send TLS close-notify, error %d.",
                                    pNetworkConnection,
                                    socketStatus );
                    }
                }

                xSemaphoreGive( pNetworkConnection->socketMutex );
            }
        }
    #endif /* if ( IOT_NETWORK_ENABLE_TLS == 1 ) */

    /* Call socket shutdown function to close connection. */
    socketStatus = FreeRTOS_shutdown( pNetworkConnection->socket,
                                      FREERTOS_SHUT_RDWR );

    if( socketStatus != 0 )
    {
        IotLogWarn( "(Network connection %p) Failed to close connection.",
                    pNetworkConnection );
    }
    else
    {
        IotLogInfo( "(Network connection %p) Connection closed.",
                    pNetworkConnection );
    }

    return IOT_NETWORK_SUCCESS;
}
/*-----------------------------------------------------------*/

IotNetworkError_t IotNetworkFreeRTOS_Destroy( void * pConnection )
{
    /* Cast network connection to the correct type. */
    _networkConnection_t * pNetworkConnection = ( _networkConnection_t * ) pConnection;

    /* Flag the connection as destroyed. */
    ( void ) Atomic_OR_u32( &( pNetworkConnection->flags ), CONNECTION_DESTROYED_BITMASK );

    return IOT_NETWORK_SUCCESS;
}
/*-----------------------------------------------------------*/
