;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:47 2004
;--------------------------------------------------------
	.module ceilf
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ceilf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ceilf'
;------------------------------------------------------------
;x                         Allocated to stack - offset 1
;r                         Allocated to stack - offset 5
;sloc0                     Allocated to stack - offset 9
;------------------------------------------------------------
;ceilf.c:23: float ceilf(float x) reentrant
;	-----------------------------------------
;	 function ceilf
;	-----------------------------------------
_ceilf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x0c
	mov	sp,a
;ceilf.c:26: r=x;
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fs2slong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;ceilf.c:27: if (r<0)
;     genCmpLt
	mov	a,_bp
	add	a,#0x05
;     genCmp
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00102$
00110$:
;ceilf.c:28: return r;
;     genCall
	dec	r0
	dec	r0
	dec	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___slong2fs
	push	acc
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
;     genRet
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	ljmp	00104$
00102$:
;ceilf.c:30: return (r+((r<x)?1:0));
;     genIpush
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___slong2fs
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
;     genIpush
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r2
	mov	a,r3
	lcall	___fslt
	mov	r2,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIfx
	mov	a,r2
;     genIpop
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00111$:
;     genAssign
	mov	r4,#0x01
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00107$
00106$:
;     genAssign
	mov	r4,#0x00
00107$:
;     genCast
	mov	r5,#0x00
;     genCast
	mov	a,r5
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genPlus
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
	add	a,@r0
	mov	r4,a
;       Peephole 236.g  used r5 instead of ar5
	mov     a,r5
	inc	r0
	addc	a,@r0
	mov	r5,a
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	inc	r0
	addc	a,@r0
	mov	r2,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	inc	r0
	addc	a,@r0
;     genCall
;       Peephole 191    removed redundant mov
	mov     r3,a
	mov     dpl,r4
	mov     dph,r5
	mov     b,r2
	lcall	___slong2fs
;     genRet
;       Peephole 191    removed redundant mov
	mov     r2,dpl
	mov     r3,dph
	mov     r4,b
	mov     r5,a
;       Peephole 238.b  removed 3 redundant moves
00104$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
