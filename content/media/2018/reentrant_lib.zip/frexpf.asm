;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:49 2004
;--------------------------------------------------------
	.module frexpf
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _frexpf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'frexpf'
;------------------------------------------------------------
;pw2                       Allocated to stack - offset -5
;x                         Allocated to stack - offset 1
;fl                        Allocated to stack - offset 5
;i                         Allocated to stack - offset 9
;------------------------------------------------------------
;frexpf.c:24: float frexpf(const float x, int *pw2)
;	-----------------------------------------
;	 function frexpf
;	-----------------------------------------
_frexpf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x0c
	mov	sp,a
;frexpf.c:29: fl.f=x;
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerSet
;     genNearPointerSet
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	dec	r0
	dec	r0
	dec	r0
;frexpf.c:31: i  = ( fl.l >> 23) & 0x000000ff;
;     genRightShift
;     genSignedRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x01
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r1,a
	mov	ar6,@r1
	inc	r1
	mov	a,@r1
	mov	c,acc.7
	xch	a,r6
	rlc	a
	xch	a,r6
	rlc	a
	xch	a,r6
	anl	a,#0x01
	jnb	acc.0,00103$
	orl	a,#0xfe
00103$:
	mov	r7,a
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genAnd
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	@r1,ar6
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
;frexpf.c:32: i -= 0x7e;
;     genMinus
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	a,@r1
	add	a,#0x82
	mov	@r1,a
	inc	r1
	mov	a,@r1
	addc	a,#0xff
	mov	@r1,a
	inc	r1
	mov	a,@r1
	addc	a,#0xff
	mov	@r1,a
	inc	r1
	mov	a,@r1
	addc	a,#0xff
	mov	@r1,a
;frexpf.c:33: *pw2 = i;
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r1,a
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
	inc	r1
	mov	ar2,@r1
;     genCast
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	ar6,@r1
	inc	r1
	mov	ar7,@r1
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r2
	mov	a,r6
	lcall	__gptrput
	inc	dptr
	mov	a,r7
	lcall	__gptrput
;frexpf.c:34: fl.l &= 0x807fffff; /* strip all exponent bits */
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
	inc	r1
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
;     genAnd
	anl	ar4,#0x7F
	anl	ar5,#0x80
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	dec	r0
	dec	r0
	dec	r0
;frexpf.c:35: fl.l |= 0x3f000000; /* mantissa between 0.5 and 1 */
;     genOr
	orl	ar5,#0x3F
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;frexpf.c:36: return(fl.f);
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00101$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
