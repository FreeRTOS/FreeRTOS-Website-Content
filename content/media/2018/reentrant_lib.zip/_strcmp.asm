;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:44 2004
;--------------------------------------------------------
	.module _strcmp
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strcmp
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strcmp'
;------------------------------------------------------------
;adst                      Allocated to stack - offset -5
;asrc                      Allocated to registers r2 r3 r4 
;ret                       Allocated to stack - offset 4
;sloc0                     Allocated to stack - offset 1
;sloc1                     Allocated to stack - offset 4
;------------------------------------------------------------
;_strcmp.c:29: int strcmp (
;	-----------------------------------------
;	 function strcmp
;	-----------------------------------------
_strcmp:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
	mov	a,sp
	add	a,#0x05
	mov	sp,a
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;_strcmp.c:48: while( ! (ret = *asrc - *adst) && *adst)
;     genAssign
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00102$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;     genCast
;       Peephole 105    removed redundant mov
	mov     r5,a
	rlc	a
	subb	a,acc
	mov	r6,a
;     genPointerGet
;     genGenPointerGet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
	mov	r7,a
;     genIpush
	push	ar2
	push	ar3
	push	ar4
;     genCast
	mov	ar2,r7
	mov	a,r7
	rlc	a
	subb	a,acc
	mov	r3,a
;     genMinus
	mov	a,r5
	clr	c
;       Peephole 236.l  used r2 instead of ar2
	subb    a,r2
	mov	r5,a
	mov	a,r6
;       Peephole 236.l  used r3 instead of ar3
	subb    a,r3
	mov	r6,a
;     genAssign
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar6
;     genIpop
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r5
	orl	a,r6
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00104$
00117$:
;     genIfx
	mov	a,r7
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00104$
00118$:
;_strcmp.c:49: ++asrc, ++adst;
;     genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00119$
	inc	r3
00119$:
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00102$
00104$:
;_strcmp.c:51: if ( ret < 0 )
;     genCmpLt
	mov	a,_bp
	add	a,#0x04
;     genCmp
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00108$
00120$:
;_strcmp.c:52: ret = -1 ;
;     genAssign
	dec	r0
	mov	@r0,#0xFF
	inc	r0
	mov	@r0,#0xFF
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00109$
00108$:
;_strcmp.c:53: else if ( ret > 0 )
;     genCmpGt
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;     genCmp
	clr	c
;       Peephole 181    changed mov to clr
	clr     a
	subb	a,@r0
;       Peephole 159    avoided xrl during execution
	mov  a,#(0x00 ^ 0x80)
	inc	r0
	mov	b,@r0
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00109$
00121$:
;_strcmp.c:54: ret = 1 ;
;     genAssign
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	clr	a
	inc	r0
	mov	@r0,a
	dec	r0
	mov	@r0,#0x01
00109$:
;_strcmp.c:56: return( ret );
;     genRet
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
00110$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
