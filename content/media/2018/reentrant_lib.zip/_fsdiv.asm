;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:39 2004
;--------------------------------------------------------
	.module _fsdiv
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsdiv
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsdiv'
;------------------------------------------------------------
;a2                        Allocated to stack - offset -6
;a1                        Allocated to registers r2 r3 r4 r5 
;fl1                       Allocated to stack - offset 1
;fl2                       Allocated to stack - offset 5
;result                    Allocated to stack - offset 9
;mask                      Allocated to stack - offset 13
;mant1                     Allocated to stack - offset 17
;mant2                     Allocated to stack - offset 21
;exp                       Allocated to stack - offset 25
;sign                      Allocated to registers r2 
;sloc0                     Allocated to stack - offset 27
;sloc1                     Allocated to stack - offset 31
;------------------------------------------------------------
;_fsdiv.c:28: float __fsdiv (float a1, float a2)
;	-----------------------------------------
;	 function __fsdiv
;	-----------------------------------------
___fsdiv:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0x22
	mov	sp,a
;_fsdiv.c:37: fl1.f = a1;
;     genAddrOf
	mov	a,_bp
	add	a,#0x01
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_fsdiv.c:38: fl2.f = a2;
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
;_fsdiv.c:41: exp = EXP (fl1.l) ;
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	mov	r4,#0x00
	mov	r5,#0x00
;     genAnd
	mov	r3,#0x00
;     genCast
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r4,a
	mov     r5,a
	mov     a,_bp
	add	a,#0x19
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_fsdiv.c:42: exp -= EXP (fl2.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
;     genAnd
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r4,a
	mov     r5,a
	mov     a,_bp
	add	a,#0x1b
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
;     genCast
	mov	a,_bp
	add	a,#0x19
	mov	r0,a
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	mov	a,@r0
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genMinus
	mov	a,_bp
	add	a,#0x1b
	mov	r0,a
	mov	a,r6
	clr	c
	subb	a,@r0
	mov	r6,a
	mov	a,r7
	inc	r0
	subb	a,@r0
	mov	r7,a
	mov	a,r2
	inc	r0
	subb	a,@r0
	mov	r2,a
	mov	a,r3
	inc	r0
	subb	a,@r0
	mov	r3,a
;     genCast
	mov	a,_bp
	add	a,#0x19
	mov	r0,a
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
;_fsdiv.c:43: exp += EXCESS;
;     genPlus
	mov	a,_bp
	add	a,#0x19
	mov	r0,a
	mov	a,#0x7E
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsdiv.c:46: sign = SIGN (fl1.l) ^ SIGN (fl2.l);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genGetHbit
	mov	a,r5
	rl	a
	anl	a,#0x01
	mov	r2,a
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genGetHbit
	mov	a,r6
	rl	a
	anl	a,#0x01
;     genXor
;       Peephole 105    removed redundant mov
	mov     r3,a
	xrl	ar2,a
;     genAssign
;_fsdiv.c:49: if (!fl2.l)
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genIfx
	mov	a,r3
	orl	a,r4
	orl	a,r5
	orl	a,r6
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00123$:
;_fsdiv.c:51: return (-1.0);
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x80
	mov	a,#0xBF
	ljmp	00112$
00102$:
;_fsdiv.c:54: if (!fl1.l)
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genIfx
	mov	a,r3
	orl	a,r4
	orl	a,r5
	orl	a,r6
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00104$
00124$:
;_fsdiv.c:55: return (0);
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00112$
00104$:
;_fsdiv.c:58: mant1 = MANT (fl1.l);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genAnd
	anl	ar5,#0x7F
	mov	r6,#0x00
;     genOr
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	mov	a,#0x80
	orl	a,r5
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar6
;_fsdiv.c:59: mant2 = MANT (fl2.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genAnd
	anl	ar5,#0x7F
	mov	r6,#0x00
;     genOr
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	mov	a,#0x80
	orl	a,r5
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar6
;_fsdiv.c:62: if (mant1 < mant2)
;     genCmpLt
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	a,_bp
	add	a,#0x15
	mov	r1,a
;     genCmp
	clr	c
	mov	a,@r0
	subb	a,@r1
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	inc	r0
	mov	a,@r0
	xrl	a,#0x80
	inc	r1
	mov	b,@r1
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00106$
00125$:
;_fsdiv.c:64: mant1 <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
;     genlshFour
	mov	a,@r0
	add	a,acc
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
;_fsdiv.c:65: exp--;
;     genMinus
	mov	a,_bp
	add	a,#0x19
	mov	r0,a
;     genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
00106$:
;_fsdiv.c:69: mask = 0x1000000;
;     genAssign
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x01
;_fsdiv.c:70: result = 0;
;     genAssign
	mov	a,_bp
	add	a,#0x09
;       Peephole 218    simplified clear (4bytes)
	mov     r0,a
	clr     a
	mov     @r0,a
	inc     r0
	mov     @r0,a
	inc     r0
	mov     @r0,a
	inc     r0
	mov     @r0,a
;_fsdiv.c:71: while (mask)
00109$:
;     genIfx
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	a,@r0
	inc	r0
	orl	a,@r0
	inc	r0
	orl	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
	jnz	00126$
	ljmp	00111$
00126$:
;_fsdiv.c:73: if (mant1 >= mant2)
;     genCmpLt
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	a,_bp
	add	a,#0x15
	mov	r1,a
;     genCmp
	clr	c
	mov	a,@r0
	subb	a,@r1
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	inc	r0
	mov	a,@r0
	xrl	a,#0x80
	inc	r1
	mov	b,@r1
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00108$
00127$:
;_fsdiv.c:75: result |= mask;
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genOr
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	a,@r0
	orl	ar3,a
	inc	r0
	mov	a,@r0
	orl	ar4,a
	inc	r0
	mov	a,@r0
	orl	ar5,a
	inc	r0
	mov	a,@r0
	orl	ar6,a
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar6
;_fsdiv.c:76: mant1 -= mant2;
;     genMinus
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	a,_bp
	add	a,#0x15
	mov	r1,a
	mov	a,@r0
	clr	c
	subb	a,@r1
	mov	@r0,a
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	mov	@r0,a
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	mov	@r0,a
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	mov	@r0,a
00108$:
;_fsdiv.c:78: mant1 <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
;     genlshFour
	mov	a,@r0
	add	a,acc
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
;_fsdiv.c:79: mask >>= 1;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x0d
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	clr	c
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	ljmp	00109$
00111$:
;_fsdiv.c:83: result += 1;
;     genPlus
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsdiv.c:86: exp++;
;     genPlus
	mov	a,_bp
	add	a,#0x19
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsdiv.c:87: result >>= 1;
;     genRightShift
;     genSignedRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x09
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	mov	c,acc.7
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
;_fsdiv.c:89: result &= ~HIDDEN;
;     genAnd
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	a,#0x7F
	inc	r0
	inc	r0
	anl	a,@r0
	mov	@r0,a
;_fsdiv.c:92: fl1.l = PACK (sign ? 1ul<<31 : 0, (unsigned long) exp, result);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genIfx
	mov	a,r2
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00114$
00128$:
;     genAssign
	mov	a,_bp
	add	a,#0x1f
	mov	r1,a
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x80
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00115$
00114$:
;     genAssign
	mov	a,_bp
	add	a,#0x1f
;       Peephole 218    simplified clear (4bytes)
	mov     r1,a
	clr     a
	mov     @r1,a
	inc     r1
	mov     @r1,a
	inc     r1
	mov     @r1,a
	inc     r1
	mov     @r1,a
00115$:
;     genCast
	mov	a,_bp
	add	a,#0x19
	mov	r1,a
	mov	ar6,@r1
	inc	r1
	mov	ar7,@r1
	mov	a,@r1
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genLeftShift
;     genLeftShiftLiteral
;     genlshFour
	mov	ar2,r6
	mov	a,r7
	anl	a,#0x01
	mov	c,acc.0
	xch	a,r2
	rrc	a
	xch	a,r2
	rrc	a
	xch	a,r2
	mov	r3,a
;     genOr
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r7,a
	mov     r6,a
	mov     a,_bp
	add	a,#0x1f
	mov	r1,a
	mov	a,r6
	orl	a,@r1
	mov	@r1,a
	mov	a,r7
	inc	r1
	orl	a,@r1
	mov	@r1,a
	mov	a,r2
	inc	r1
	orl	a,@r1
	mov	@r1,a
	mov	a,r3
	inc	r1
	orl	a,@r1
	mov	@r1,a
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
	inc	r1
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
;     genOr
	mov	a,_bp
	add	a,#0x1f
	mov	r1,a
	mov	a,@r1
	orl	ar4,a
	inc	r1
	mov	a,@r1
	orl	ar5,a
	inc	r1
	mov	a,@r1
	orl	ar2,a
	inc	r1
	mov	a,@r1
	orl	ar3,a
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_fsdiv.c:93: return (fl1.f);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00112$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
