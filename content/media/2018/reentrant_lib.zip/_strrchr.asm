;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:45 2004
;--------------------------------------------------------
	.module _strrchr
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strrchr
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strrchr'
;------------------------------------------------------------
;ch                        Allocated to stack - offset -3
;string                    Allocated to registers r2 r3 r4 
;start                     Allocated to stack - offset 1
;------------------------------------------------------------
;_strrchr.c:26: char * strrchr (
;	-----------------------------------------
;	 function strrchr
;	-----------------------------------------
_strrchr:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
	inc	sp
	inc	sp
	inc	sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;_strrchr.c:31: char * start = string;
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
;_strrchr.c:33: while (*string++)                       /* find end of string */
;     genAssign
00101$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
;     genIfx
	mov	a,r5
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00101$
00116$:
;_strrchr.c:36: while (--string != start && *string != ch)
;     genAssign
00105$:
;     genMinus
;     genMinusDec
	dec	r2
	cjne	r2,#0xff,00117$
	dec	r3
00117$:
;     genCmpEq
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	cjne	a,ar2,00118$
	inc	r0
	mov	a,@r0
	cjne	a,ar3,00118$
	inc	r0
	mov	a,@r0
	cjne	a,ar4,00118$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00107$
00118$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
;     genCmpEq
	mov	a,_bp
	add	a,#0xfd
	mov	r0,a
	mov	a,@r0
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    a,ar5,00105$
;00119$:
;       Peephole 200    removed redundant sjmp
00120$:
00107$:
;_strrchr.c:39: if (*string == ch)                /* char found ? */
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
;     genCmpEq
	mov	a,_bp
	add	a,#0xfd
	mov	r0,a
	mov	a,@r0
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    a,ar5,00109$
;00121$:
;       Peephole 200    removed redundant sjmp
00122$:
;_strrchr.c:40: return( (char *)string );
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00110$
00109$:
;_strrchr.c:42: return (NULL) ;
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x00
00110$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
