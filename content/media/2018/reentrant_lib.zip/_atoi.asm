;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:37 2004
;--------------------------------------------------------
	.module _atoi
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atoi
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atoi'
;------------------------------------------------------------
;s                         Allocated to stack - offset 1
;rv                        Allocated to registers r5 r6 
;sign                      Allocated to registers r4 
;sloc0                     Allocated to stack - offset 7
;sloc1                     Allocated to stack - offset 4
;------------------------------------------------------------
;_atoi.c:25: int atoi(char * s)
;	-----------------------------------------
;	 function atoi
;	-----------------------------------------
_atoi:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	inc	sp
	inc	sp
	inc	sp
;_atoi.c:27: register int rv=0; 
;     genAssign
;_atoi.c:31: while (*s) {
;     genAssign
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r5,a
	mov     r6,a
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
00107$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r4,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00109$
00133$:
;_atoi.c:32: if (*s <= '9' && *s >= '0')
;     genCmpGt
;     genCmp
	clr	c
;       Peephole 159    avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	mov	b,r4
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00102$
00134$:
;     genCmpLt
;     genCmp
	clr	c
	mov	a,r4
	xrl	a,#0x80
	subb	a,#0xb0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00109$
00135$:
;_atoi.c:33: break;
00102$:
;_atoi.c:34: if (*s == '-' || *s == '+') 
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
	mov	r4,a
;     genCmpEq
	cjne	r4,#0x2D,00136$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00109$
00136$:
;     genCmpEq
	cjne	r4,#0x2B,00137$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00109$
00137$:
;_atoi.c:36: s++;
;     genPlus
;     genPlusIncr
	inc	r7
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 243    avoided branch to sjmp
	cjne    r7,#0x00,00107$
	inc     r2
00138$:
	sjmp    00107$      
00109$:
;_atoi.c:39: sign = (*s == '-');
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
	mov	r2,a
;     genCmpEq
;       Peephole 241.c  optimized compare
	clr     a
	cjne    r2,#0x2D,00139$
	inc     a
00139$:
00140$:
;     genAssign
;_atoi.c:40: if (*s == '-' || *s == '+') s++;
;     genIfx
;       Peephole 166    removed redundant mov
	mov     r3,a
	mov     ar4,r3
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00110$
00141$:
;     genCmpEq
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    r2,#0x2B,00131$
;00142$:
;       Peephole 200    removed redundant sjmp
00143$:
00110$:
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_atoi.c:42: while (*s && *s >= '0' && *s <= '9') {
00131$:
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,_bp
	add	a,#0x04
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00115$:
;     genPointerGet
;     genGenPointerGet
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r3,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00117$
00144$:
;     genCmpLt
;     genCmp
	clr	c
	mov	a,r3
	xrl	a,#0x80
	subb	a,#0xb0
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00117$
00145$:
;     genCmpGt
;     genCmp
	clr	c
;       Peephole 159    avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	mov	b,r3
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00117$
00146$:
;_atoi.c:43: rv = (rv * 10) + (*s - '0');
;     genIpush
	push	ar4
;     genIpush
	push	ar3
	mov	a,#0x0A
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
	mov	dpl,r5
	mov	dph,r6
	lcall	__mulint
	mov	r4,dpl
	mov	r2,dph
	dec	sp
	dec	sp
	pop	ar3
;     genCast
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r7,a
;     genMinus
	mov	a,r3
	add	a,#0xd0
	mov	r3,a
	mov	a,r7
	addc	a,#0xff
	mov	r7,a
;     genPlus
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	r4,a
;       Peephole 236.g  used r7 instead of ar7
	mov     a,r7
;       Peephole 236.b  used r2 instead of ar2
	addc    a,r2
	mov	r2,a
;     genAssign
	mov	ar5,r4
	mov	ar6,r2
;_atoi.c:44: s++;
;     genPlus
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;     genIpop
	pop	ar4
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00115$
00117$:
;_atoi.c:47: return (sign ? -rv : rv);
;     genIfx
	mov	a,r4
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00120$
00147$:
;     genUminus
	clr	c
	clr	a
	subb	a,r5
	mov	r2,a
	clr	a
	subb	a,r6
	mov	r3,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00121$
00120$:
;     genAssign
	mov	ar2,r5
	mov	ar3,r6
00121$:
;     genRet
	mov	dpl,r2
	mov	dph,r3
00118$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
