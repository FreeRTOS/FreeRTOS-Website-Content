;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:41 2004
;--------------------------------------------------------
	.module _isspace
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _isspace
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'isspace'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;_isspace.c:24: char isspace (unsigned char c) 
;	-----------------------------------------
;	 function isspace
;	-----------------------------------------
_isspace:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
;_isspace.c:27: if ( c == ' '  ||
;     genCmpEq
	cjne	r2,#0x20,00115$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00101$
00115$:
;_isspace.c:28: c == '\f' ||
;     genCmpEq
	cjne	r2,#0x0C,00116$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00101$
00116$:
;_isspace.c:29: c == '\n' ||
;     genCmpEq
	cjne	r2,#0x0A,00117$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00101$
00117$:
;_isspace.c:30: c == '\r' ||
;     genCmpEq
	cjne	r2,#0x0D,00118$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00101$
00118$:
;_isspace.c:31: c == '\t' ||
;     genCmpEq
	cjne	r2,#0x09,00119$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00101$
00119$:
;_isspace.c:32: c == '\v' ) 
;     genCmpEq
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    r2,#0x0B,00102$
;00120$:
;       Peephole 200    removed redundant sjmp
00121$:
00101$:
;_isspace.c:33: return 1;
;     genRet
	mov	dpl,#0x01
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00108$
00102$:
;_isspace.c:34: return 0;
;     genRet
	mov	dpl,#0x00
00108$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
