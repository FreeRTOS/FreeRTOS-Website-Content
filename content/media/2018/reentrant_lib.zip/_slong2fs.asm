;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:43 2004
;--------------------------------------------------------
	.module _slong2fs
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___slong2fs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__slong2fs'
;------------------------------------------------------------
;sl                        Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;_slong2fs.c:4: float __slong2fs (signed long sl) {
;	-----------------------------------------
;	 function __slong2fs
;	-----------------------------------------
___slong2fs:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;_slong2fs.c:5: if (sl<0) 
;     genCmpLt
;     genCmp
;       Peephole 105    removed redundant mov
	mov     r5,a
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00102$
00107$:
;_slong2fs.c:6: return -__ulong2fs(-sl);
;     genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r6,a
	clr	a
	subb	a,r3
	mov	r7,a
	clr	a
	subb	a,r4
	mov	r0,a
	clr	a
	subb	a,r5
;     genCall
;       Peephole 191    removed redundant mov
	mov     r1,a
	mov     dpl,r6
	mov     dph,r7
	mov     b,r0
	lcall	___ulong2fs
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
;     genUminus
;     genUminusFloat
;       Peephole 105    removed redundant mov
	mov     r1,a
	cpl	acc.7
;     genRet
;       Peephole 191    removed redundant mov
	mov     r1,a
	mov     dpl,r6
	mov     dph,r7
	mov     b,r0
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00104$
00102$:
;_slong2fs.c:8: return __ulong2fs(sl);
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___ulong2fs
;     genRet
;       Peephole 191    removed redundant mov
	mov     r2,dpl
	mov     r3,dph
	mov     r4,b
	mov     r5,a
;       Peephole 238.b  removed 3 redundant moves
00104$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
