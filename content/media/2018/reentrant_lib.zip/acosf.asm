;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:46 2004
;--------------------------------------------------------
	.module acosf
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _acosf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'acosf'
;------------------------------------------------------------
;x                         Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;acosf.c:25: float acosf(const float x) reentrant
;	-----------------------------------------
;	 function acosf
;	-----------------------------------------
_acosf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;acosf.c:27: if(x== 1.0) return 0.0;
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fseq
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r6
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00107$
00114$:
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00109$
00107$:
;acosf.c:28: else if(x==-1.0) return PI;
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0xBF
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fseq
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r6
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00104$
00115$:
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0FDB
	mov	b,#0x49
	mov	a,#0x40
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00109$
00104$:
;acosf.c:29: else if(x== 0.0) return HALF_PI;
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fseq
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r6
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00108$
00116$:
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0FDB
	mov	b,#0xC9
	mov	a,#0x3F
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00109$
00108$:
;acosf.c:30: return asincosf(x,1);
;     genIpush
	mov	a,#0x01
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	_asincosf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	dec	sp
	dec	sp
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00109$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
