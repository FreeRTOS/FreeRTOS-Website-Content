;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:56 2004
;--------------------------------------------------------
	.module _modulong
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __modulong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_modulong'
;------------------------------------------------------------
;b                         Allocated to stack - offset -6
;a                         Allocated to registers r2 r3 r4 r5 
;count                     Allocated to stack - offset 1
;------------------------------------------------------------
;_modulong.c:340: _modulong (unsigned long a, unsigned long b)
;	-----------------------------------------
;	 function _modulong
;	-----------------------------------------
__modulong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	inc	sp
;_modulong.c:342: unsigned char count = 0;
;     genAssign
	mov	r6,#0x00
;_modulong.c:344: while (!MSB_SET(b))
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,#0x00
00103$:
;     genGetHbit
	mov	a,_bp
	add	a,#0xfa
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	rl	a
	anl	a,#0x01
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r7,a
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00117$
00119$:
;_modulong.c:346: b <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
;     genlshFour
	mov	a,@r0
	add	a,acc
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
;_modulong.c:347: if (b > a)
;     genCmpGt
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	inc	r0
	subb	a,@r0
	mov	a,r4
	inc	r0
	subb	a,@r0
	mov	a,r5
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00102$
00120$:
;_modulong.c:349: b >>=1;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0xfa
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	clr	c
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
;_modulong.c:350: break;
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00117$
00102$:
;_modulong.c:352: count++;
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPlusIncr
	inc	@r0
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar6,@r0
;_modulong.c:354: do
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00103$
00117$:
;     genAssign
00108$:
;_modulong.c:356: if (a >= b)
;     genCmpLt
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	inc	r0
	subb	a,@r0
	mov	a,r4
	inc	r0
	subb	a,@r0
	mov	a,r5
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00107$
00121$:
;_modulong.c:357: a -= b;
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,r2
	clr	c
	subb	a,@r0
	mov	r2,a
	mov	a,r3
	inc	r0
	subb	a,@r0
	mov	r3,a
	mov	a,r4
	inc	r0
	subb	a,@r0
	mov	r4,a
	mov	a,r5
	inc	r0
	subb	a,@r0
	mov	r5,a
00107$:
;_modulong.c:358: b >>= 1;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0xfa
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	clr	c
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
;_modulong.c:360: while (count--);
;     genAssign
	mov	ar7,r6
;     genMinus
;     genMinusDec
	dec	r6
;     genIfx
	mov	a,r7
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00108$
00122$:
;_modulong.c:362: return a;
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00111$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
