;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:49 2004
;--------------------------------------------------------
	.module malloc
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _init_dynamic_memory
	.globl _malloc
	.globl _free
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_FIRST_MEMORY_HEADER_PTR:
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'init_dynamic_memory'
;------------------------------------------------------------
;size                      Allocated to stack - offset -4
;array                     Allocated to registers r2 r3 
;------------------------------------------------------------
;malloc.c:145: void init_dynamic_memory(MEMHEADER xdata * array, unsigned int size) 
;	-----------------------------------------
;	 function init_dynamic_memory
;	-----------------------------------------
_init_dynamic_memory:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
;malloc.c:167: if ( !array ) /*Reserved memory starts on 0x0000 but it's NULL...*/
;     genIfx
	mov	a,r2
	orl	a,r3
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00106$:
;malloc.c:169: array = (MEMHEADER xdata * )((char xdata * ) array + 1) ;
;     genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00107$
	inc	r3
00107$:
;malloc.c:170: size --;
;     genMinus
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
;     genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
00102$:
;malloc.c:172: FIRST_MEMORY_HEADER_PTR = array;
;     genAssign
	mov	dptr,#_FIRST_MEMORY_HEADER_PTR
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;malloc.c:174: array->next = (MEMHEADER xdata * )(((char xdata * ) array) + size - HEADER_SIZE);
;     genPlus
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
	mov	a,@r0
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r4,a
	inc	r0
	mov	a,@r0
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	r5,a
;     genMinus
	mov	a,r4
	add	a,#0xfa
	mov	r4,a
	mov	a,r5
	addc	a,#0xff
	mov	r5,a
;     genPointerSet
;     genFarPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;malloc.c:175: array->next->next = (void xdata * ) NULL; //And mark it as last
;     genCast
	mov	dpl,r4
	mov	dph,r5
;     genPointerSet
;     genFarPointerSet
;       Peephole 101    removed redundant mov
;       Peephole 181    changed mov to clr
;       Peephole 181    changed mov to clr
;       Peephole 226    removed unnecessary clr
	clr     a
	movx    @dptr,a
	inc     dptr
	movx    @dptr,a
	inc     dptr
	movx	@dptr,a
;malloc.c:176: array->prev       = (void xdata * ) NULL; //and mark first as first
;     genPlus
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
;       Peephole 101    removed redundant mov
;       Peephole 181    changed mov to clr
;       Peephole 181    changed mov to clr
;       Peephole 226    removed unnecessary clr
	clr     a
	movx    @dptr,a
	inc     dptr
	movx    @dptr,a
	inc     dptr
	movx	@dptr,a
;malloc.c:177: array->len        = 0;    //Empty and ready.
;     genPlus
;     genPlusIncr
	mov	a,#0x04
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
;       Peephole 101    removed redundant mov
;       Peephole 181    changed mov to clr
	clr     a
	movx    @dptr,a
	inc     dptr
	movx    @dptr,a
00103$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'malloc'
;------------------------------------------------------------
;size                      Allocated to stack - offset 1
;current_header            Allocated to stack - offset 3
;new_header                Allocated to registers r2 r3 
;sloc0                     Allocated to stack - offset 5
;------------------------------------------------------------
;malloc.c:180: void  xdata * malloc (unsigned int size)
;	-----------------------------------------
;	 function malloc
;	-----------------------------------------
_malloc:
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	mov	a,sp
	add	a,#0x06
	mov	sp,a
;malloc.c:185: if (size>(0xFFFF-HEADER_SIZE)) return (void xdata *) NULL; //To prevent overflow in next line
;     genCmpGt
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genCmp
	clr	c
	mov	a,#0xF9
	subb	a,@r0
	mov	a,#0xFF
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00102$
00122$:
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x00
	ljmp	00114$
00102$:
;malloc.c:186: size += HEADER_SIZE; //We need a memory for header too
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,#0x06
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;malloc.c:187: current_header = FIRST_MEMORY_HEADER_PTR;
;     genAssign
	mov	dptr,#_FIRST_MEMORY_HEADER_PTR
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;     genAssign
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;malloc.c:188: while (1)
00108$:
;malloc.c:198: if ((((unsigned int)current_header->next) -
;     genPointerGet
;     genFarPointerGet
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;     genCast
	mov	ar2,r6
	mov	ar3,r7
;malloc.c:199: ((unsigned int)current_header) -
;     genCast
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genMinus
	mov	a,r2
	clr	c
;       Peephole 236.l  used r4 instead of ar4
	subb    a,r4
	mov	r2,a
	mov	a,r3
;       Peephole 236.l  used r5 instead of ar5
	subb    a,r5
	mov	r3,a
;malloc.c:200: current_header->len) >= size) break; //if spare is more than need
;     genPlus
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
;     genPlusIncr
	mov	a,#0x04
	add	a,@r0
	mov	r4,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r5,a
;     genPointerGet
;     genFarPointerGet
	mov	dpl,r4
	mov	dph,r5
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	movx	a,@dptr
	mov	@r0,a
	inc	dptr
	movx	a,@dptr
	inc	r0
	mov	@r0,a
;     genMinus
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	a,r2
	clr	c
	subb	a,@r0
	mov	r2,a
	mov	a,r3
	inc	r0
	subb	a,@r0
	mov	r3,a
;     genCmpLt
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00109$
00123$:
;malloc.c:201: current_header = current_header->next;    //else try next             
;     genAssign
	mov	ar2,r6
	mov	ar3,r7
;     genAssign
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;malloc.c:202: if (!current_header->next)  return (void xdata *) NULL;  //if end_of_list reached
;     genPointerGet
;     genFarPointerGet
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
;     genIfx
;       Peephole 135    removed redundant mov
	mov     r3,a
	orl     a,r2
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00108$
00124$:
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x00
	ljmp	00114$
00109$:
;malloc.c:204: if (!current_header->len)
;     genIfx
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00111$
00125$:
;malloc.c:206: current_header->len = size; //for first allocation
;     genPointerSet
;     genFarPointerSet
	mov	dpl,r4
	mov	dph,r5
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;malloc.c:207: return ((xdata *)&(current_header->mem));
;     genPlus
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	a,#0x06
	add	a,@r0
	mov	r2,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r3,a
;     genRet
	mov	dpl,r2
	mov	dph,r3
	ljmp	00114$
00111$:
;malloc.c:209: new_header = (MEMHEADER xdata * )((char xdata *)current_header + current_header->len);
;     genPlus
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	a,_bp
	add	a,#0x05
	mov	r1,a
	mov	a,@r1
	add	a,@r0
	mov	r2,a
	inc	r1
	mov	a,@r1
	inc	r0
	addc	a,@r0
	mov	r3,a
;     genAssign
;malloc.c:210: new_header->next = current_header->next; //and plug it into the chain
;     genPointerSet
;     genFarPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;malloc.c:211: new_header->prev = current_header;
;     genPlus
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;malloc.c:212: current_header->next  = new_header;
;     genPointerSet
;     genFarPointerSet
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;malloc.c:213: if (new_header->next)  new_header->next->prev = new_header;
;     genIfx
	mov	a,r6
	orl	a,r7
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00113$
00126$:
;     genPointerGet
;     genFarPointerGet
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;     genPlus
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r5 instead of ar5
	addc    a,r5
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
00113$:
;malloc.c:214: new_header->len  = size; //mark as used
;     genPlus
;     genPlusIncr
	mov	a,#0x04
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;malloc.c:215: return ((xdata *)&(new_header->mem));
;     genPlus
	mov	a,#0x06
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r2,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	r3,a
;     genRet
	mov	dpl,r2
	mov	dph,r3
00114$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'free'
;------------------------------------------------------------
;p                         Allocated to registers r2 r3 
;prev_header               Allocated to registers r4 r5 
;------------------------------------------------------------
;malloc.c:218: void free (void xdata * p)
;	-----------------------------------------
;	 function free
;	-----------------------------------------
_free:
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
;malloc.c:221: if ( p ) //For allocated pointers only!
;     genIfx
	mov	a,r2
	orl	a,r3
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00108$
00113$:
;malloc.c:223: p = (MEMHEADER xdata * )((char xdata *)  p - HEADER_SIZE); //to start of header
;     genMinus
	mov	a,r2
	add	a,#0xfa
	mov	r2,a
	mov	a,r3
	addc	a,#0xff
	mov	r3,a
;malloc.c:224: if ( ((MEMHEADER xdata * ) p)->prev ) // For the regular header
;     genPlus
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	dph,a
;     genPointerGet
;     genFarPointerGet
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
;     genIfx
;       Peephole 135    removed redundant mov
	mov     r5,a
	orl     a,r4
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00104$
00114$:
;malloc.c:226: prev_header = ((MEMHEADER xdata * ) p)->prev;
;     genAssign
;     genAssign
;malloc.c:227: prev_header->next = ((MEMHEADER xdata * ) p)->next;
;     genPointerGet
;     genFarPointerGet
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;     genPointerSet
;     genFarPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;malloc.c:228: if (((MEMHEADER xdata * ) p)->next)
;     genIfx
	mov	a,r6
	orl	a,r7
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00108$
00115$:
;malloc.c:229: ((MEMHEADER xdata * ) p)->next->prev = prev_header;
;     genPlus
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r6 instead of ar6
	add     a,r6
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r7 instead of ar7
	addc    a,r7
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00108$
00104$:
;malloc.c:231: else ((MEMHEADER xdata * ) p)->len = 0; //For the first header
;     genPlus
;     genPlusIncr
	mov	a,#0x04
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
;       Peephole 101    removed redundant mov
;       Peephole 181    changed mov to clr
	clr     a
	movx    @dptr,a
	inc     dptr
	movx    @dptr,a
00108$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
