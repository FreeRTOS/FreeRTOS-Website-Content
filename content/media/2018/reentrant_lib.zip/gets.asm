;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:49 2004
;--------------------------------------------------------
	.module gets
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _gets
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'gets'
;------------------------------------------------------------
;str                       Allocated to stack - offset 1
;s                         Allocated to registers r5 r6 r7 
;c                         Allocated to registers r4 
;count                     Allocated to registers r2 r3 
;------------------------------------------------------------
;gets.c:3: char * gets(const char *str) {
;	-----------------------------------------
;	 function gets
;	-----------------------------------------
_gets:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
;gets.c:4: char *s=str;
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
;gets.c:6: unsigned int count=0;
;     genAssign
	mov	r2,#0x00
	mov	r3,#0x00
;gets.c:8: while (1) {
00109$:
;gets.c:9: c=getchar();
;     genCall
	push	ar2
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	lcall	_getchar
	mov	r4,dpl
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;     genAssign
;gets.c:10: switch(c) {
;     genCmpEq
	cjne	r4,#0x08,00118$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00101$
00118$:
;     genCmpEq
	cjne	r4,#0x0A,00119$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00105$
00119$:
;     genCmpEq
	cjne	r4,#0x0D,00120$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00105$
00120$:
	ljmp	00106$
;gets.c:11: case '\b': // backspace
00101$:
;gets.c:12: if (count) {
;     genIfx
	mov	a,r2
	orl	a,r3
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00109$
00121$:
;gets.c:13: putchar ('\b');
;     genCall
	mov	dpl,#0x08
	push	ar2
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;gets.c:14: putchar (' ');
;     genCall
	mov	dpl,#0x20
	push	ar2
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;gets.c:15: putchar ('\b');
;     genCall
	mov	dpl,#0x08
	push	ar2
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;gets.c:16: s--;
;     genMinus
;     genMinusDec
	dec	r5
	cjne	r5,#0xff,00122$
	dec	r6
00122$:
;gets.c:17: count--;
;     genMinus
;     genMinusDec
	dec	r2
	cjne	r2,#0xff,00123$
	dec	r3
00123$:
;gets.c:19: break;
	ljmp	00109$
;gets.c:21: case '\r': // CR or LF
00105$:
;gets.c:22: putchar('\r');
;     genCall
	mov	dpl,#0x0D
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
;gets.c:23: putchar('\n');
;     genCall
	mov	dpl,#0x0A
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
;gets.c:24: *s=0;
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;       Peephole 181    changed mov to clr
	clr     a
	lcall	__gptrput
;gets.c:25: return str;
;     genRet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
;gets.c:26: default:
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00111$
00106$:
;gets.c:27: *s++=c;
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r4
	lcall	__gptrput
	inc	dptr
	mov	r5,dpl
	mov	r6,dph
;gets.c:28: count++;
;     genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00124$
	inc	r3
00124$:
;gets.c:29: putchar(c);
;     genCall
	mov	dpl,r4
	push	ar2
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;gets.c:31: }
	ljmp	00109$
00111$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
