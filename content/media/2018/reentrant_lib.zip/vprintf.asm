;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:54 2004
;--------------------------------------------------------
	.module vprintf
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _vsprintf
	.globl _vprintf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_value:
	.ds 5
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_output_to_string:
	.ds 1
_lower_case:
	.ds 1
_lsd:
	.ds 1
_vsprintf_left_justify_1_1:
	.ds 1
_vsprintf_zero_padding_1_1:
	.ds 1
_vsprintf_prefix_sign_1_1:
	.ds 1
_vsprintf_prefix_space_1_1:
	.ds 1
_vsprintf_signed_argument_1_1:
	.ds 1
_vsprintf_char_argument_1_1:
	.ds 1
_vsprintf_long_argument_1_1:
	.ds 1
_vsprintf_float_argument_1_1:
	.ds 1
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_output_ptr:
	.ds 3
_radix:
	.ds 1
_charsOutputted:
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'output_char'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;vprintf.c:86: static void output_char( char c ) reentrant
;	-----------------------------------------
;	 function output_char
;	-----------------------------------------
_output_char:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
;vprintf.c:88: if (output_to_string)
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _output_to_string,00102$
00107$:
;vprintf.c:90: *output_ptr++ = c;
;     genAssign
	mov	dptr,#_output_ptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	mov	a,r2
	lcall	__gptrput
;     genPlus
	mov	dptr,#_output_ptr
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r3 instead of ar3
	add     a,r3
	movx	@dptr,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r4 instead of ar4
	addc    a,r4
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00103$
00102$:
;vprintf.c:94: putchar( c );
;     genCall
	mov	dpl,r2
	lcall	_putchar
00103$:
;vprintf.c:96: charsOutputted++;
;     genAssign
	mov	dptr,#_charsOutputted
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;     genPlus
	mov	dptr,#_charsOutputted
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	movx	@dptr,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	inc	dptr
	movx	@dptr,a
00104$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'output_digit'
;------------------------------------------------------------
;n                         Allocated to registers r2 
;------------------------------------------------------------
;vprintf.c:101: static void output_digit( unsigned char n ) reentrant
;	-----------------------------------------
;	 function output_digit
;	-----------------------------------------
_output_digit:
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
;vprintf.c:103: output_char( n <= 9 ? '0'+n : 
;     genCmpGt
;     genCmp
	clr	c
	mov	a,#0x09
	subb	a,r2
;     genNot
;       Peephole 105    removed redundant mov
;     genIfx
;       Peephole 105    removed redundant mov
;       Peephole 245    optimized complement (r3 and acc set needed?)
	cpl	c
	clr	a
	rlc	a
	mov	r3,a	
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00103$
00110$:
;     genPlus
	mov	a,#0x30
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r3,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00104$
00103$:
;vprintf.c:104: (lower_case ? n+(char)('a'-10) : n+(char)('A'-10)) );
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _lower_case,00105$
00111$:
;     genPlus
	mov	a,#0x57
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r4,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00106$
00105$:
;     genPlus
	mov	a,#0x37
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r4,a
00106$:
;     genAssign
	mov	ar3,r4
00104$:
;     genCall
	mov	dpl,r3
	lcall	_output_char
00101$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'output_2digits'
;------------------------------------------------------------
;b                         Allocated to registers r2 
;------------------------------------------------------------
;vprintf.c:109: static void output_2digits( unsigned char b ) reentrant
;	-----------------------------------------
;	 function output_2digits
;	-----------------------------------------
_output_2digits:
	push	_bp
	mov	_bp,sp
;     genReceive
;vprintf.c:111: output_digit( b>>4 );
;     genRightShift
;     genRightShiftLiteral
;     genrshOne
;       Peephole 244.a  moving first to a instead of r2
	mov	a,dpl
	mov	r2,a
	swap	a
	anl	a,#0x0f
;     genCall
;       Peephole 244.c  loading dpl from a instead of r3
	mov	r3,a
	mov	dpl,a
	push	ar2
	lcall	_output_digit
	pop	ar2
;vprintf.c:112: output_digit( b&0x0F );
;     genAnd
	anl	ar2,#0x0F
;     genCall
	mov	dpl,r2
	lcall	_output_digit
00101$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'calculate_digit'
;------------------------------------------------------------
;i                         Allocated to registers r2 
;------------------------------------------------------------
;vprintf.c:117: static void calculate_digit( void )
;	-----------------------------------------
;	 function calculate_digit
;	-----------------------------------------
_calculate_digit:
	push	_bp
	mov	_bp,sp
;vprintf.c:121: for( i = 32; i != 0; i-- )
;     genAssign
	mov	r2,#0x20
00103$:
;     genCmpEq
	cjne	r2,#0x00,00112$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00107$
00112$:
;vprintf.c:140: _endasm;
;     genInline
	  clr c
	  mov a,_value+0
	  rlc a
	  mov _value+0,a
	  mov a,_value+1
	  rlc a
	  mov _value+1,a
	  mov a,_value+2
	  rlc a
	  mov _value+2,a
	  mov a,_value+3
	  rlc a
	  mov _value+3,a
	  mov a,_value+4
	  rlc a
	  mov _value+4,a
;vprintf.c:142: if (radix <= value.byte[4] )
;     genAssign
	mov	dptr,#_radix
	movx	a,@dptr
	mov	r3,a
;     genAssign
;     genCmpGt
;     genCmp
	clr	c
	mov	a,0x0004 + _value
	subb	a,r3
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00105$
00113$:
;vprintf.c:144: value.byte[4] -= radix;
;     genAssign
;     genMinus
	mov	a,0x0004 + _value
	clr	c
;       Peephole 236.l  used r3 instead of ar3
	subb    a,r3
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	(_value + 0x0004),a
;vprintf.c:145: value.byte[0]++;
;     genPointerGet
;     genNearPointerGet
;     genDataPointerGet
	mov	r3,_value
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r3 instead of ar3
	add     a,r3
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,a
00105$:
;vprintf.c:121: for( i = 32; i != 0; i-- )
;     genMinus
;     genMinusDec
	dec	r2
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00103$
00107$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vsprintf'
;------------------------------------------------------------
;format                    Allocated to stack - offset -5
;ap                        Allocated to stack - offset -6
;buf                       Allocated to registers r2 r3 r4 
;width                     Allocated to stack - offset 1
;decimals                  Allocated to registers r4 
;length                    Allocated to registers r2 
;c                         Allocated to stack - offset 2
;sloc0                     Allocated to stack - offset 8
;------------------------------------------------------------
;vprintf.c:282: int vsprintf (const char *buf, const char *format, va_list ap)
;	-----------------------------------------
;	 function vsprintf
;	-----------------------------------------
_vsprintf:
	push	_bp
	mov	_bp,sp
	inc	sp
	inc	sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;vprintf.c:299: charsOutputted=0;
;     genAssign
;       Peephole 229    replaced inefficient 16 bit clear
	mov     dptr,#_charsOutputted
	clr     a
	movx    @dptr,a
	inc     dptr
	movx    @dptr,a
;vprintf.c:301: output_ptr = buf;
;     genAssign
;       Peephole 231    removed redundant mov to dptr
	mov     dptr,#_output_ptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;vprintf.c:302: if ( !buf )
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00303$:
;vprintf.c:304: output_to_string = 0;
;     genAssign
	clr	_output_to_string
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00237$
00102$:
;vprintf.c:308: output_to_string = 1;
;     genAssign
	setb	_output_to_string
;vprintf.c:317: while( c=*format++ )
00237$:
00221$:
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar4
;     genAssign
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	@r0,ar5
;     genIfx
	mov	a,r5
;     genIfxJump
	jnz	00304$
	ljmp	00223$
00304$:
;vprintf.c:319: if ( c=='%' )
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x25,00305$
	sjmp	00306$
00305$:
	ljmp	00219$
00306$:
;vprintf.c:321: left_justify    = 0;
;     genAssign
	clr	_vsprintf_left_justify_1_1
;vprintf.c:322: zero_padding    = 0;
;     genAssign
	clr	_vsprintf_zero_padding_1_1
;vprintf.c:323: prefix_sign     = 0;
;     genAssign
	clr	_vsprintf_prefix_sign_1_1
;vprintf.c:324: prefix_space    = 0;
;     genAssign
	clr	_vsprintf_prefix_space_1_1
;vprintf.c:325: signed_argument = 0;
;     genAssign
	clr	_vsprintf_signed_argument_1_1
;vprintf.c:326: radix           = 0;
;     genAssign
	mov	dptr,#_radix
;       Peephole 181    changed mov to clr
	clr     a
	movx	@dptr,a
;vprintf.c:327: char_argument   = 0;
;     genAssign
	clr	_vsprintf_char_argument_1_1
;vprintf.c:328: long_argument   = 0;
;     genAssign
	clr	_vsprintf_long_argument_1_1
;vprintf.c:329: float_argument  = 0;
;     genAssign
	clr	_vsprintf_float_argument_1_1
;vprintf.c:330: width           = 0;
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,#0x00
;vprintf.c:331: decimals        = -1;
;     genAssign
	mov	r4,#0xFF
;vprintf.c:333: get_conversion_spec:
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
00104$:
;vprintf.c:335: c = *format++;
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	mov	r5,dpl
	mov	r6,dph
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
;     genAssign
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	@r0,ar2
;vprintf.c:337: if (c=='%') {
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    @r0,#0x25,00106$
;00307$:
;       Peephole 200    removed redundant sjmp
00308$:
;vprintf.c:338: output_char(c);
;     genCall
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	dpl,@r0
	lcall	_output_char
;vprintf.c:339: continue;
	ljmp	00221$
00106$:
;vprintf.c:342: if (isdigit(c)) {
;     genCall
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	dpl,@r0
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	lcall	_isdigit
	mov	a,dpl
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00113$
00309$:
;vprintf.c:343: if (decimals==-1) {
;     genCmpEq
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    r4,#0xFF,00110$
;00310$:
;       Peephole 200    removed redundant sjmp
00311$:
;vprintf.c:344: width = 10*width + (c - '0');
;     genIpush
	push	ar4
;     genMult
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genMultOneByte
	mov	a,@r0
	mov	b,#0x0A
	mul	ab
	mov	r4,a
;     genMinus
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	a,@r0
	add	a,#0xd0
;     genPlus
;       Peephole 177.b  removed redundant mov
	mov     r2,a
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	r4,a
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar4
;vprintf.c:345: if (width == 0) {
;     genCmpEq
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;       Peephole 241.f  optimized compare
	clr     a
	cjne    @r0,#0x00,00312$
	inc     a
00312$:
00313$:
;     genIpop
	pop	ar4
;     genIfx
;     genIfxJump
	jnz	00314$
	ljmp	00104$
00314$:
;vprintf.c:347: zero_padding = 1;
;     genAssign
	setb	_vsprintf_zero_padding_1_1
	ljmp	00104$
00110$:
;vprintf.c:350: decimals = 10*decimals + (c-'0');
;     genIpush
;     genMult
;     genMultOneByte
	mov	a,r4
	mov	b,#0x0A
	mul	ab
	mov	r2,a
;     genMinus
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	a,@r0
	add	a,#0xd0
;     genPlus
;       Peephole 177.b  removed redundant mov
	mov     r3,a
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r2,a
;     genAssign
	mov	ar4,r2
;vprintf.c:352: goto get_conversion_spec;
;     genIpop
	ljmp	00104$
00113$:
;vprintf.c:355: if (c=='.') {
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    @r0,#0x2E,00117$
;00315$:
;       Peephole 200    removed redundant sjmp
00316$:
;vprintf.c:356: if (decimals=-1) decimals=0;
;     genAssign
	mov	r4,#0x00
;vprintf.c:359: goto get_conversion_spec;
	ljmp	00104$
00117$:
;vprintf.c:362: lower_case = islower(c);
;     genCall
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	dpl,@r0
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	lcall	_islower
	mov	a,dpl
	add	a,#0xff
	mov	_lower_case,c
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
;vprintf.c:363: if (lower_case)
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _lower_case,00119$
00317$:
;vprintf.c:365: c = toupper(c);
;     genAnd
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	a,#0xDF
	anl	a,@r0
	mov	@r0,a
00119$:
;vprintf.c:368: switch( c )
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x20,00318$
	ljmp	00122$
00318$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x2B,00319$
	ljmp	00121$
00319$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x2D,00320$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00120$
00320$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x42,00321$
	ljmp	00123$
00321$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x43,00322$
	ljmp	00125$
00322$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x44,00323$
	ljmp	00147$
00323$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x46,00324$
	ljmp	00151$
00324$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x49,00325$
	ljmp	00147$
00325$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x4C,00326$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00124$
00326$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x4F,00327$
	ljmp	00148$
00327$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x50,00328$
	ljmp	00142$
00328$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x53,00329$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00126$
00329$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x55,00330$
	ljmp	00149$
00330$:
;     genCmpEq
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	cjne	@r0,#0x58,00331$
	ljmp	00150$
00331$:
	ljmp	00152$
;vprintf.c:370: case '-':
00120$:
;vprintf.c:371: left_justify = 1;
;     genAssign
	setb	_vsprintf_left_justify_1_1
;vprintf.c:372: goto get_conversion_spec;
	ljmp	00104$
;vprintf.c:373: case '+':
00121$:
;vprintf.c:374: prefix_sign = 1;
;     genAssign
	setb	_vsprintf_prefix_sign_1_1
;vprintf.c:375: goto get_conversion_spec;
	ljmp	00104$
;vprintf.c:376: case ' ':
00122$:
;vprintf.c:377: prefix_space = 1;
;     genAssign
	setb	_vsprintf_prefix_space_1_1
;vprintf.c:378: goto get_conversion_spec;
	ljmp	00104$
;vprintf.c:379: case 'B':
00123$:
;vprintf.c:380: char_argument = 1;
;     genAssign
	setb	_vsprintf_char_argument_1_1
;vprintf.c:381: goto get_conversion_spec;
	ljmp	00104$
;vprintf.c:382: case 'L':
00124$:
;vprintf.c:383: long_argument = 1;
;     genAssign
	setb	_vsprintf_long_argument_1_1
;vprintf.c:384: goto get_conversion_spec;
	ljmp	00104$
;vprintf.c:386: case 'C':
00125$:
;vprintf.c:387: output_char( va_arg(ap,int) );
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
;     genMinusDec
	mov	a,@r1
	add	a,#0xfe
	mov	r0,a
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	@r1,ar0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar4,@r0
	dec	r0
;     genCast
;     genCall
	mov	dpl,r2
	lcall	_output_char
;vprintf.c:388: break;
	ljmp	00153$
;vprintf.c:390: case 'S':
00126$:
;vprintf.c:391: PTR = va_arg(ap,ptr_t);
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
;     genMinusDec
	mov	a,@r1
	add	a,#0xfd
	mov	r0,a
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	@r1,ar0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	dec	r0
	dec	r0
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r2
	mov	(_value + 1),r4
	mov	(_value + 2),r5
;vprintf.c:401: length = strlen(PTR);
;     genCall
	mov	dpl,r2
	mov	dph,r4
	mov	b,r5
	lcall	_strlen
	mov	r2,dpl
	mov	r4,dph
;     genCast
;vprintf.c:403: if ( ( !left_justify ) && (length < width) )
;     genIfx
;     genIfxJump
;       Peephole 112.a  removed ljmp by inverse jump logic
	jb      _vsprintf_left_justify_1_1,00133$
00332$:
;     genCmpLt
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00133$
00333$:
;vprintf.c:405: width -= length;
;     genMinus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	clr	c
;       Peephole 236.l  used r2 instead of ar2
	subb    a,r2
	mov	@r0,a
;vprintf.c:406: while( width-- != 0 )
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar4,@r0
00127$:
;     genAssign
	mov	ar5,r4
;     genMinus
;     genMinusDec
	dec	r4
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar4
;     genCmpEq
	cjne	r5,#0x00,00334$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00133$
00334$:
;vprintf.c:408: output_char( ' ' );
;     genCall
	mov	dpl,#0x20
	push	ar2
	push	ar4
	lcall	_output_char
	pop	ar4
	pop	ar2
;vprintf.c:412: while ( *PTR )
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00127$
00133$:
;     genAssign
;     genPointerGet
;     genGenPointerGet
	mov	dpl,_value
	mov	dph,(_value + 1)
	mov	b,(_value + 2)
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r4,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00135$
00335$:
;vprintf.c:413: output_char( *PTR++ );
;     genIpush
	push	ar2
;     genPointerGet
;     genNearPointerGet
;     genDataPointerGet
	mov	r4,_value
	mov	r5,(_value + 1)
	mov	r6,(_value + 2)
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	r7,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r5 instead of ar5
	addc    a,r5
	mov	r2,a
	mov	ar3,r6
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r7
	mov	(_value + 1),r2
	mov	(_value + 2),r3
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
;     genCall
;       Peephole 244.c  loading dpl from a instead of r4
	mov	r4,a
	mov	dpl,a
	push	ar2
	lcall	_output_char
	pop	ar2
;     genIpop
	pop	ar2
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00133$
00135$:
;vprintf.c:415: if ( left_justify && (length < width))
;     genIfx
;     genIfxJump
	jb	_vsprintf_left_justify_1_1,00336$
	ljmp	00153$
00336$:
;     genCmpLt
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
;     genIfxJump
	jc	00337$
	ljmp	00153$
00337$:
;vprintf.c:417: width -= length;
;     genMinus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	clr	c
;       Peephole 236.l  used r2 instead of ar2
	subb    a,r2
	mov	@r0,a
;vprintf.c:418: while( width-- != 0 )
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar3,@r0
00136$:
;     genAssign
	mov	ar4,r3
;     genMinus
;     genMinusDec
	dec	r3
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar3
;     genCmpEq
	cjne	r4,#0x00,00338$
	ljmp	00153$
00338$:
;vprintf.c:420: output_char( ' ' );
;     genCall
	mov	dpl,#0x20
	push	ar3
	lcall	_output_char
	pop	ar3
;vprintf.c:425: case 'P':
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00136$
00142$:
;vprintf.c:426: PTR = va_arg(ap,ptr_t);
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
;     genMinusDec
	mov	a,@r1
	add	a,#0xfd
	mov	r0,a
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	@r1,ar0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	dec	r0
	dec	r0
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r3
	mov	(_value + 1),r4
	mov	(_value + 2),r5
;vprintf.c:437: output_char( memory_id[(value.byte[2] > 3) ? 4 : value.byte[2]] );
;     genAssign
;     genCmpGt
;     genCmp
	clr	c
	mov	a,#0x03
	subb	a,0x0002 + _value
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00229$
00339$:
;     genAssign
	mov	r3,#0x04
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00230$
00229$:
;     genPointerGet
;     genNearPointerGet
;     genDataPointerGet
	mov	r3,(_value + 0x0002)
00230$:
;     genPlus
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
;       Peephole 181    changed mov to clr
;     genPointerGet
;     genCodePointerGet
;       Peephole 181    changed mov to clr
;       Peephole 186.d  optimized movc sequence
	mov     dptr,#_memory_id
	movc    a,@a+dptr
;     genCall
;       Peephole 244.c  loading dpl from a instead of r3
	mov	r3,a
	mov	dpl,a
	lcall	_output_char
;vprintf.c:438: output_char(':');
;     genCall
	mov	dpl,#0x3A
	lcall	_output_char
;vprintf.c:439: output_char('0');
;     genCall
	mov	dpl,#0x30
	lcall	_output_char
;vprintf.c:440: output_char('x');
;     genCall
	mov	dpl,#0x78
	lcall	_output_char
;vprintf.c:441: if ((value.byte[2] != 0x00 /* DSEG */) &&
;     genAssign
;     genCmpEq
	mov	a,0x0002 + _value
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00144$
00340$:
;vprintf.c:442: (value.byte[2] != 0x03 /* SSEG */))
;     genAssign
;     genCmpEq
	mov	a,0x0002 + _value
	cjne	a,#0x03,00341$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00144$
00341$:
;vprintf.c:443: output_2digits( value.byte[1] );
;     genAssign
;     genCall
	mov	dpl,0x0001 + _value
	lcall	_output_2digits
00144$:
;vprintf.c:444: output_2digits( value.byte[0] );
;     genAssign
;     genCall
	mov	dpl,_value
	lcall	_output_2digits
;vprintf.c:446: break;
;vprintf.c:449: case 'I':
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00153$
00147$:
;vprintf.c:450: signed_argument = 1;
;     genAssign
	setb	_vsprintf_signed_argument_1_1
;vprintf.c:451: radix = 10;
;     genAssign
	mov	dptr,#_radix
	mov	a,#0x0A
	movx	@dptr,a
;vprintf.c:452: break;
;vprintf.c:454: case 'O':
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00153$
00148$:
;vprintf.c:455: radix = 8;
;     genAssign
	mov	dptr,#_radix
	mov	a,#0x08
	movx	@dptr,a
;vprintf.c:456: break;
;vprintf.c:458: case 'U':
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00153$
00149$:
;vprintf.c:459: radix = 10;
;     genAssign
	mov	dptr,#_radix
	mov	a,#0x0A
	movx	@dptr,a
;vprintf.c:460: break;
;vprintf.c:462: case 'X':
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00153$
00150$:
;vprintf.c:463: radix = 16;
;     genAssign
	mov	dptr,#_radix
	mov	a,#0x10
	movx	@dptr,a
;vprintf.c:464: break;
;vprintf.c:466: case 'F':
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00153$
00151$:
;vprintf.c:467: float_argument=1;
;     genAssign
	setb	_vsprintf_float_argument_1_1
;vprintf.c:468: break;
;vprintf.c:470: default:
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00153$
00152$:
;vprintf.c:472: output_char( c );
;     genCall
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	dpl,@r0
	lcall	_output_char
;vprintf.c:474: }
00153$:
;vprintf.c:476: if (float_argument) {
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_float_argument_1_1,00216$
00342$:
;vprintf.c:477: value.f=va_arg(ap,float);
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
;     genMinusDec
	mov	a,@r1
	add	a,#0xfc
	mov	r0,a
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	@r1,ar0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
	dec	r0
	dec	r0
	dec	r0
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r3
	mov	(_value + 1),r4
	mov	(_value + 2),r5
	mov	(_value + 3),r6
;vprintf.c:479: PTR="<NO FLOAT>";
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,#__str_0
	mov	(_value + 1),#(__str_0 >> 8)
	mov	(_value + 2),#0x02
;vprintf.c:480: while (c=*PTR++)
00154$:
;     genPointerGet
;     genNearPointerGet
;     genDataPointerGet
	mov	r2,_value
	mov	r4,(_value + 1)
	mov	r5,(_value + 2)
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r6,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r4 instead of ar4
	addc    a,r4
	mov	r7,a
	mov	ar3,r5
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r6
	mov	(_value + 1),r7
	mov	(_value + 2),r3
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
	mov	r3,a
;     genAssign
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	@r0,ar3
;     genIfx
	mov	a,r3
;     genIfxJump
	jnz	00343$
	ljmp	00221$
00343$:
;vprintf.c:481: output_char (c);
;     genCall
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	dpl,@r0
	lcall	_output_char
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00154$
00216$:
;vprintf.c:492: } else if (radix != 0)
;     genAssign
	mov	dptr,#_radix
	movx	a,@dptr
	mov	r3,a
;     genCmpEq
	cjne	r3,#0x00,00344$
	ljmp	00221$
00344$:
;vprintf.c:498: if (char_argument)
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_char_argument_1_1,00165$
00345$:
;vprintf.c:500: value.l = va_arg(ap,char);
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
;     genMinusDec
	mov	a,@r1
	dec	a
	mov	r0,a
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	@r1,ar0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
;     genCast
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
	mov	r6,a
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r3
	mov	(_value + 1),r4
	mov	(_value + 2),r5
	mov	(_value + 3),r6
;vprintf.c:501: if (!signed_argument)
;     genIfx
;     genIfxJump
;       Peephole 112.a  removed ljmp by inverse jump logic
	jb      _vsprintf_signed_argument_1_1,00166$
00346$:
;vprintf.c:503: value.byte[1] = 0x00;
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	(_value + 0x0001),#0x00
;vprintf.c:504: value.byte[2] = 0x00;
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	(_value + 0x0002),#0x00
;vprintf.c:505: value.byte[3] = 0x00;
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	(_value + 0x0003),#0x00
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00166$
00165$:
;vprintf.c:508: else if (long_argument)
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_long_argument_1_1,00162$
00347$:
;vprintf.c:510: value.l = va_arg(ap,long);
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
;     genMinusDec
	mov	a,@r1
	add	a,#0xfc
	mov	r0,a
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	@r1,ar0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
	dec	r0
	dec	r0
	dec	r0
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r3
	mov	(_value + 1),r4
	mov	(_value + 2),r5
	mov	(_value + 3),r6
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00166$
00162$:
;vprintf.c:514: value.l = va_arg(ap,int);
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
;     genMinusDec
	mov	a,@r1
	add	a,#0xfe
	mov	r0,a
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	@r1,ar0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	dec	r0
;     genCast
	mov	a,r4
	rlc	a
	subb	a,acc
	mov	r5,a
	mov	r6,a
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r3
	mov	(_value + 1),r4
	mov	(_value + 2),r5
	mov	(_value + 3),r6
;vprintf.c:515: if (!signed_argument)
;     genIfx
;     genIfxJump
;       Peephole 112.a  removed ljmp by inverse jump logic
	jb      _vsprintf_signed_argument_1_1,00166$
00348$:
;vprintf.c:517: value.byte[2] = 0x00;
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	(_value + 0x0002),#0x00
;vprintf.c:518: value.byte[3] = 0x00;
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	(_value + 0x0003),#0x00
00166$:
;vprintf.c:522: if ( signed_argument )
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_signed_argument_1_1,00171$
00349$:
;vprintf.c:524: if (value.l < 0)
;     genPointerGet
;     genNearPointerGet
;     genDataPointerGet
	mov	r3,_value
	mov	r4,(_value + 1)
	mov	r5,(_value + 2)
	mov	r6,(_value + 3)
;     genCmpLt
;     genCmp
	mov	a,r6
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00168$
00350$:
;vprintf.c:525: value.l = -value.l;
;     genUminus
	clr	c
	clr	a
	subb	a,r3
	mov	r3,a
	clr	a
	subb	a,r4
	mov	r4,a
	clr	a
	subb	a,r5
	mov	r5,a
	clr	a
	subb	a,r6
	mov	r6,a
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	_value,r3
	mov	(_value + 1),r4
	mov	(_value + 2),r5
	mov	(_value + 3),r6
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00171$
00168$:
;vprintf.c:527: signed_argument = 0;
;     genAssign
	clr	_vsprintf_signed_argument_1_1
00171$:
;vprintf.c:531: lsd = 1;
;     genAssign
	setb	_lsd
;vprintf.c:533: do {
;     genAssign
	mov	r3,#0x00
00175$:
;vprintf.c:534: value.byte[4] = 0;
;     genPointerSet
;     genNearPointerSet
;     genDataPointerSet
	mov	(_value + 0x0004),#0x00
;vprintf.c:535: calculate_digit();
;     genCall
	push	ar3
	lcall	_calculate_digit
	pop	ar3
;vprintf.c:549: _endasm;
;     genInline
	  jb _lsd,1$
	  pop b ; b = <lsd>
	  mov a,_value+4 ; a = <msd>
	  swap a
	  orl b,a ; b = <msd><lsd>
	  push b
	  sjmp 2$
1$:
	  mov a,_value+4 ; a = <lsd>
	  push acc
2$:
;vprintf.c:551: length++;
;     genPlus
;     genPlusIncr
	inc	r3
;vprintf.c:552: lsd = ~lsd;
;     genCpl
;       Peephole 167    removed redundant bit moves (c not set to _lsd)
	cpl     _lsd
;vprintf.c:553: } while( (value.byte[0] != 0) || (value.byte[1] != 0) ||
;     genAssign
;     genCmpEq
	mov	a,_value
;       Peephole 162    removed sjmp by inverse jump logic
	jz      00352$
00351$:
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00175$
00352$:
;     genAssign
;     genCmpEq
	mov	a,0x0001 + _value
;       Peephole 162    removed sjmp by inverse jump logic
	jz      00354$
00353$:
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00175$
00354$:
;vprintf.c:554: (value.byte[2] != 0) || (value.byte[3] != 0) );
;     genAssign
;     genCmpEq
	mov	a,0x0002 + _value
;       Peephole 162    removed sjmp by inverse jump logic
	jz      00356$
00355$:
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00175$
00356$:
;     genAssign
;     genCmpEq
	mov	a,0x0003 + _value
	jnz	00357$
	mov	a,#0x01
	sjmp	00358$
00357$:
	clr	a
00358$:
;     genAssign
;     genIfx
;       Peephole 177.d  removed redundant move
	mov     r4,a
	mov     ar2,r3
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00175$
00359$:
;vprintf.c:556: if (width == 0)
;     genCmpEq
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    @r0,#0x00,00179$
;00360$:
;       Peephole 200    removed redundant sjmp
00361$:
;vprintf.c:561: width=1;
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,#0x01
00179$:
;vprintf.c:565: if (!zero_padding && !left_justify)
;     genIfx
;     genIfxJump
;       Peephole 112.a  removed ljmp by inverse jump logic
	jb      _vsprintf_zero_padding_1_1,00184$
00362$:
;     genIfx
;     genIfxJump
;       Peephole 112.a  removed ljmp by inverse jump logic
	jb      _vsprintf_left_justify_1_1,00184$
00363$:
;vprintf.c:567: while ( width > (unsigned char) (length+1) )
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r3,a
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar4,@r0
00180$:
;     genCmpGt
;     genCmp
	clr	c
	mov	a,r3
	subb	a,r4
	clr	a
	rlc	a
	mov	r5,a
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar4
;     genIfx
	mov	a,r5
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00184$
00364$:
;vprintf.c:569: output_char( ' ' );
;     genCall
	mov	dpl,#0x20
	push	ar2
	push	ar3
	push	ar4
	lcall	_output_char
	pop	ar4
	pop	ar3
	pop	ar2
;vprintf.c:570: width--;
;     genMinus
;     genMinusDec
	dec	r4
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00180$
00184$:
;vprintf.c:574: if (signed_argument) // this now means the original value was negative
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_signed_argument_1_1,00194$
00365$:
;vprintf.c:576: output_char( '-' );
;     genCall
	mov	dpl,#0x2D
	push	ar2
	lcall	_output_char
	pop	ar2
;vprintf.c:578: width--;
;     genMinus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genMinusDec
	dec	@r0
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00195$
00194$:
;vprintf.c:580: else if (length != 0)
;     genCmpEq
	cjne	r2,#0x00,00366$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00195$
00366$:
;vprintf.c:583: if (prefix_sign)
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_prefix_sign_1_1,00189$
00367$:
;vprintf.c:585: output_char( '+' );
;     genCall
	mov	dpl,#0x2B
	push	ar2
	lcall	_output_char
	pop	ar2
;vprintf.c:587: width--;
;     genMinus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genMinusDec
	dec	@r0
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00195$
00189$:
;vprintf.c:589: else if (prefix_space)
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_prefix_space_1_1,00195$
00368$:
;vprintf.c:591: output_char( ' ' );
;     genCall
	mov	dpl,#0x20
	push	ar2
	lcall	_output_char
	pop	ar2
;vprintf.c:593: width--;
;     genMinus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genMinusDec
	dec	@r0
00195$:
;vprintf.c:598: if (!left_justify)
;     genIfx
;     genIfxJump
;       Peephole 112.a  removed ljmp by inverse jump logic
	jb      _vsprintf_left_justify_1_1,00203$
00369$:
;vprintf.c:599: while ( width-- > length )
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar3,@r0
00196$:
;     genAssign
	mov	ar4,r3
;     genMinus
;     genMinusDec
	dec	r3
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar3
;     genCmpGt
;     genCmp
	clr	c
	mov	a,r2
	subb	a,r4
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00299$
00370$:
;vprintf.c:601: output_char( zero_padding ? '0' : ' ' );
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _vsprintf_zero_padding_1_1,00231$
00371$:
;     genAssign
	mov	r4,#0x30
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00232$
00231$:
;     genAssign
	mov	r4,#0x20
00232$:
;     genCall
	mov	dpl,r4
	push	ar2
	push	ar3
	lcall	_output_char
	pop	ar3
	pop	ar2
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00196$
00203$:
;vprintf.c:606: if (width > length)
;     genCmpGt
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00200$
00372$:
;vprintf.c:607: width -= length;
;     genMinus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	clr	c
;       Peephole 236.l  used r2 instead of ar2
	subb    a,r2
	mov	@r0,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00299$
00200$:
;vprintf.c:609: width = 0;
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,#0x00
;vprintf.c:613: while( length-- )
00299$:
;     genAssign
00205$:
;     genAssign
	mov	ar3,r2
;     genMinus
;     genMinusDec
	dec	r2
;     genIfx
	mov	a,r3
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00207$
00373$:
;vprintf.c:615: lsd = ~lsd;
;     genCpl
;       Peephole 167    removed redundant bit moves (c not set to _lsd)
	cpl     _lsd
;vprintf.c:630: _endasm;
;     genInline
	  jb _lsd,3$
	  pop acc ; a = <msd><lsd>
	  nop ; to disable the "optimizer"
	  push acc
	  swap a
	  anl a,#0x0F ; a = <msd>
	  sjmp 4$
3$:
	  pop acc
	  anl a,#0x0F ; a = <lsd>
4$:
	  mov _value+4,a
;vprintf.c:632: output_digit( value.byte[4] );
;     genAssign
;     genCall
	mov	dpl,0x0004 + _value
	push	ar2
	lcall	_output_digit
	pop	ar2
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00205$
00207$:
;vprintf.c:634: if (left_justify)
;     genIfx
;     genIfxJump
	jb	_vsprintf_left_justify_1_1,00374$
	ljmp	00221$
00374$:
;vprintf.c:635: while (width-- > 0)
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar2,@r0
00208$:
;     genAssign
	mov	ar3,r2
;     genMinus
;     genMinusDec
	dec	r2
;     genCmpGt
;     genCmp
	clr	c
;       Peephole 181    changed mov to clr
	clr     a
	subb	a,r3
;     genIfxJump
	jc	00375$
	ljmp	00221$
00375$:
;vprintf.c:636: output_char(' ');
;     genCall
	mov	dpl,#0x20
	push	ar2
	lcall	_output_char
	pop	ar2
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00208$
00219$:
;vprintf.c:642: output_char( c );
;     genCall
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	dpl,@r0
	lcall	_output_char
	ljmp	00221$
00223$:
;vprintf.c:648: if (output_to_string) {
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     _output_to_string,00225$
00376$:
;vprintf.c:649: output_char(0);
;     genCall
	mov	dpl,#0x00
	lcall	_output_char
;vprintf.c:650: return charsOutputted-1;
;     genAssign
	mov	dptr,#_charsOutputted
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;     genMinus
;     genMinusDec
	dec	r2
	cjne	r2,#0xff,00377$
	dec	r3
00377$:
;     genRet
	mov	dpl,r2
	mov	dph,r3
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00227$
00225$:
;vprintf.c:652: return charsOutputted;
;     genAssign
	mov	dptr,#_charsOutputted
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;     genRet
	mov	dpl,r2
	mov	dph,r3
00227$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vprintf'
;------------------------------------------------------------
;ap                        Allocated to stack - offset -3
;format                    Allocated to registers r2 r3 r4 
;------------------------------------------------------------
;vprintf.c:658: int vprintf (const char *format, va_list ap)
;	-----------------------------------------
;	 function vprintf
;	-----------------------------------------
_vprintf:
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;vprintf.c:660: return vsprintf( 0, format, ap );
;     genIpush
	mov	a,_bp
	add	a,#0xfd
	mov	r0,a
	mov	a,@r0
	push	acc
;     genIpush
	push	ar2
	push	ar3
	push	ar4
;     genCall
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x00
	lcall	_vsprintf
	mov	r2,dpl
	mov	r3,dph
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genRet
	mov	dpl,r2
	mov	dph,r3
00101$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
_memory_id:
	.ascii "IXCP-"
	.db 0x00
__str_0:
	.ascii "<NO FLOAT>"
	.db 0x00
	.area XINIT   (CODE)
