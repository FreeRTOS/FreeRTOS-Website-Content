;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:49 2004
;--------------------------------------------------------
	.module logf
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _logf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'logf'
;------------------------------------------------------------
;x                         Allocated to stack - offset 1
;Rz                        Allocated to stack - offset 5
;f                         Allocated to registers r2 r3 r6 r5 
;z                         Allocated to stack - offset 9
;w                         Allocated to registers r2 r3 r4 r5 
;znum                      Allocated to stack - offset 13
;zden                      Allocated to registers r2 r3 r4 r5 
;xn                        Allocated to stack - offset 17
;n                         Allocated to stack - offset 21
;sloc0                     Allocated to stack - offset 23
;------------------------------------------------------------
;logf.c:37: float logf(const float x) reentrant
;	-----------------------------------------
;	 function logf
;	-----------------------------------------
_logf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x1a
	mov	sp,a
;logf.c:47: if (x<=0.0)
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsgt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIfx
	mov	a,r6
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00110$:
;logf.c:49: errno=EDOM;
;     genAssign
;       Peephole 230    replaced inefficient 16 bit constant
	mov     dptr,#_errno
	mov     a,#0x21
	movx    @dptr,a
	inc     dptr
	clr     a
	movx    @dptr,a
	mov     dptr,#_errno
;logf.c:50: return 0.0;
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00106$
00102$:
;logf.c:52: f=frexpf(x, &n);
;     genAddrOf
	mov	a,_bp
	add	a,#0x15
	mov	r6,a
;     genCast
	mov	r7,#0x00
	mov	r2,#0x0
;     genIpush
	push	ar6
	push	ar7
	push	ar2
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	_frexpf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	dec	sp
	dec	sp
	dec	sp
;     genAssign
	mov	ar6,r4
;logf.c:53: znum=f-0.5;
;     genIpush
	push	ar2
	push	ar3
	push	ar5
	push	ar6
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r6
	mov	a,r5
	lcall	___fssub
	push	acc
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;     genAssign
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;logf.c:54: if (f>C0)
;     genIpush
	push	ar2
	push	ar3
	push	ar5
	push	ar6
	mov	a,#0xF3
	push	acc
	mov	a,#0x04
	push	acc
	mov	a,#0x35
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r6
	mov	a,r5
	lcall	___fsgt
	mov	r4,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r4
;     genIfxJump
	jnz	00111$
	ljmp	00104$
00111$:
;logf.c:56: znum-=0.5;
;     genIpush
	push	ar2
	push	ar3
	push	ar5
	push	ar6
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fssub
	push	acc
	mov	a,_bp
	add	a,#0x17
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;     genAssign
	mov	a,_bp
	add	a,#0x17
	mov	r0,a
	mov	a,_bp
	add	a,#0x0d
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
;logf.c:57: zden=(f*0.5)+0.5;
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r6
	mov	a,r5
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r2
	mov	a,r3
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00105$
00104$:
;logf.c:61: n--;
;     genMinus
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
;     genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
;logf.c:62: zden=znum*0.5+0.5;
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
00105$:
;logf.c:64: z=znum/zden;
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsdiv
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;logf.c:65: w=z*z;
;     genIpush
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
;logf.c:67: Rz=z+z*(w*A(w)/B(w));
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	mov	a,#0x3D
	push	acc
	mov	a,#0x7E
	push	acc
	mov	a,#0x0D
	push	acc
	mov	a,#0xBF
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsmul
	push	acc
	mov	a,_bp
	add	a,#0x17
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;     genIpush
	mov	a,#0x3A
	push	acc
	mov	a,#0x3F
	push	acc
	mov	a,#0xD4
	push	acc
	mov	a,#0xC0
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsadd
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	push	ar4
	push	ar5
	push	ar2
	push	ar3
;     genCall
	mov	a,_bp
	add	a,#0x17
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsdiv
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsadd
	push	acc
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;logf.c:68: xn=n;
;     genCall
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	lcall	___sint2fs
	mov	r6,dpl
	mov	r7,dph
	mov	r2,b
	mov	r3,a
;     genAssign
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;logf.c:69: return ((xn*C2+Rz)+xn*C1);
;     genIpush
	mov	a,#0x83
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x5E
	push	acc
	mov	a,#0xB9
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r2
	mov	a,r3
	lcall	___fsadd
	push	acc
	mov	a,_bp
	add	a,#0x17
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x31
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	push	ar6
	push	ar7
	push	ar2
	push	ar3
;     genCall
	mov	a,_bp
	add	a,#0x17
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00106$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
