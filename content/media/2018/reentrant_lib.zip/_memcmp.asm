;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:42 2004
;--------------------------------------------------------
	.module _memcmp
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memcmp
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'memcmp'
;------------------------------------------------------------
;buf2                      Allocated to stack - offset -5
;count                     Allocated to stack - offset -7
;buf1                      Allocated to stack - offset 1
;------------------------------------------------------------
;_memcmp.c:26: int memcmp (
;	-----------------------------------------
;	 function memcmp
;	-----------------------------------------
_memcmp:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
;_memcmp.c:32: if (!count)
;     genIfx
	mov	a,_bp
	add	a,#0xf9
	mov	r0,a
	mov	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00112$
00113$:
;_memcmp.c:33: return(0);
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	ljmp	00107$
;_memcmp.c:35: while ( --count && *((char *)buf1) == *((char *)buf2) ) {
00112$:
;     genAssign
	mov	a,_bp
	add	a,#0xf9
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
00104$:
;     genMinus
;     genMinusDec
	dec	r5
	cjne	r5,#0xff,00114$
	dec	r6
00114$:
;     genIfx
	mov	a,r5
	orl	a,r6
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00115$:
;     genIpush
	push	ar5
	push	ar6
;     genPointerGet
;     genGenPointerGet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
	mov	r7,a
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
;     genCmpEq
	mov	a,r7
	cjne	a,ar5,00116$
	mov	a,#0x01
	sjmp	00117$
00116$:
	clr	a
00117$:
;     genIpop
	pop	ar6
	pop	ar5
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00118$:
;_memcmp.c:36: buf1 = (char *)buf1 + 1;
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_memcmp.c:37: buf2 = (char *)buf2 + 1;
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar4
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00104$
00106$:
;_memcmp.c:40: return( *((unsigned char *)buf1) - *((unsigned char *)buf2) );
;     genPointerGet
;     genGenPointerGet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
	mov	r2,a
;     genCast
	mov	r3,#0x00
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	r4,a
;     genCast
	mov	r5,#0x00
;     genMinus
	mov	a,r2
	clr	c
;       Peephole 236.l  used r4 instead of ar4
	subb    a,r4
	mov	r2,a
	mov	a,r3
;       Peephole 236.l  used r5 instead of ar5
	subb    a,r5
	mov	r3,a
;     genRet
	mov	dpl,r2
	mov	dph,r3
00107$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
