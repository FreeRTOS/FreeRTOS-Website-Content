;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:38 2004
;--------------------------------------------------------
	.module _fs2slong
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fs2slong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fs2slong'
;------------------------------------------------------------
;f                         Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;_fs2slong.c:4: signed long __fs2slong (float f) {
;	-----------------------------------------
;	 function __fs2slong
;	-----------------------------------------
___fs2slong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;_fs2slong.c:6: if (!f)
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00110$:
;_fs2slong.c:7: return 0;
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00106$
00102$:
;_fs2slong.c:9: if (f<0) {
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fslt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r6
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00104$
00111$:
;_fs2slong.c:10: return -__fs2ulong(-f);
;     genUminus
;     genUminusFloat
	mov	ar6,r2
	mov	ar7,r3
	mov	ar0,r4
	mov	a,r5
	cpl	acc.7
;     genCall
;       Peephole 191    removed redundant mov
	mov     r1,a
	mov     dpl,r6
	mov     dph,r7
	mov     b,r0
	lcall	___fs2ulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
;     genUminus
	clr	c
	clr	a
	subb	a,r6
	mov	r6,a
	clr	a
	subb	a,r7
	mov	r7,a
	clr	a
	subb	a,r0
	mov	r0,a
	clr	a
	subb	a,r1
;     genRet
;       Peephole 191    removed redundant mov
	mov     r1,a
	mov     dpl,r6
	mov     dph,r7
	mov     b,r0
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00106$
00104$:
;_fs2slong.c:12: return __fs2ulong(f);
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fs2ulong
;     genRet
;       Peephole 191    removed redundant mov
	mov     r2,dpl
	mov     r3,dph
	mov     r4,b
	mov     r5,a
;       Peephole 238.b  removed 3 redundant moves
00106$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
