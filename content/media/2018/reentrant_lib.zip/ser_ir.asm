;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:51 2004
;--------------------------------------------------------
	.module ser_ir
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _CY
	.globl _AC
	.globl _F0
	.globl _RS1
	.globl _RS0
	.globl _OV
	.globl _F1
	.globl _P
	.globl _PS
	.globl _PT1
	.globl _PX1
	.globl _PT0
	.globl _PX0
	.globl _RD
	.globl _WR
	.globl _T1
	.globl _T0
	.globl _INT1
	.globl _INT0
	.globl _TXD
	.globl _RXD
	.globl _P3_7
	.globl _P3_6
	.globl _P3_5
	.globl _P3_4
	.globl _P3_3
	.globl _P3_2
	.globl _P3_1
	.globl _P3_0
	.globl _EA
	.globl _ES
	.globl _ET1
	.globl _EX1
	.globl _ET0
	.globl _EX0
	.globl _P2_7
	.globl _P2_6
	.globl _P2_5
	.globl _P2_4
	.globl _P2_3
	.globl _P2_2
	.globl _P2_1
	.globl _P2_0
	.globl _SM0
	.globl _SM1
	.globl _SM2
	.globl _REN
	.globl _TB8
	.globl _RB8
	.globl _TI
	.globl _RI
	.globl _P1_7
	.globl _P1_6
	.globl _P1_5
	.globl _P1_4
	.globl _P1_3
	.globl _P1_2
	.globl _P1_1
	.globl _P1_0
	.globl _TF1
	.globl _TR1
	.globl _TF0
	.globl _TR0
	.globl _IE1
	.globl _IT1
	.globl _IE0
	.globl _IT0
	.globl _P0_7
	.globl _P0_6
	.globl _P0_5
	.globl _P0_4
	.globl _P0_3
	.globl _P0_2
	.globl _P0_1
	.globl _P0_0
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _IP
	.globl _P3
	.globl _IE
	.globl _P2
	.globl _SBUF
	.globl _SCON
	.globl _P1
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _PCON
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _P0
	.globl _ser_init
	.globl _ser_handler
	.globl _ser_putc
	.globl _ser_getc
	.globl _ser_puts
	.globl _ser_gets
	.globl _ser_can_xmt
	.globl _ser_can_rcv
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_P1	=	0x0090
_SCON	=	0x0098
_SBUF	=	0x0099
_P2	=	0x00a0
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_RI	=	0x0098
_TI	=	0x0099
_RB8	=	0x009a
_TB8	=	0x009b
_REN	=	0x009c
_SM2	=	0x009d
_SM1	=	0x009e
_SM0	=	0x009f
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES	=	0x00ac
_EA	=	0x00af
_P3_0	=	0x00b0
_P3_1	=	0x00b1
_P3_2	=	0x00b2
_P3_3	=	0x00b3
_P3_4	=	0x00b4
_P3_5	=	0x00b5
_P3_6	=	0x00b6
_P3_7	=	0x00b7
_RXD	=	0x00b0
_TXD	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS	=	0x00bc
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_rbuf:
	.ds 10
_xbuf:
	.ds 10
_rcnt:
	.ds 1
_xcnt:
	.ds 1
_rpos:
	.ds 1
_xpos:
	.ds 1
_busy:
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_init'
;------------------------------------------------------------
;------------------------------------------------------------
;ser_ir.c:49: void ser_init (void)
;	-----------------------------------------
;	 function ser_init
;	-----------------------------------------
_ser_init:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;ser_ir.c:51: ES = 0;
;     genAssign
	clr	_ES
;ser_ir.c:52: rcnt = xcnt = rpos = xpos = 0;  /* init buffers */
;     genAssign
	mov	dptr,#_xpos
;       Peephole 181    changed mov to clr
;     genAssign
;       Peephole 181    changed mov to clr
;       Peephole 219    removed redundant clear
;     genAssign
;       Peephole 181    changed mov to clr
;     genAssign
;       Peephole 181    changed mov to clr
;       Peephole 219    removed redundant clear
;       Peephole 219.a  removed redundant clear
	clr     a
	movx    @dptr,a
	mov     dptr,#_rpos
	movx    @dptr,a
	mov     dptr,#_xcnt
	movx    @dptr,a
	mov     dptr,#_rcnt
	movx    @dptr,a
;ser_ir.c:53: busy = 0;
;     genAssign
	mov	dptr,#_busy
;       Peephole 181    changed mov to clr
	clr     a
	movx	@dptr,a
;ser_ir.c:54: SCON = 0x50;
;     genAssign
	mov	_SCON,#0x50
;ser_ir.c:55: PCON |= 0x80;                   /* SMOD = 1; */
;     genOr
	orl	_PCON,#0x80
;ser_ir.c:56: TMOD &= 0x0f;                   /* use timer 1 */
;     genAnd
	anl	_TMOD,#0x0F
;ser_ir.c:57: TMOD |= 0x20;
;     genOr
	orl	_TMOD,#0x20
;ser_ir.c:58: TL1 = -3; TH1 = -3; TR1 = 1;    /* 19200bps with 11.059MHz crystal */
;     genAssign
	mov	_TL1,#0xFD
;     genAssign
	mov	_TH1,#0xFD
;     genAssign
	setb	_TR1
;ser_ir.c:59: ES = 1;
;     genAssign
	setb	_ES
00101$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_handler'
;------------------------------------------------------------
;------------------------------------------------------------
;ser_ir.c:62: void ser_handler (void) interrupt 4
;	-----------------------------------------
;	 function ser_handler
;	-----------------------------------------
_ser_handler:
	push	acc
	push	dpl
	push	dph
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	psw
	mov	psw,#0x00
	push	_bp
	mov	_bp,sp
;ser_ir.c:64: if (RI) {
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
;ser_ir.c:65: RI = 0;
;     genAssign
;       Peephole 250.a  using atomic test and clear
	jbc     _RI,00118$
	sjmp    00104$
00118$:
;ser_ir.c:67: if (rcnt < RBUFLEN)
;     genAssign
	mov	dptr,#_rcnt
	movx	a,@dptr
	mov	r2,a
;     genCmpLt
;     genCmp
	cjne	r2,#0x0A,00119$
00119$:
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00104$
00120$:
;ser_ir.c:68: rbuf [(rpos+rcnt++) % RBUFLEN] = SBUF;
;     genAssign
	mov	dptr,#_rpos
	movx	a,@dptr
	mov	r3,a
;     genCast
	mov	r4,#0x00
;     genAssign
	mov	ar5,r2
;     genPlus
	mov	dptr,#_rcnt
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	movx	@dptr,a
;     genCast
	mov	r2,#0x00
;     genPlus
;       Peephole 236.g  used r5 instead of ar5
	mov     a,r5
;       Peephole 236.a  used r3 instead of ar3
	add     a,r3
	mov	r3,a
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
;       Peephole 236.b  used r4 instead of ar4
	addc    a,r4
	mov	r4,a
;     genIpush
	mov	a,#0x0A
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
	mov	dpl,r3
	mov	dph,r4
	lcall	__modsint
	mov	r2,dpl
	mov	r3,dph
	dec	sp
	dec	sp
;     genPlus
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,#_rbuf
	mov	dpl,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	addc	a,#(_rbuf >> 8)
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
	mov	a,_SBUF
	movx	@dptr,a
00104$:
;ser_ir.c:70: if (TI) {
;     genIfx
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
;ser_ir.c:71: TI = 0;
;     genAssign
;       Peephole 250.a  using atomic test and clear
	jbc     _TI,00121$
	sjmp    00111$
00121$:
;ser_ir.c:72: if (busy = xcnt) {   /* Assignment, _not_ comparison! */
;     genAssign
	mov	dptr,#_xcnt
	movx	a,@dptr
;     genAssign
;       Peephole 100    removed redundant mov
	mov     r2,a
	mov     dptr,#_busy
	movx    @dptr,a
;     genIfx
	mov	a,r2
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00111$
00122$:
;ser_ir.c:73: xcnt--;
;     genMinus
;     genMinusDec
	mov	a,r2
	dec	a
;     genAssign
	mov	dptr,#_xcnt
	movx	@dptr,a
;ser_ir.c:74: SBUF = xbuf [xpos++];
;     genAssign
	mov	dptr,#_xpos
	movx	a,@dptr
	mov	r2,a
;     genPlus
	mov	dptr,#_xpos
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	movx	@dptr,a
;     genPlus
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,#_xbuf
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
	addc	a,#(_xbuf >> 8)
	mov	dph,a
;     genPointerGet
;     genFarPointerGet
	movx	a,@dptr
	mov	_SBUF,a
;ser_ir.c:75: if (xpos >= XBUFLEN)
;     genAssign
	mov	dptr,#_xpos
	movx	a,@dptr
	mov	r2,a
;     genCmpLt
;     genCmp
	cjne	r2,#0x0A,00123$
00123$:
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00111$
00124$:
;ser_ir.c:76: xpos = 0;
;     genAssign
	mov	dptr,#_xpos
;       Peephole 181    changed mov to clr
	clr     a
	movx	@dptr,a
00111$:
	mov	sp,_bp
	pop	_bp
	pop	psw
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
	pop	dph
	pop	dpl
	pop	acc
	reti
;	eliminated unneeded push/pop b
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_putc'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;ser_ir.c:81: void ser_putc (unsigned char c)
;	-----------------------------------------
;	 function ser_putc
;	-----------------------------------------
_ser_putc:
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
;ser_ir.c:83: while (xcnt >= XBUFLEN) /* wait for room in buffer */
00101$:
;     genAssign
	mov	dptr,#_xcnt
	movx	a,@dptr
	mov	r3,a
;     genCmpLt
;     genCmp
	cjne	r3,#0x0A,00112$
00112$:
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00101$
00113$:
;ser_ir.c:85: ES = 0;
;     genAssign
	clr	_ES
;ser_ir.c:86: if (busy) {
;     genAssign
	mov	dptr,#_busy
	movx	a,@dptr
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r4,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00105$
00114$:
;ser_ir.c:87: xbuf[(xpos+xcnt++) % XBUFLEN] = c;
;     genAssign
	mov	dptr,#_xpos
	movx	a,@dptr
	mov	r4,a
;     genCast
	mov	r5,#0x00
;     genAssign
	mov	ar6,r3
;     genPlus
	mov	dptr,#_xcnt
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r3 instead of ar3
	add     a,r3
	movx	@dptr,a
;     genCast
	mov	r3,#0x00
;     genPlus
;       Peephole 236.g  used r6 instead of ar6
	mov     a,r6
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	r4,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
;       Peephole 236.b  used r5 instead of ar5
	addc    a,r5
	mov	r5,a
;     genIpush
	push	ar2
	mov	a,#0x0A
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
	mov	dpl,r4
	mov	dph,r5
	lcall	__modsint
	mov	r3,dpl
	mov	r4,dph
	dec	sp
	dec	sp
	pop	ar2
;     genPlus
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	add	a,#_xbuf
	mov	dpl,a
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
	addc	a,#(_xbuf >> 8)
	mov	dph,a
;     genPointerSet
;     genFarPointerSet
	mov	a,r2
	movx	@dptr,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00106$
00105$:
;ser_ir.c:89: SBUF = c;
;     genAssign
	mov	_SBUF,r2
;ser_ir.c:90: busy = 1;
;     genAssign
	mov	dptr,#_busy
	mov	a,#0x01
	movx	@dptr,a
00106$:
;ser_ir.c:92: ES = 1;
;     genAssign
	setb	_ES
00107$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_getc'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;ser_ir.c:95: unsigned char ser_getc (void)
;	-----------------------------------------
;	 function ser_getc
;	-----------------------------------------
_ser_getc:
	push	_bp
	mov	_bp,sp
;ser_ir.c:98: while (!rcnt)   /* wait for character */
00101$:
;     genAssign
	mov	dptr,#_rcnt
	movx	a,@dptr
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r2,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00101$
00111$:
;ser_ir.c:100: ES = 0;
;     genAssign
	clr	_ES
;ser_ir.c:101: rcnt--;
;     genMinus
;     genMinusDec
	mov	a,r2
	dec	a
;     genAssign
	mov	dptr,#_rcnt
	movx	@dptr,a
;ser_ir.c:102: c = rbuf [rpos++];
;     genAssign
	mov	dptr,#_rpos
	movx	a,@dptr
	mov	r2,a
;     genPlus
	mov	dptr,#_rpos
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	movx	@dptr,a
;     genPlus
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,#_rbuf
	mov	dpl,a
;       Peephole 181    changed mov to clr
	clr     a
	addc	a,#(_rbuf >> 8)
	mov	dph,a
;     genPointerGet
;     genFarPointerGet
	movx	a,@dptr
	mov	r2,a
;     genAssign
;ser_ir.c:103: if (rpos >= RBUFLEN)
;     genAssign
	mov	dptr,#_rpos
	movx	a,@dptr
	mov	r3,a
;     genCmpLt
;     genCmp
	cjne	r3,#0x0A,00112$
00112$:
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00105$
00113$:
;ser_ir.c:104: rpos = 0;
;     genAssign
	mov	dptr,#_rpos
;       Peephole 181    changed mov to clr
	clr     a
	movx	@dptr,a
00105$:
;ser_ir.c:105: ES = 1;
;     genAssign
	setb	_ES
;ser_ir.c:106: return (c);
;     genRet
	mov	dpl,r2
00106$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_puts'
;------------------------------------------------------------
;s                         Allocated to registers r2 r3 r4 
;c                         Allocated to registers r6 
;------------------------------------------------------------
;ser_ir.c:110: void ser_puts (unsigned char *s)
;	-----------------------------------------
;	 function ser_puts
;	-----------------------------------------
_ser_puts:
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;ser_ir.c:113: while (c=*s++) {
00103$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
;     genAssign
	mov	ar6,r5
;     genIfx
	mov	a,r5
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00111$:
;ser_ir.c:114: if (c == '\n') ser_putc ('\r');
;     genCmpEq
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    r6,#0x0A,00102$
;00112$:
;       Peephole 200    removed redundant sjmp
00113$:
;     genCall
	mov	dpl,#0x0D
	push	ar2
	push	ar3
	push	ar4
	push	ar6
	lcall	_ser_putc
	pop	ar6
	pop	ar4
	pop	ar3
	pop	ar2
00102$:
;ser_ir.c:115: ser_putc (c);
;     genCall
	mov	dpl,r6
	push	ar2
	push	ar3
	push	ar4
	lcall	_ser_putc
	pop	ar4
	pop	ar3
	pop	ar2
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00103$
00106$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_gets'
;------------------------------------------------------------
;len                       Allocated to stack - offset -3
;s                         Allocated to stack - offset 1
;pos                       Allocated to registers r5 
;c                         Allocated to registers r6 
;------------------------------------------------------------
;ser_ir.c:119: void ser_gets (unsigned char *s, unsigned char len)
;	-----------------------------------------
;	 function ser_gets
;	-----------------------------------------
_ser_gets:
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
;ser_ir.c:124: while (pos <= len) {
;     genAssign
	mov	r5,#0x00
00105$:
;     genCmpGt
	mov	a,_bp
	add	a,#0xfd
	mov	r0,a
;     genCmp
	clr	c
	mov	a,@r0
	subb	a,r5
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00107$
00113$:
;ser_ir.c:125: c = ser_getc ();
;     genCall
	push	ar5
	lcall	_ser_getc
	mov	r6,dpl
	pop	ar5
;     genAssign
;ser_ir.c:126: if (c == '\r') continue;        /* discard CR's */
;     genCmpEq
	cjne	r6,#0x0D,00114$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00105$
00114$:
;ser_ir.c:127: s[pos++] = c;
;     genAssign
	mov	ar7,r5
;     genPlus
;     genPlusIncr
	inc	r5
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;       Peephole 236.g  used r7 instead of ar7
	mov     a,r7
	add	a,@r0
	mov	r7,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r2,a
	inc	r0
	mov	ar3,@r0
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	mov	a,r6
	lcall	__gptrput
;ser_ir.c:128: if (c == '\n') break;           /* NL terminates */
;     genCmpEq
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    r6,#0x0A,00105$
;00115$:
;       Peephole 200    removed redundant sjmp
00116$:
00107$:
;ser_ir.c:130: s[pos] = '\0';
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;       Peephole 236.g  used r5 instead of ar5
	mov     a,r5
	add	a,@r0
	mov	r5,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r2,a
	inc	r0
	mov	ar3,@r0
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r5
	mov	dph,r2
	mov	b,r3
;       Peephole 181    changed mov to clr
	clr     a
	lcall	__gptrput
00108$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_can_xmt'
;------------------------------------------------------------
;------------------------------------------------------------
;ser_ir.c:133: unsigned char ser_can_xmt (void)
;	-----------------------------------------
;	 function ser_can_xmt
;	-----------------------------------------
_ser_can_xmt:
	push	_bp
	mov	_bp,sp
;ser_ir.c:135: return XBUFLEN - xcnt;
;     genAssign
	mov	dptr,#_xcnt
	movx	a,@dptr
	mov	r2,a
;     genMinus
	mov	a,#0x0A
	clr	c
;       Peephole 236.l  used r2 instead of ar2
	subb    a,r2
;     genRet
;       Peephole 244.c  loading dpl from a instead of r2
	mov	r2,a
	mov	dpl,a
00101$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_can_rcv'
;------------------------------------------------------------
;------------------------------------------------------------
;ser_ir.c:138: unsigned char ser_can_rcv (void)
;	-----------------------------------------
;	 function ser_can_rcv
;	-----------------------------------------
_ser_can_rcv:
	push	_bp
	mov	_bp,sp
;ser_ir.c:140: return rcnt;
;     genAssign
	mov	dptr,#_rcnt
	movx	a,@dptr
;     genRet
;       Peephole 244.c  loading dpl from a instead of r2
	mov	r2,a
	mov	dpl,a
00101$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
