;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:41 2004
;--------------------------------------------------------
	.module _ispunct
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ispunct
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ispunct'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;_ispunct.c:25: char ispunct (unsigned char c) 
;	-----------------------------------------
;	 function ispunct
;	-----------------------------------------
_ispunct:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
;_ispunct.c:28: if (isprint (c)    && 
;     genCall
;       Peephole 177.a  removed redundant mov
	mov  r2,dpl
	push	ar2
	lcall	_isprint
	mov	a,dpl
	pop	ar2
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00114$:
;_ispunct.c:29: !islower(c)     && 
;     genCall
	mov	dpl,r2
	push	ar2
	lcall	_islower
	mov	a,dpl
	pop	ar2
;     genIfx
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00115$:
;_ispunct.c:30: !isupper(c)     &&
;     genCall
	mov	dpl,r2
	push	ar2
	lcall	_isupper
	mov	a,dpl
	pop	ar2
;     genIfx
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00116$:
;_ispunct.c:31: c != ' '        &&
;     genCmpEq
	cjne	r2,#0x20,00117$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00102$
00117$:
;_ispunct.c:32: !isdigit(c)) 
;     genCall
	mov	dpl,r2
	lcall	_isdigit
	mov	a,dpl
;     genIfx
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00118$:
;_ispunct.c:33: return 1;
;     genRet
	mov	dpl,#0x01
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00107$
00102$:
;_ispunct.c:34: return 0;
;     genRet
	mov	dpl,#0x00
00107$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
