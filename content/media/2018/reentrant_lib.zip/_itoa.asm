;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:41 2004
;--------------------------------------------------------
	.module _itoa
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __itoa
	.globl __uitoa
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_uitoa'
;------------------------------------------------------------
;string                    Allocated to stack - offset -5
;radix                     Allocated to stack - offset -6
;value                     Allocated to registers r2 r3 
;index                     Allocated to stack - offset 1
;i                         Allocated to stack - offset 2
;sloc0                     Allocated to stack - offset 3
;------------------------------------------------------------
;_itoa.c:18: void _uitoa(unsigned int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _uitoa
;	-----------------------------------------
__uitoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
	mov	a,sp
	add	a,#0x04
	mov	sp,a
;     genReceive
	mov	r2,dpl
	mov	r3,dph
;_itoa.c:26: do {
;     genAssign
	mov	r4,#0x10
00103$:
;_itoa.c:27: string[--index] = '0' + (value % radix);
;     genMinus
;     genMinusDec
	dec	r4
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
	add	a,@r0
	mov	r5,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r6,a
	inc	r0
	mov	ar7,@r0
;     genCast
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,_bp
	add	a,#0x03
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r1
	mov	@r1,#0x00
;     genIpush
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genIpush
	push	ar2
	push	ar3
;     genCall
	mov	dpl,r2
	mov	dph,r3
	lcall	__moduint
	mov	r2,dpl
	mov	r3,dph
	dec	sp
	dec	sp
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
;     genCast
;     genPlus
	mov	a,#0x30
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
;     genPointerSet
;     genGenPointerSet
;       Peephole 191    removed redundant mov
	mov     r2,a
	mov     dpl,r5
	mov     dph,r6
	mov     b,r7
	lcall	__gptrput
;_itoa.c:28: if ( string[index] > '9') string[index] += 'A' - '9' - 1;
;     genCmpGt
;     genCmp
	clr	c
	mov	a,#0x39
	subb	a,r2
	clr	a
	rlc	a
;     genIpop
	pop	ar3
	pop	ar2
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00115$:
;     genIpush
	push	ar4
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r4,a
;     genPlus
	mov	a,#0x07
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
;     genPointerSet
;     genGenPointerSet
;       Peephole 191    removed redundant mov
	mov     r4,a
	mov     dpl,r5
	mov     dph,r6
	mov     b,r7
	lcall	__gptrput
;_itoa.c:36: string[i] = 0; /* string terminator */
;     genIpop
	pop	ar4
;_itoa.c:28: if ( string[index] > '9') string[index] += 'A' - '9' - 1;
00102$:
;_itoa.c:29: value /= radix;
;     genIpush
	push	ar4
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	lcall	__divuint
	mov	r2,dpl
	mov	r3,dph
	dec	sp
	dec	sp
	pop	ar4
;_itoa.c:30: } while (value != 0);
;     genCmpEq
	cjne	r2,#0x00,00116$
	cjne	r3,#0x00,00116$
	sjmp	00117$
00116$:
	ljmp	00103$
00117$:
;_itoa.c:32: do {
;     genAssign
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	@r0,#0x00
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar4
00106$:
;_itoa.c:33: string[i++] = string[index++];
;     genAssign
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
	mov	ar4,@r0
;     genPlus
	mov	a,_bp
	add	a,#0x02
	mov	r0,a
;     genPlusIncr
	inc	@r0
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
	add	a,@r0
	mov	r4,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r5,a
	inc	r0
	mov	ar6,@r0
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar7,@r0
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPlusIncr
	inc	@r0
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;       Peephole 236.g  used r7 instead of ar7
	mov     a,r7
	add	a,@r0
	mov	r7,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r2,a
	inc	r0
	mov	ar3,@r0
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
;     genPointerSet
;     genGenPointerSet
;       Peephole 191    removed redundant mov
	mov     r7,a
	mov     dpl,r4
	mov     dph,r5
	mov     b,r6
	lcall	__gptrput
;_itoa.c:34: } while ( index < NUMBER_OF_DIGITS );
;     genCmpLt
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genCmp
	cjne	@r0,#0x10,00118$
00118$:
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00106$
00119$:
;_itoa.c:36: string[i] = 0; /* string terminator */
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	a,_bp
	add	a,#0x02
	mov	r1,a
	mov	a,@r1
	add	a,@r0
	mov	r2,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r3,a
	inc	r0
	mov	ar4,@r0
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;       Peephole 181    changed mov to clr
	clr     a
	lcall	__gptrput
00109$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function '_itoa'
;------------------------------------------------------------
;string                    Allocated to stack - offset -5
;radix                     Allocated to stack - offset -6
;value                     Allocated to registers r2 r3 
;------------------------------------------------------------
;_itoa.c:39: void _itoa(int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _itoa
;	-----------------------------------------
__itoa:
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
;_itoa.c:41: if (value < 0 && radix == 10) {
;     genCmpLt
;     genCmp
;       Peephole 244.b  moving first to a instead of r3
	mov	a,dph
	mov	r3,a
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00102$
00109$:
;     genCmpEq
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    @r0,#0x0A,00102$
;00110$:
;       Peephole 200    removed redundant sjmp
00111$:
;_itoa.c:42: *string++ = '-';
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,#0x2D
	lcall	__gptrput
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r5 instead of ar5
	addc    a,r5
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar6
;_itoa.c:43: _uitoa(-value, string, radix);
;     genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r4,a
	clr	a
	subb	a,r3
	mov	r5,a
;     genIpush
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,@r0
	push	acc
;     genIpush
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r4
	mov	dph,r5
	lcall	__uitoa
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00105$
00102$:
;_itoa.c:46: _uitoa(value, string, radix);
;     genIpush
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,@r0
	push	acc
;     genIpush
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	lcall	__uitoa
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
00105$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
