;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:56 2004
;--------------------------------------------------------
	.module _mulint
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __mulint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_mulint'
;------------------------------------------------------------
;b                         Allocated to stack - offset -4
;a                         Allocated to stack - offset 1
;x                         Allocated to stack - offset 3
;y                         Allocated to registers r2 r3 r4 
;t                         Allocated to stack - offset 6
;------------------------------------------------------------
;_mulint.c:213: _mulint (int a, int b)
;	-----------------------------------------
;	 function _mulint
;	-----------------------------------------
__mulint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	mov	a,sp
	add	a,#0x07
	mov	sp,a
;_mulint.c:225: x = (union uu *)&a;
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r2,_bp
	inc     r2
;     genCast
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x0
;_mulint.c:226: y = (union uu *)&b;
;     genAddrOf
	mov	a,_bp
	add	a,#0xfc
	mov	r5,a
;     genCast
	mov	ar2,r5
	mov	r3,#0x00
	mov	r4,#0x0
;_mulint.c:229: t.t = x->s.lo * y->s.lo;
;     genAddrOf
	mov	a,_bp
	add	a,#0x06
	mov	r0,a
;     genPointerGet
;     genGenPointerGet
	mov	a,_bp
	add	a,#0x03
	mov	r1,a
	mov	dpl,@r1
	inc	r1
	mov	dph,@r1
	inc	r1
	mov	b,@r1
	lcall	__gptrget
	mov	r5,a
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;     genMult
;     genMultOneByte
;       Peephole 177.d  removed redundant move
	mov     r6,a
	mov     b,r5
	mul	ab
;     genPointerSet
;     genNearPointerSet
	mov	@r0,acc
	inc	r0
	mov	@r0,b
	dec	r0
;_mulint.c:230: t.s.hi += (x->s.lo * y->s.hi) + (x->s.hi * y->s.lo);
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r0 instead of ar0
	add     a,r0
	mov	r1,a
;     genPointerGet
;     genNearPointerGet
	mov	ar7,@r1
;     genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00103$
	inc	r3
00103$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;     genMult
;     genMultOneByte
;       Peephole 177.d  removed redundant move
	mov     r2,a
	mov     b,r5
	mul	ab
	mov	r5,a
;     genPlus
	push	ar0
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	r2,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r3,a
	inc	r0
	mov	ar4,@r0
	pop	ar0
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
;     genMult
;     genMultOneByte
	mov	b,r2
	mov	a,r6
	mul	ab
;     genPlus
;       Peephole 236.a  used r5 instead of ar5
	add     a,r5
;     genPlus
;       Peephole 236.a  used r7 instead of ar7
	add     a,r7
;     genPointerSet
;     genNearPointerSet
	mov	@r1,acc
;_mulint.c:232: return t.t;
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
00101$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
