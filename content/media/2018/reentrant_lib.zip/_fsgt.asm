;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:55 2004
;--------------------------------------------------------
	.module _fsgt
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsgt
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsgt'
;------------------------------------------------------------
;a2                        Allocated to stack - offset -6
;a1                        Allocated to registers r2 r3 r4 r5 
;fl1                       Allocated to stack - offset 1
;fl2                       Allocated to stack - offset 5
;sloc0                     Allocated to stack - offset 9
;------------------------------------------------------------
;_fsgt.c:28: char __fsgt (float a1, float a2)
;	-----------------------------------------
;	 function __fsgt
;	-----------------------------------------
___fsgt:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0x0c
	mov	sp,a
;_fsgt.c:32: fl1.f = a1;
;     genAddrOf
	mov	a,_bp
	add	a,#0x01
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_fsgt.c:33: fl2.f = a2;
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
;_fsgt.c:35: if (fl1.l<0 && fl2.l<0) {
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genCmpLt
;     genCmp
	mov	a,r5
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00104$
00114$:
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genCmpLt
;     genCmp
	mov	a,r5
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00104$
00115$:
;_fsgt.c:36: if (fl2.l > fl1.l)
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
;     genCmpGt
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r6
	subb	a,@r0
	mov	a,r7
	inc	r0
	subb	a,@r0
	mov	a,r2
	inc	r0
	subb	a,@r0
	mov	a,r3
	xrl	a,#0x80
	inc	r0
	mov	b,@r0
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00102$
00116$:
;_fsgt.c:37: return (1);
;     genRet
	mov	dpl,#0x01
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00108$
00102$:
;_fsgt.c:38: return (0);
;     genRet
	mov	dpl,#0x00
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00108$
00104$:
;_fsgt.c:41: if (fl1.l > fl2.l)
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
;     genCmpGt
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r6
	subb	a,@r0
	mov	a,r7
	inc	r0
	subb	a,@r0
	mov	a,r2
	inc	r0
	subb	a,@r0
	mov	a,r3
	xrl	a,#0x80
	inc	r0
	mov	b,@r0
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00107$
00117$:
;_fsgt.c:42: return (1);
;     genRet
	mov	dpl,#0x01
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00108$
00107$:
;_fsgt.c:43: return (0);
;     genRet
	mov	dpl,#0x00
00108$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
