;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:55 2004
;--------------------------------------------------------
	.module _divuint
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divuint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divuint'
;------------------------------------------------------------
;b                         Allocated to stack - offset -4
;a                         Allocated to registers r2 r3 
;reste                     Allocated to registers r4 r5 
;count                     Allocated to registers r6 
;c                         Allocated to registers r7 
;------------------------------------------------------------
;_divuint.c:149: _divuint (unsigned int a, unsigned int b)
;	-----------------------------------------
;	 function _divuint
;	-----------------------------------------
__divuint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
;_divuint.c:151: unsigned int reste = 0;
;     genAssign
	mov	r4,#0x00
	mov	r5,#0x00
;_divuint.c:159: do
;     genAssign
	mov	r6,#0x10
00105$:
;_divuint.c:162: c = MSB_SET(a);
;     genGetHbit
	mov	a,r3
	rl	a
	anl	a,#0x01
	mov	r7,a
;     genAssign
;_divuint.c:163: a <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
;     genlshTwo
	mov	a,r3
	xch	a,r2
	add	a,acc
	xch	a,r2
	rlc	a
	mov	r3,a
;_divuint.c:164: reste <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
;     genlshTwo
	mov	a,r5
	xch	a,r4
	add	a,acc
	xch	a,r4
	rlc	a
	mov	r5,a
;_divuint.c:165: if (c)
;     genIfx
	mov	a,r7
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00114$:
;_divuint.c:166: reste |= 1;
;     genOr
	orl	ar4,#0x01
00102$:
;_divuint.c:168: if (reste >= b)
;     genCmpLt
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r4
	subb	a,@r0
	mov	a,r5
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00106$
00115$:
;_divuint.c:170: reste -= b;
;     genMinus
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
	mov	a,r4
	clr	c
	subb	a,@r0
	mov	r4,a
	mov	a,r5
	inc	r0
	subb	a,@r0
	mov	r5,a
;_divuint.c:172: a |= 1;
;     genOr
	orl	ar2,#0x01
00106$:
;_divuint.c:175: while (--count);
;     genDjnz
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 205    optimized misc jump sequence
	djnz    r6,00105$
00116$:
00117$:
;_divuint.c:176: return a;
;     genRet
	mov	dpl,r2
	mov	dph,r3
00108$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
