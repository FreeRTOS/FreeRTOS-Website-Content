;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:41 2004
;--------------------------------------------------------
	.module _isxdigit
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _isxdigit
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'isxdigit'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;_isxdigit.c:24: char isxdigit (unsigned char c) 
;	-----------------------------------------
;	 function isxdigit
;	-----------------------------------------
_isxdigit:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
;_isxdigit.c:27: if (( c >= '0' && c <= '9')  ||
;     genCmpLt
;     genCmp
	cjne	r2,#0x30,00113$
00113$:
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00105$
00114$:
;     genCmpGt
;     genCmp
	clr	c
	mov	a,#0x39
	subb	a,r2
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00101$
00115$:
00105$:
;_isxdigit.c:28: ( c >= 'a' && c <= 'f')  ||
;     genCmpLt
;     genCmp
	cjne	r2,#0x61,00116$
00116$:
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00107$
00117$:
;     genCmpGt
;     genCmp
	clr	c
	mov	a,#0x66
	subb	a,r2
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00101$
00118$:
00107$:
;_isxdigit.c:29: ( c >= 'A' && c <= 'F')) 
;     genCmpLt
;     genCmp
	cjne	r2,#0x41,00119$
00119$:
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00102$
00120$:
;     genCmpGt
;     genCmp
	clr	c
	mov	a,#0x46
	subb	a,r2
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00102$
00121$:
00101$:
;_isxdigit.c:30: return 1;
;     genRet
	mov	dpl,#0x01
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00108$
00102$:
;_isxdigit.c:31: return 0;
;     genRet
	mov	dpl,#0x00
00108$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
