;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:40 2004
;--------------------------------------------------------
	.module _gptrput
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __gptrput
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_gptrput'
;------------------------------------------------------------
;c                         Allocated to stack - offset -3
;gptr                      Allocated to registers 
;------------------------------------------------------------
;_gptrput.c:29: _gptrput (char *gptr, char c)
;	-----------------------------------------
;	 function _gptrput
;	-----------------------------------------
__gptrput:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;_gptrput.c:83: _endasm;
;     genInline
	        push acc
	    ;
	    ; depending on the pointer type acc. to SDCCsymt.h
	    ;
	        mov a,b
	        jz 00001$ ; 0 near
	        dec a
	        jz 00002$ ; 1 far
	        dec a
	        jz 00003$ ; 2 code
	        dec a
	        jz 00004$ ; 3 pdata
	        dec a ; 4 skip generic pointer
	        dec a
	        jz 00001$ ; 5 idata
 00003$:
	        pop acc ; do nothing
	        sjmp 00005$
;
; store into near space
;
 00001$:
	        pop acc
	        push ar0
	        mov r0,dpl
	        mov @r0,a
	        pop ar0
	        sjmp 00005$
 00002$:
	        pop acc
	        movx @dptr,a
	        sjmp 00005$
 00004$:
	        pop acc
	        push ar0
	        mov r0,dpl
	        movx @r0,a
	        pop ar0
 00005$:
00101$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
