;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:55 2004
;--------------------------------------------------------
	.module _divulong
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divulong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divulong'
;------------------------------------------------------------
;b                         Allocated to stack - offset -6
;a                         Allocated to stack - offset 1
;reste                     Allocated to registers r6 r7 r2 r3 
;count                     Allocated to registers r4 
;c                         Allocated to registers r5 
;------------------------------------------------------------
;_divulong.c:327: _divulong (unsigned long a, unsigned long b)
;	-----------------------------------------
;	 function _divulong
;	-----------------------------------------
__divulong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
;_divulong.c:329: unsigned long reste = 0L;
;     genAssign
	mov	r6,#0x00
	mov	r7,#0x00
	mov	r2,#0x00
	mov	r3,#0x00
;_divulong.c:337: do
;     genAssign
	mov	r4,#0x20
00105$:
;_divulong.c:340: c = MSB_SET(a);
;     genGetHbit
	mov	a,_bp
	add	a,#0x01
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	rl	a
	anl	a,#0x01
	mov	r5,a
;     genAssign
;_divulong.c:341: a <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genlshFour
	mov	a,@r0
	add	a,acc
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
;_divulong.c:342: reste <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
;     genlshFour
	mov	a,r6
	add	a,acc
	mov	r6,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r2
	rlc	a
	mov	r2,a
	mov	a,r3
	rlc	a
	mov	r3,a
;_divulong.c:343: if (c)
;     genIfx
	mov	a,r5
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00114$:
;_divulong.c:344: reste |= 1L;
;     genOr
	orl	ar6,#0x01
00102$:
;_divulong.c:346: if (reste >= b)
;     genCmpLt
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r6
	subb	a,@r0
	mov	a,r7
	inc	r0
	subb	a,@r0
	mov	a,r2
	inc	r0
	subb	a,@r0
	mov	a,r3
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00106$
00115$:
;_divulong.c:348: reste -= b;
;     genMinus
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,r6
	clr	c
	subb	a,@r0
	mov	r6,a
	mov	a,r7
	inc	r0
	subb	a,@r0
	mov	r7,a
	mov	a,r2
	inc	r0
	subb	a,@r0
	mov	r2,a
	mov	a,r3
	inc	r0
	subb	a,@r0
	mov	r3,a
;_divulong.c:350: a |= 1L;
;     genOr
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,#0x01
	orl	a,@r0
	mov	@r0,a
00106$:
;_divulong.c:353: while (--count);
;     genDjnz
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 205    optimized misc jump sequence
	djnz    r4,00105$
00116$:
00117$:
;_divulong.c:354: return a;
;     genRet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
00108$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
