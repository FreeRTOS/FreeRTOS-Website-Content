;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:40 2004
;--------------------------------------------------------
	.module _fsmul
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsmul
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsmul'
;------------------------------------------------------------
;a2                        Allocated to stack - offset -6
;a1                        Allocated to registers r2 r3 r4 r5 
;fl1                       Allocated to stack - offset 1
;fl2                       Allocated to stack - offset 5
;result                    Allocated to stack - offset 9
;exp                       Allocated to stack - offset 13
;sign                      Allocated to stack - offset 15
;sloc0                     Allocated to stack - offset 16
;sloc1                     Allocated to stack - offset 20
;------------------------------------------------------------
;_fsmul.c:28: float __fsmul (float a1, float a2) {
;	-----------------------------------------
;	 function __fsmul
;	-----------------------------------------
___fsmul:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0x17
	mov	sp,a
;_fsmul.c:34: fl1.f = a1;
;     genAddrOf
	mov	a,_bp
	add	a,#0x01
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_fsmul.c:35: fl2.f = a2;
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
;_fsmul.c:37: if (!fl1.l || !fl2.l)
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00101$
00114$:
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00115$:
00101$:
;_fsmul.c:38: return (0);
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00107$
00102$:
;_fsmul.c:41: sign = SIGN (fl1.l) ^ SIGN (fl2.l);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genGetHbit
	mov	a,r5
	rl	a
	anl	a,#0x01
	mov	r2,a
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genGetHbit
	mov	a,r6
	rl	a
	anl	a,#0x01
;     genXor
;       Peephole 105    removed redundant mov
	mov     r3,a
	xrl	ar2,a
;     genAssign
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	@r0,ar2
;_fsmul.c:42: exp = EXP (fl1.l) - EXCESS;
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar3,r5
	mov	a,r6
	mov	c,acc.7
	xch	a,r3
	rlc	a
	xch	a,r3
	rlc	a
	xch	a,r3
	anl	a,#0x01
	mov	r4,a
	mov	r5,#0x00
	mov	r6,#0x00
;     genAnd
	mov	r4,#0x00
;     genMinus
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r5,a
	mov     r6,a
	mov     a,r3
	add	a,#0x82
	mov	r3,a
	mov	a,r4
	addc	a,#0xff
	mov	r4,a
	mov	a,r5
	addc	a,#0xff
	mov	r5,a
	mov	a,r6
	addc	a,#0xff
	mov	r6,a
;     genCast
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
;_fsmul.c:43: exp += EXP (fl2.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar3,r5
	mov	a,r6
	mov	c,acc.7
	xch	a,r3
	rlc	a
	xch	a,r3
	rlc	a
	xch	a,r3
	anl	a,#0x01
	mov	r4,a
;     genAnd
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r5,a
	mov     r6,a
	mov     a,_bp
	add	a,#0x10
	mov	r0,a
	mov	@r0,ar3
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
;     genCast
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	mov	a,@r0
	rlc	a
	subb	a,acc
	mov	r3,a
	mov	r4,a
;     genPlus
	mov	a,_bp
	add	a,#0x10
	mov	r0,a
	mov	a,@r0
;       Peephole 236.a  used r7 instead of ar7
	add     a,r7
	mov	r7,a
	inc	r0
	mov	a,@r0
;       Peephole 236.b  used r2 instead of ar2
	addc    a,r2
	mov	r2,a
	inc	r0
	mov	a,@r0
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	mov	r3,a
	inc	r0
	mov	a,@r0
;       Peephole 236.b  used r4 instead of ar4
	addc    a,r4
	mov	r4,a
;     genCast
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
;_fsmul.c:45: fl1.l = MANT (fl1.l);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
	inc	r1
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
;     genAnd
	anl	ar4,#0x7F
	mov	r5,#0x00
;     genOr
	orl	ar4,#0x80
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_fsmul.c:46: fl2.l = MANT (fl2.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r1,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
	inc	r1
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
;     genAnd
	anl	ar4,#0x7F
	mov	r5,#0x00
;     genOr
	orl	ar4,#0x80
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_fsmul.c:49: result = (fl1.l >> 8) * (fl2.l >> 8);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x10
	mov	r0,a
;     genrshFour
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,#0x00
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar6,r7
	mov	ar7,r2
	mov	ar2,r3
	mov	r3,#0x00
;     genIpush
	push	ar6
	push	ar7
	push	ar2
	push	ar3
;     genCall
	mov	a,_bp
	add	a,#0x10
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_fsmul.c:50: result += ((fl1.l & (unsigned long) 0xFF) * (fl2.l >> 8)) >> 8;
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genAnd
	mov	a,_bp
	add	a,#0x10
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar6,r7
	mov	ar7,r2
	mov	ar2,r3
	mov	r3,#0x00
;     genIpush
	push	ar6
	push	ar7
	push	ar2
	push	ar3
;     genCall
	mov	a,_bp
	add	a,#0x10
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar2,r3
	mov	ar3,r4
	mov	ar4,r5
	mov	r5,#0x00
;     genPlus
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,@r0
	mov	@r0,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 236.g  used r5 instead of ar5
	mov     a,r5
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsmul.c:51: result += ((fl2.l & (unsigned long) 0xFF) * (fl1.l >> 8)) >> 8;
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genAnd
	mov	a,_bp
	add	a,#0x10
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar6,r7
	mov	ar7,r2
	mov	ar2,r3
	mov	r3,#0x00
;     genIpush
	push	ar6
	push	ar7
	push	ar2
	push	ar3
;     genCall
	mov	a,_bp
	add	a,#0x10
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar2,r3
	mov	ar3,r4
	mov	ar4,r5
	mov	r5,#0x00
;     genPlus
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,@r0
	mov	@r0,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 236.g  used r5 instead of ar5
	mov     a,r5
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsmul.c:53: if (result & SIGNBIT)
;     genAnd
	mov	a,_bp
	add	a,#0x09
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00105$
00116$:
;_fsmul.c:56: result += 0x80;
;     genPlus
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	a,#0x80
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsmul.c:57: result >>= 8;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x09
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	dec	r0
	mov	@r0,a
	inc	r0
	inc	r0
	mov	a,@r0
	dec	r0
	mov	@r0,a
	inc	r0
	inc	r0
	mov	a,@r0
	dec	r0
	mov	@r0,a
	inc	r0
	mov	@r0,#0x00
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00106$
00105$:
;_fsmul.c:62: result += 0x40;
;     genPlus
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	a,#0x40
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsmul.c:63: result >>= 7;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x09
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	dec	r0
	mov	c,acc.7
	xch	a,@r0
	rlc	a
	xch	a,@r0
	rlc	a
	xch	a,@r0
	anl	a,#0x01
	inc	r0
	mov	@r0,a
	inc	r0
	mov	a,@r0
	add	a,acc
	dec	r0
	orl	a,@r0
	mov	@r0,a
	inc	r0
	inc	r0
	mov	a,@r0
	dec	r0
	mov	c,acc.7
	xch	a,@r0
	rlc	a
	xch	a,@r0
	rlc	a
	xch	a,@r0
	anl	a,#0x01
	inc	r0
	mov	@r0,a
;_fsmul.c:64: exp--;
;     genMinus
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
00106$:
;_fsmul.c:67: result &= ~HIDDEN;
;     genAnd
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	a,#0x7F
	inc	r0
	inc	r0
	anl	a,@r0
	mov	@r0,a
;_fsmul.c:70: fl1.l = PACK (sign ? SIGNBIT : 0 , (unsigned long)exp, result);  
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genIfx
	mov	a,_bp
	add	a,#0x0f
	mov	r1,a
	mov	a,@r1
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00109$
00117$:
;     genAssign
	mov	a,_bp
	add	a,#0x14
	mov	r1,a
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x80
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00110$
00109$:
;     genAssign
	mov	a,_bp
	add	a,#0x14
;       Peephole 218    simplified clear (4bytes)
	mov     r1,a
	clr     a
	mov     @r1,a
	inc     r1
	mov     @r1,a
	inc     r1
	mov     @r1,a
	inc     r1
	mov     @r1,a
00110$:
;     genCast
	mov	a,_bp
	add	a,#0x0d
	mov	r1,a
	mov	ar6,@r1
	inc	r1
	mov	ar7,@r1
	mov	a,@r1
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genLeftShift
;     genLeftShiftLiteral
;     genlshFour
	mov	ar2,r6
	mov	a,r7
	anl	a,#0x01
	mov	c,acc.0
	xch	a,r2
	rrc	a
	xch	a,r2
	rrc	a
	xch	a,r2
	mov	r3,a
;     genOr
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r7,a
	mov     r6,a
	mov     a,_bp
	add	a,#0x14
	mov	r1,a
	mov	a,@r1
	orl	ar6,a
	inc	r1
	mov	a,@r1
	orl	ar7,a
	inc	r1
	mov	a,@r1
	orl	ar2,a
	inc	r1
	mov	a,@r1
	orl	ar3,a
;     genOr
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	a,@r1
	orl	ar6,a
	inc	r1
	mov	a,@r1
	orl	ar7,a
	inc	r1
	mov	a,@r1
	orl	ar2,a
	inc	r1
	mov	a,@r1
	orl	ar3,a
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_fsmul.c:71: return (fl1.f);
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00107$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
