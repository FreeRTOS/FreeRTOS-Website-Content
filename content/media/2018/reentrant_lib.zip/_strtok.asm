;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:45 2004
;--------------------------------------------------------
	.module _strtok
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strtok
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_strtok_s_1_1:
	.ds 3
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strtok'
;------------------------------------------------------------
;control                   Allocated to stack - offset -5
;str                       Allocated to registers r2 r3 r4 
;s1                        Allocated to registers r2 r3 r4 
;s                         Allocated with name '_strtok_s_1_1'
;------------------------------------------------------------
;_strtok.c:31: char * strtok (
;	-----------------------------------------
;	 function strtok
;	-----------------------------------------
_strtok:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;_strtok.c:38: if ( str )
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00130$:
;_strtok.c:39: s = str ;
;     genAssign
	mov	dptr,#_strtok_s_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
00102$:
;_strtok.c:40: if ( !s )
;     genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00108$
00131$:
;_strtok.c:41: return NULL;
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x00
	ljmp	00119$
;_strtok.c:43: while (*s) {
00108$:
;     genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r2,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00110$
00132$:
;_strtok.c:44: if (strchr(control,*s))
;     genIpush
	push	ar2
;     genCall
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	_strchr
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	dec	sp
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00110$
00133$:
;_strtok.c:45: s++;
;     genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;     genPlus
	mov	dptr,#_strtok_s_1_1
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	movx	@dptr,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;_strtok.c:47: break;
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00108$
00110$:
;_strtok.c:50: s1 = s ;
;     genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;     genAssign
;_strtok.c:52: while (*s) {
00113$:
;     genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r5,a
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 162    removed sjmp by inverse jump logic
	jz      00115$
00134$:
;_strtok.c:53: if (strchr(control,*s)) {
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	_strchr
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
	dec	sp
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r5
	orl	a,r6
	orl	a,r7
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00112$
00135$:
;_strtok.c:54: *s++ = '\0';
;     genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;       Peephole 181    changed mov to clr
	clr     a
	lcall	__gptrput
;     genPlus
	mov	dptr,#_strtok_s_1_1
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r5 instead of ar5
	add     a,r5
	movx	@dptr,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r6 instead of ar6
	addc    a,r6
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;_strtok.c:55: return s1 ;
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00119$
00112$:
;_strtok.c:57: s++ ;
;     genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;     genPlus
	mov	dptr,#_strtok_s_1_1
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r5 instead of ar5
	add     a,r5
	movx	@dptr,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r6 instead of ar6
	addc    a,r6
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	ljmp	00113$
00115$:
;_strtok.c:60: s = NULL;
;     genAssign
	mov	dptr,#_strtok_s_1_1
	clr	a
	inc	dptr
	inc	dptr
	movx	@dptr,a
	lcall	__decdptr
	movx	@dptr,a
	lcall	__decdptr
	movx	@dptr,a
;_strtok.c:62: if (*s1)
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r5,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00117$
00136$:
;_strtok.c:63: return s1;
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00119$
00117$:
;_strtok.c:65: return NULL;
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x00
00119$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
