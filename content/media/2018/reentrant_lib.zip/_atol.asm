;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:37 2004
;--------------------------------------------------------
	.module _atol
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atol
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atol'
;------------------------------------------------------------
;s                         Allocated to registers r5 r6 r7 
;rv                        Allocated to stack - offset 1
;sign                      Allocated to registers r4 
;sloc0                     Allocated to stack - offset 5
;sloc1                     Allocated to stack - offset 8
;------------------------------------------------------------
;_atol.c:25: long atol(char * s)
;	-----------------------------------------
;	 function atol
;	-----------------------------------------
_atol:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
	mov	a,sp
	add	a,#0x0b
	mov	sp,a
;     genReceive
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
;_atol.c:27: register long rv=0; 
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	clr	a
	inc	r0
	inc	r0
	inc	r0
	mov	@r0,a
	dec	r0
	mov	@r0,a
	dec	r0
	mov	@r0,a
	dec	r0
	mov	@r0,a
;_atol.c:31: while (*s) {
;     genAssign
	mov	ar3,r5
	mov	ar4,r6
	mov	ar2,r7
00107$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r2
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r5,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00109$
00133$:
;_atol.c:32: if (*s <= '9' && *s >= '0')
;     genCmpGt
;     genCmp
	clr	c
;       Peephole 159    avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	mov	b,r5
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00102$
00134$:
;     genCmpLt
;     genCmp
	clr	c
	mov	a,r5
	xrl	a,#0x80
	subb	a,#0xb0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00109$
00135$:
;_atol.c:33: break;
00102$:
;_atol.c:34: if (*s == '-' || *s == '+') 
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r2
	lcall	__gptrget
	mov	r5,a
;     genCmpEq
	cjne	r5,#0x2D,00136$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00109$
00136$:
;     genCmpEq
	cjne	r5,#0x2B,00137$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00109$
00137$:
;_atol.c:36: s++;
;     genPlus
;     genPlusIncr
	inc	r3
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 243    avoided branch to sjmp
	cjne    r3,#0x00,00107$
	inc     r4
00138$:
	sjmp    00107$      
00109$:
;_atol.c:39: sign = (*s == '-');
;     genAssign
	mov	ar5,r3
	mov	ar6,r4
	mov	ar7,r2
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r2
	lcall	__gptrget
	mov	r2,a
;     genCmpEq
;       Peephole 241.c  optimized compare
	clr     a
	cjne    r2,#0x2D,00139$
	inc     a
00139$:
00140$:
;     genAssign
;_atol.c:40: if (*s == '-' || *s == '+') s++;
;     genIfx
;       Peephole 166    removed redundant mov
	mov     r3,a
	mov     ar4,r3
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00110$
00141$:
;     genCmpEq
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    r2,#0x2B,00131$
;00142$:
;       Peephole 200    removed redundant sjmp
00143$:
00110$:
;     genPlus
;     genPlusIncr
	inc	r5
	cjne	r5,#0x00,00144$
	inc	r6
00144$:
;_atol.c:42: while (*s && *s >= '0' && *s <= '9') {
00131$:
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
00115$:
;     genPointerGet
;     genGenPointerGet
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r6,a
;     genIfxJump
	jnz	00145$
	ljmp	00117$
00145$:
;     genCmpLt
;     genCmp
	clr	c
	mov	a,r6
	xrl	a,#0x80
	subb	a,#0xb0
;     genIfxJump
	jnc	00146$
	ljmp	00117$
00146$:
;     genCmpGt
;     genCmp
	clr	c
;       Peephole 159    avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	mov	b,r6
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
	jnc	00147$
	ljmp	00117$
00147$:
;_atol.c:43: rv = (rv * 10) + (*s - '0');
;     genIpush
	push	ar4
;     genIpush
	push	ar4
	push	ar6
	mov	a,#0x0A
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	__mullong
	push	acc
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar6
	pop	ar4
;     genCast
	mov	a,r6
	rlc	a
	subb	a,acc
	mov	r5,a
;     genMinus
	mov	a,r6
	add	a,#0xd0
	mov	r6,a
	mov	a,r5
	addc	a,#0xff
;     genCast
;       Peephole 105    removed redundant mov
	mov     r5,a
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genPlus
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
;       Peephole 236.g  used r6 instead of ar6
	mov     a,r6
	add	a,@r0
	mov	r6,a
;       Peephole 236.g  used r5 instead of ar5
	mov     a,r5
	inc	r0
	addc	a,@r0
	mov	r5,a
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	inc	r0
	addc	a,@r0
	mov	r2,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	inc	r0
	addc	a,@r0
	mov	r3,a
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_atol.c:44: s++;
;     genPlus
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;     genIpop
	pop	ar4
	ljmp	00115$
00117$:
;_atol.c:47: return (sign ? -rv : rv);
;     genIfx
	mov	a,r4
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00120$
00148$:
;     genUminus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	clr	c
	clr	a
	subb	a,@r0
	mov	r2,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r3,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r4,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r5,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00121$
00120$:
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
00121$:
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00118$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
