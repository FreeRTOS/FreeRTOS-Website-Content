;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:45 2004
;--------------------------------------------------------
	.module _strspn
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strspn
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strspn'
;------------------------------------------------------------
;control                   Allocated to stack - offset -5
;string                    Allocated to registers r2 r3 r4 
;count                     Allocated to stack - offset 1
;ch                        Allocated to registers 
;------------------------------------------------------------
;_strspn.c:26: int strspn (
;	-----------------------------------------
;	 function strspn
;	-----------------------------------------
_strspn:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
	inc	sp
	inc	sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;_strspn.c:34: while (ch = *string) {
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	clr	a
	inc	r0
	mov	@r0,a
	dec	r0
	mov	@r0,a
;     genAssign
00104$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r7,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00112$:
;_strspn.c:35: if ( strchr(control,ch) )
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar7
;     genCall
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	_strchr
	mov	r7,dpl
	mov	r5,dph
	mov	r6,b
	dec	sp
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
	mov	a,r7
	orl	a,r5
	orl	a,r6
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00113$:
;_strspn.c:36: count++ ;
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_strspn.c:39: string++ ;
;     genPlus
;     genPlusIncr
	inc	r2
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 243    avoided branch to sjmp
	cjne    r2,#0x00,00104$
	inc     r3
00114$:
	sjmp    00104$      
00106$:
;_strspn.c:42: return count ;
;     genRet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
00107$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
