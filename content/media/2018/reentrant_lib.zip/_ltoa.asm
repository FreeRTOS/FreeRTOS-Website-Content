;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:42 2004
;--------------------------------------------------------
	.module _ltoa
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __ltoa
	.globl __ultoa
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_ultoa'
;------------------------------------------------------------
;string                    Allocated to stack - offset -5
;radix                     Allocated to stack - offset -6
;value                     Allocated to stack - offset 1
;index                     Allocated to registers r4 
;buffer                    Allocated to stack - offset 5
;sloc0                     Allocated to stack - offset 37
;------------------------------------------------------------
;_ltoa.c:18: void _ultoa(unsigned long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ultoa
;	-----------------------------------------
__ultoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x28
	mov	sp,a
;_ltoa.c:25: do {
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r6,a
;     genAssign
	mov	r4,#0x20
00103$:
;_ltoa.c:26: buffer[--index] = '0' + (value % radix);
;     genMinus
;     genMinusDec
	dec	r4
;     genPlus
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
;       Peephole 236.a  used r6 instead of ar6
	add     a,r6
	mov	r0,a
;     genCast
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	push	ar0
	mov	a,_bp
	add	a,#0x25
	mov	r0,a
	mov	a,@r1
	mov	@r0,a
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	pop	ar0
;     genIpush
	push	ar4
	push	ar0
	mov	a,_bp
	add	a,#0x25
	mov	r1,a
	mov	a,@r1
	push	acc
	inc	r1
	mov	a,@r1
	push	acc
	inc	r1
	mov	a,@r1
	push	acc
	inc	r1
	mov	a,@r1
	push	acc
;     genIpush
	push	ar6
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	dpl,@r1
	inc	r1
	mov	dph,@r1
	inc	r1
	mov	b,@r1
	inc	r1
	mov	a,@r1
	lcall	__modulong
	mov	r6,dpl
	mov	r7,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar0
	pop	ar4
;     genCast
;     genPlus
	mov	a,#0x30
;       Peephole 236.a  used r6 instead of ar6
	add     a,r6
;     genPointerSet
;     genNearPointerSet
;       Peephole 192    used a instead of ar6 as source
	mov     r6,a
	mov     @r0,a
;_ltoa.c:27: if ( buffer[index] > '9') buffer[index] += 'A' - '9' - 1;
;     genCmpGt
;     genCmp
	clr	c
	mov	a,#0x39
	subb	a,r6
	clr	a
	rlc	a
;     genIpop
	pop	ar6
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00115$:
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
;     genPlus
	mov	a,#0x07
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
;     genPointerSet
;     genNearPointerSet
;       Peephole 192    used a instead of ar2 as source
	mov     r2,a
	mov     @r0,a
00102$:
;_ltoa.c:28: value /= radix;
;     genIpush
	push	ar4
	push	ar6
	mov	a,_bp
	add	a,#0x25
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	__divulong
	push	acc
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar6
	pop	ar4
;_ltoa.c:29: } while (value != 0);
;     genCmpEq
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	cjne	@r0,#0x00,00116$
	inc	r0
	cjne	@r0,#0x00,00116$
	inc	r0
	cjne	@r0,#0x00,00116$
	inc	r0
	cjne	@r0,#0x00,00116$
	sjmp	00117$
00116$:
	ljmp	00103$
00117$:
;_ltoa.c:31: do {
;     genAssign
	mov	ar2,r4
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
00106$:
;_ltoa.c:32: *string++ = buffer[index++];
;     genAssign
	mov	ar7,r2
;     genPlus
;     genPlusIncr
	inc	r2
;     genPlus
;       Peephole 236.g  used r7 instead of ar7
	mov     a,r7
;       Peephole 236.a  used r6 instead of ar6
	add     a,r6
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar7,@r0
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	mov	a,r7
	lcall	__gptrput
	inc	dptr
	mov	r3,dpl
	mov	r4,dph
;_ltoa.c:33: } while ( index < NUMBER_OF_DIGITS );
;     genCmpLt
;     genCmp
	cjne	r2,#0x20,00118$
00118$:
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00106$
00119$:
;_ltoa.c:35: *string = 0;  /* string terminator */
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
;       Peephole 181    changed mov to clr
	clr     a
	lcall	__gptrput
00109$:
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function '_ltoa'
;------------------------------------------------------------
;string                    Allocated to stack - offset -5
;radix                     Allocated to stack - offset -6
;value                     Allocated to stack - offset 1
;------------------------------------------------------------
;_ltoa.c:38: void _ltoa(long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ltoa
;	-----------------------------------------
__ltoa:
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
;_ltoa.c:40: if (value < 0 && radix == 10) {
;     genCmpLt
	mov	a,_bp
	add	a,#0x01
;     genCmp
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00102$
00109$:
;     genCmpEq
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 199    optimized misc jump sequence
	cjne    @r0,#0x0A,00102$
;00110$:
;       Peephole 200    removed redundant sjmp
00111$:
;_ltoa.c:41: *string++ = '-';
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
;     genPointerSet
;     genGenPointerSet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,#0x2D
	lcall	__gptrput
;     genPlus
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r6 instead of ar6
	add     a,r6
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
;       Peephole 236.b  used r7 instead of ar7
	addc    a,r7
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar2
;_ltoa.c:42: _ultoa(-value, string, radix);
;     genUminus
	dec	r0
	dec	r0
	dec	r0
	clr	c
	clr	a
	subb	a,@r0
	mov	r2,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r3,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r4,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r5,a
;     genIpush
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,@r0
	push	acc
;     genIpush
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	__ultoa
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00105$
00102$:
;_ltoa.c:45: _ultoa(value, string, radix);
;     genIpush
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,@r0
	push	acc
;     genIpush
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	__ultoa
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
00105$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
