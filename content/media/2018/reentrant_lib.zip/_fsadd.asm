;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:39 2004
;--------------------------------------------------------
	.module _fsadd
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsadd
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsadd'
;------------------------------------------------------------
;a2                        Allocated to stack - offset -6
;a1                        Allocated to registers r2 r3 r4 r5 
;mant1                     Allocated to stack - offset 1
;mant2                     Allocated to stack - offset 5
;fl1                       Allocated to stack - offset 9
;fl2                       Allocated to stack - offset 13
;exp1                      Allocated to stack - offset 17
;exp2                      Allocated to stack - offset 19
;sign                      Allocated to stack - offset 21
;sloc0                     Allocated to stack - offset 29
;sloc1                     Allocated to stack - offset 25
;------------------------------------------------------------
;_fsadd.c:26: float __fsadd (float a1, float a2)
;	-----------------------------------------
;	 function __fsadd
;	-----------------------------------------
___fsadd:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0x1c
	mov	sp,a
;_fsadd.c:31: volatile unsigned long sign = 0;
;     genAssign
	mov	a,_bp
	add	a,#0x15
;       Peephole 218    simplified clear (4bytes)
	mov     r0,a
	clr     a
	mov     @r0,a
	inc     r0
	mov     @r0,a
	inc     r0
	mov     @r0,a
	inc     r0
	mov     @r0,a
;_fsadd.c:33: fl1.f = a1;
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_fsadd.c:34: fl2.f = a2;
;     genAddrOf
	mov	a,_bp
	add	a,#0x0d
;     genPointerSet
;     genNearPointerSet
;       Peephole 239    used a instead of acc
	mov     r0,a
	mov	a,_bp
	add	a,#0xfa
	mov	r1,a
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
;_fsadd.c:37: if (!fl1.l)
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00102$
00145$:
;_fsadd.c:38: return (fl2.f);
;     genAddrOf
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	ljmp	00129$
00102$:
;_fsadd.c:39: if (!fl2.l)
;     genAddrOf
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00104$
00146$:
;_fsadd.c:40: return (fl1.f);
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	ljmp	00129$
00104$:
;_fsadd.c:42: exp1 = EXP (fl1.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	mov	r4,#0x00
	mov	r5,#0x00
;     genAnd
	mov	r3,#0x00
;     genCast
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r4,a
	mov     r5,a
	mov     a,_bp
	add	a,#0x11
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_fsadd.c:43: exp2 = EXP (fl2.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRightShift
;     genRightShiftLiteral
;     genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	mov	r4,#0x00
	mov	r5,#0x00
;     genAnd
	mov	r3,#0x00
;     genCast
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r4,a
	mov     r5,a
	mov     a,_bp
	add	a,#0x13
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_fsadd.c:45: if (exp1 > exp2 + 25)
;     genPlus
	mov	a,_bp
	add	a,#0x13
	mov	r0,a
	mov	a,#0x19
	add	a,@r0
	mov	r2,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r3,a
;     genCmpGt
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	xrl	a,#0x80
	inc	r0
	mov	b,@r0
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00106$
00147$:
;_fsadd.c:46: return (fl1.f);
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	ljmp	00129$
00106$:
;_fsadd.c:47: if (exp2 > exp1 + 25)
;     genPlus
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	a,#0x19
	add	a,@r0
	mov	r2,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r3,a
;     genCmpGt
	mov	a,_bp
	add	a,#0x13
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	xrl	a,#0x80
	inc	r0
	mov	b,@r0
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00108$
00148$:
;_fsadd.c:48: return (fl2.f);
;     genAddrOf
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	ljmp	00129$
00108$:
;_fsadd.c:50: mant1 = MANT (fl1.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genAnd
	anl	ar4,#0x7F
	mov	r5,#0x00
;     genOr
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	mov	a,#0x80
	orl	a,r4
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar5
;_fsadd.c:51: mant2 = MANT (fl2.l);
;     genAddrOf
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genAnd
	anl	ar4,#0x7F
	mov	r5,#0x00
;     genOr
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	mov	a,#0x80
	orl	a,r4
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar5
;_fsadd.c:53: if (SIGN (fl1.l))
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genGetHbit
	mov	a,r5
	rl	a
	anl	a,#0x01
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r2,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00110$
00149$:
;_fsadd.c:54: mant1 = -mant1;
;     genUminus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	clr	c
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
00110$:
;_fsadd.c:55: if (SIGN (fl2.l))
;     genAddrOf
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genGetHbit
	mov	a,r5
	rl	a
	anl	a,#0x01
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r2,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00112$
00150$:
;_fsadd.c:56: mant2 = -mant2;
;     genUminus
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	clr	c
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
00112$:
;_fsadd.c:58: if (exp1 > exp2)
;     genCmpGt
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	a,_bp
	add	a,#0x13
	mov	r1,a
;     genCmp
	clr	c
	mov	a,@r1
	subb	a,@r0
	inc	r1
	mov	a,@r1
	xrl	a,#0x80
	inc	r0
	mov	b,@r0
	xrl	b,#0x80
	subb	a,b
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00114$
00151$:
;_fsadd.c:60: mant2 >>= exp1 - exp2;
;     genMinus
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
	mov	a,_bp
	add	a,#0x13
	mov	r1,a
	mov	a,@r0
	clr	c
	subb	a,@r1
	mov	r2,a
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	mov	r3,a
;     genRightShift
;     genSignedRightShift
	mov	b,r2
	inc	b
	mov	a,_bp
	add	a,#0x05
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	rlc	a
	mov	ov,c
	dec	r0
	dec	r0
	dec	r0
	sjmp	00153$
00152$:
	mov	c,ov
	inc	r0
	inc	r0
	inc	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
00153$:
	djnz	b,00152$
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00115$
00114$:
;_fsadd.c:64: mant1 >>= exp2 - exp1;
;     genMinus
	mov	a,_bp
	add	a,#0x13
	mov	r0,a
	mov	a,_bp
	add	a,#0x11
	mov	r1,a
	mov	a,@r0
	clr	c
	subb	a,@r1
	mov	r2,a
	inc	r0
	mov	a,@r0
	inc	r1
	subb	a,@r1
	mov	r3,a
;     genRightShift
;     genSignedRightShift
	mov	b,r2
	inc	b
	mov	a,_bp
	add	a,#0x01
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	rlc	a
	mov	ov,c
	dec	r0
	dec	r0
	dec	r0
	sjmp	00155$
00154$:
	mov	c,ov
	inc	r0
	inc	r0
	inc	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
00155$:
	djnz	b,00154$
;_fsadd.c:65: exp1 = exp2;
;     genAssign
	mov	a,_bp
	add	a,#0x13
	mov	r0,a
	mov	a,_bp
	add	a,#0x11
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00115$:
;_fsadd.c:67: mant1 += mant2;
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,_bp
	add	a,#0x05
	mov	r1,a
	mov	a,@r1
	add	a,@r0
	mov	@r0,a
	inc	r1
	mov	a,@r1
	inc	r0
	addc	a,@r0
	mov	@r0,a
	inc	r1
	mov	a,@r1
	inc	r0
	addc	a,@r0
	mov	@r0,a
	inc	r1
	mov	a,@r1
	inc	r0
	addc	a,@r0
	mov	@r0,a
;_fsadd.c:69: if (mant1 < 0)
;     genCmpLt
	mov	a,_bp
	add	a,#0x01
;     genCmp
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.7,00119$
00156$:
;_fsadd.c:71: mant1 = -mant1;
;     genUminus
	dec	r0
	dec	r0
	dec	r0
	clr	c
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	@r0,a
;_fsadd.c:72: sign = SIGNBIT;
;     genAssign
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x00
	inc	r0
	mov	@r0,#0x80
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00121$
00119$:
;_fsadd.c:74: else if (!mant1)
;     genIfx
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	inc	r0
	orl	a,@r0
	inc	r0
	orl	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00121$
00157$:
;_fsadd.c:75: return (0);
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00129$
;_fsadd.c:78: while (mant1<HIDDEN) {
00121$:
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genCmpLt
;     genCmp
	clr	c
	mov	a,r2
	subb	a,#0x00
	mov	a,r3
	subb	a,#0x00
	mov	a,r4
	subb	a,#0x80
	mov	a,r5
	subb	a,#0x00
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00126$
00158$:
;_fsadd.c:79: mant1 <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genlshFour
	mov	a,@r0
	add	a,acc
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
;_fsadd.c:80: exp1--;
;     genMinus
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
;     genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
;_fsadd.c:84: while (mant1 & 0xff000000) {
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00121$
00126$:
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genAnd
	mov	a,r5
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00128$
00159$:
;_fsadd.c:85: if (mant1&1)
;     genAnd
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
;     genIfxJump
;       Peephole 111    removed ljmp by inverse jump logic
	jnb     acc.0,00125$
00160$:
;_fsadd.c:86: mant1 += 2;
;     genPlus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genPlusIncr
	mov	a,#0x02
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
00125$:
;_fsadd.c:87: mant1 >>= 1 ;
;     genRightShift
;     genSignedRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x01
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	mov	c,acc.7
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
;_fsadd.c:88: exp1++;
;     genPlus
	mov	a,_bp
	add	a,#0x11
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00126$
00128$:
;_fsadd.c:92: mant1 &= ~HIDDEN;
;     genAnd
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,#0x7F
	inc	r0
	inc	r0
	anl	a,@r0
	mov	@r0,a
;_fsadd.c:95: fl1.l = PACK (sign, (unsigned long) exp1, mant1);
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genCast
	mov	a,_bp
	add	a,#0x11
	mov	r1,a
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
	mov	a,@r1
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;     genLeftShift
;     genLeftShiftLiteral
;     genlshFour
	mov	ar4,r2
	mov	a,r3
	anl	a,#0x01
	mov	c,acc.0
	xch	a,r4
	rrc	a
	xch	a,r4
	rrc	a
	xch	a,r4
	mov	r5,a
;     genOr
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r3,a
	mov     r2,a
	mov     a,_bp
	add	a,#0x15
	mov	r1,a
	push	ar0
	mov	a,_bp
	add	a,#0x19
	mov	r0,a
	mov	a,r2
	orl	a,@r1
	mov	@r0,a
	mov	a,r3
	inc	r1
	orl	a,@r1
	inc	r0
	mov	@r0,a
	mov	a,r4
	inc	r1
	orl	a,@r1
	inc	r0
	mov	@r0,a
	mov	a,r5
	inc	r1
	orl	a,@r1
	inc	r0
	mov	@r0,a
	pop	ar0
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	ar6,@r1
	inc	r1
	mov	ar7,@r1
	inc	r1
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
;     genOr
	mov	a,_bp
	add	a,#0x19
	mov	r1,a
	mov	a,@r1
	orl	ar6,a
	inc	r1
	mov	a,@r1
	orl	ar7,a
	inc	r1
	mov	a,@r1
	orl	ar2,a
	inc	r1
	mov	a,@r1
	orl	ar3,a
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_fsadd.c:97: return (fl1.f);
;     genAddrOf
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00129$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
