;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:55 2004
;--------------------------------------------------------
	.module _divslong
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divslong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divslong'
;------------------------------------------------------------
;b                         Allocated to stack - offset -6
;a                         Allocated to registers r2 r3 r4 r5 
;r                         Allocated to stack - offset 1
;sloc0                     Allocated to stack - offset 5
;sloc1                     Allocated to stack - offset 13
;------------------------------------------------------------
;_divslong.c:257: _divslong (long a, long b)
;	-----------------------------------------
;	 function _divslong
;	-----------------------------------------
__divslong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0x08
	mov	sp,a
;_divslong.c:262: (b < 0 ? -b : b));
;     genCmpLt
	mov	a,_bp
	add	a,#0xfa
;     genCmp
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	rlc	a
	clr	a
	rlc	a
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r6,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00113$:
;     genUminus
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,_bp
	add	a,#0x05
	mov	r1,a
	clr	c
	clr	a
	subb	a,@r0
	mov	@r1,a
	inc	r0
	clr	a
	subb	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	clr	a
	subb	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	clr	a
	subb	a,@r0
	inc	r1
	mov	@r1,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00107$
00106$:
;     genAssign
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,_bp
	add	a,#0x05
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00107$:
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;_divslong.c:261: r = _divulong((a < 0 ? -a : a),
;     genCmpLt
;     genCmp
	mov	a,r5
	rlc	a
	clr	a
	rlc	a
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r7,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00108$
00114$:
;     genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
	clr	a
	subb	a,r4
	mov	r4,a
	clr	a
	subb	a,r5
	mov	r5,a
;       Peephole 112.b  changed ljmp to sjmp
;     genAssign
;       Peephole 201    removed redundant sjmp
00108$:
00109$:
;     genIpush
	push	ar6
	push	ar7
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	__divulong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar7
	pop	ar6
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_divslong.c:263: if ( (a < 0) ^ (b < 0))
;     genXor
	mov	a,r6
;       Peephole 236.n  used r7 instead of ar7
	xrl     a,r7
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00115$:
;_divslong.c:264: return -r;
;     genUminus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	clr	c
	clr	a
	subb	a,@r0
	mov	r6,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r7,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r2,a
	inc	r0
	clr	a
	subb	a,@r0
;     genRet
;       Peephole 191    removed redundant mov
	mov     r3,a
	mov     dpl,r6
	mov     dph,r7
	mov     b,r2
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00104$
00102$:
;_divslong.c:266: return r;
;     genRet
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
00104$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
