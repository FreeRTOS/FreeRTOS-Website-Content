;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:56 2004
;--------------------------------------------------------
	.module _mullong
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __mullong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_mullong'
;------------------------------------------------------------
;b                         Allocated to stack - offset -6
;a                         Allocated to stack - offset 1
;t                         Allocated to stack - offset 5
;sloc0                     Allocated to stack - offset 9
;sloc1                     Allocated to stack - offset 10
;sloc2                     Allocated to stack - offset 11
;sloc3                     Allocated to stack - offset 12
;sloc4                     Allocated to stack - offset 13
;sloc5                     Allocated to stack - offset 14
;sloc6                     Allocated to stack - offset 15
;sloc7                     Allocated to stack - offset 17
;------------------------------------------------------------
;_mullong.c:534: _mullong (long a, long b)
;	-----------------------------------------
;	 function _mullong
;	-----------------------------------------
__mullong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x14
	mov	sp,a
;_mullong.c:538: t.i.hi = bcast(a)->b.b0 * bcast(b)->b.b2;       // A
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPlus
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r0 instead of ar0
	add     a,r0
	mov	r1,a
;     genAddrOf
;       Peephole 212    reduced add sequence to inc
	mov     r2,_bp
	inc     r2
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	r0,ar2
	mov	ar3,@r0
	pop	ar0
;     genAddrOf
	mov	a,_bp
	add	a,#0xfa
	mov	r4,a
;     genPlus
	push	ar0
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	@r0,a
	pop	ar0
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	ar0,@r0
	mov	ar6,@r0
	pop	ar0
;     genMult
;     genMultOneByte
	mov	b,r3
	mov	a,r6
	mul	ab
;     genPointerSet
;     genNearPointerSet
	mov	@r1,acc
	inc	r1
	mov	@r1,b
	dec	r1
;_mullong.c:539: t.i.lo = bcast(a)->b.b0 * bcast(b)->b.b0;       // A
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	r0,ar4
	mov	ar6,@r0
	pop	ar0
;     genMult
;     genMultOneByte
	mov	b,r3
	mov	a,r6
	mul	ab
;     genPointerSet
;     genNearPointerSet
	mov	@r0,acc
	inc	r0
	mov	@r0,b
	dec	r0
;_mullong.c:540: t.b.b3 += bcast(a)->b.b3 *
;     genPlus
;     genPlusIncr
	mov	a,#0x03
;       Peephole 236.a  used r0 instead of ar0
	add     a,r0
	mov	r7,a
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	r0,ar7
	push	ar1
	mov	a,_bp
	add	a,#0x0a
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	pop	ar0
	pop	ar1
;     genPlus
	push	ar0
	mov	a,_bp
	add	a,#0x0b
	mov	r0,a
;     genPlusIncr
	mov	a,#0x03
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	@r0,a
	pop	ar0
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0b
	mov	r0,a
	mov	ar0,@r0
	mov	ar5,@r0
	pop	ar0
;_mullong.c:541: bcast(b)->b.b0;       // G
;     genMult
;     genMultOneByte
	mov	b,r5
	mov	a,r6
	mul	ab
;     genPlus
	push	ar0
	push	acc
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	pop	acc
	add	a,@r0
	pop	ar0
;     genPointerSet
;     genNearPointerSet
	push	ar0
	mov	r0,ar7
	mov	@r0,acc
	pop	ar0
;_mullong.c:542: t.b.b3 += bcast(a)->b.b2 *
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	r0,ar7
	push	ar1
	mov	a,_bp
	add	a,#0x0a
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	pop	ar0
	pop	ar1
;     genPlus
	push	ar0
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
;     genPlusIncr
	mov	a,#0x02
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	@r0,a
	pop	ar0
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
	mov	ar0,@r0
	push	ar1
	mov	a,_bp
	add	a,#0x0d
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	pop	ar1
	pop	ar0
;_mullong.c:543: bcast(b)->b.b1;       // F
;     genPlus
	push	ar0
	mov	a,_bp
	add	a,#0x0e
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	@r0,a
	pop	ar0
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0e
	mov	r0,a
	mov	ar0,@r0
	mov	ar5,@r0
	pop	ar0
;     genMult
	push	ar0
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genMultOneByte
	mov	b,@r0
	mov	a,r5
	mul	ab
	pop	ar0
;     genPlus
	push	ar0
	push	acc
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	pop	acc
	add	a,@r0
	pop	ar0
;     genPointerSet
;     genNearPointerSet
	push	ar0
	mov	r0,ar7
	mov	@r0,acc
	pop	ar0
;_mullong.c:544: t.i.hi += bcast(a)->b.b2 * bcast(b)->b.b0;      // E <- b lost in .lst
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	a,@r1
	mov	@r0,a
	inc	r1
	mov	a,@r1
	inc	r0
	mov	@r0,a
	dec	r1
	pop	ar0
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
	mov	ar0,@r0
	mov	ar5,@r0
	pop	ar0
;     genMult
;     genMultOneByte
	mov	b,r5
	mov	a,r6
	mul	ab
;     genPlus
	push	ar0
	push	acc
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	pop	acc
	add	a,@r0
	mov	r5,a
	mov	a,b
	inc	r0
	addc	a,@r0
	mov	r7,a
	pop	ar0
;     genPointerSet
;     genNearPointerSet
	mov	@r1,ar5
	inc	r1
	mov	@r1,ar7
	dec	r1
;_mullong.c:546: t.i.hi += bcast(a)->b.b1 * bcast(b)->b.b1;      // D <- b lost in .lst
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	a,@r1
	mov	@r0,a
	inc	r1
	mov	a,@r1
	inc	r0
	mov	@r0,a
	dec	r1
	pop	ar0
;     genPlus
	push	ar0
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	@r0,a
	pop	ar0
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
	mov	ar0,@r0
	mov	ar5,@r0
	pop	ar0
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	a,_bp
	add	a,#0x0e
	mov	r0,a
	mov	ar0,@r0
	mov	ar7,@r0
	pop	ar0
;     genMult
;     genMultOneByte
	mov	b,r5
	mov	a,r7
	mul	ab
;     genPlus
	push	ar0
	push	acc
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	pop	acc
	add	a,@r0
	mov	r7,a
	mov	a,b
	inc	r0
	addc	a,@r0
	mov	r5,a
	pop	ar0
;     genPointerSet
;     genNearPointerSet
	mov	@r1,ar7
	inc	r1
	mov	@r1,ar5
;_mullong.c:548: bcast(a)->bi.b3 = bcast(a)->b.b1 *
;     genPointerGet
;     genNearPointerGet
	mov	a,_bp
	add	a,#0x0c
	mov	r1,a
	mov	ar1,@r1
	mov	ar5,@r1
;_mullong.c:549: bcast(b)->b.b2;
;     genPointerGet
;     genNearPointerGet
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	ar1,@r1
	mov	ar7,@r1
;     genMult
;     genMultOneByte
	mov	b,r5
	mov	a,r7
	mul	ab
;     genPointerSet
;     genNearPointerSet
	push	acc
	mov	a,_bp
	add	a,#0x0b
	mov	r1,a
	pop	acc
	mov	ar1,@r1
	mov	@r1,acc
;_mullong.c:550: bcast(a)->bi.i12 = bcast(a)->b.b1 *
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r1,a
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r2 instead of ar2
	add     a,r2
	mov	r5,a
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	r0,ar5
	mov	ar5,@r0
	pop	ar0
;_mullong.c:551: bcast(b)->b.b0;              // C
;     genMult
;     genMultOneByte
	mov	b,r5
	mov	a,r6
	mul	ab
;     genPointerSet
;     genNearPointerSet
	mov	@r1,acc
	inc	r1
	mov	@r1,b
;_mullong.c:553: bcast(b)->bi.b3 = bcast(a)->b.b0 *
;     genPlus
;     genPlusIncr
	mov	a,#0x03
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	r1,a
;_mullong.c:554: bcast(b)->b.b3;
;     genPointerGet
;     genNearPointerGet
	mov	ar5,@r1
;     genMult
;     genMultOneByte
	mov	b,r3
	mov	a,r5
	mul	ab
;     genPointerSet
;     genNearPointerSet
	mov	@r1,acc
;_mullong.c:555: bcast(b)->bi.i12 = bcast(a)->b.b0 *
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	r1,a
;_mullong.c:556: bcast(b)->b.b1;              // B
;     genPlus
;     genPlusIncr
	mov	a,#0x01
;       Peephole 236.a  used r4 instead of ar4
	add     a,r4
	mov	r5,a
;     genPointerGet
;     genNearPointerGet
	push	ar0
	mov	r0,ar5
	mov	ar5,@r0
	pop	ar0
;     genMult
;     genMultOneByte
	mov	b,r3
	mov	a,r5
	mul	ab
;     genPointerSet
;     genNearPointerSet
	mov	@r1,acc
	inc	r1
	mov	@r1,b
;_mullong.c:557: bcast(b)->bi.b0 = 0;                            // B
;     genPointerSet
;     genNearPointerSet
	mov	r1,ar4
	mov	@r1,#0x00
;_mullong.c:558: bcast(a)->bi.b0 = 0;                            // C
;     genPointerSet
;     genNearPointerSet
	mov	r1,ar2
	mov	@r1,#0x00
;_mullong.c:559: t.l += a;
;     genPointerGet
;     genNearPointerGet
	mov	a,_bp
	add	a,#0x11
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	dec	r0
	dec	r0
	dec	r0
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	ar6,@r1
	inc	r1
	mov	ar7,@r1
	inc	r1
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
;     genPlus
	mov	a,_bp
	add	a,#0x11
	mov	r1,a
;       Peephole 236.g  used r6 instead of ar6
	mov     a,r6
	add	a,@r1
	mov	r6,a
;       Peephole 236.g  used r7 instead of ar7
	mov     a,r7
	inc	r1
	addc	a,@r1
	mov	r7,a
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	inc	r1
	addc	a,@r1
	mov	r2,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	inc	r1
	addc	a,@r1
	mov	r3,a
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;_mullong.c:561: return t.l + b;
;     genAssign
;     genPlus
	mov	a,_bp
	add	a,#0xfa
	mov	r0,a
	mov	a,@r0
;       Peephole 236.a  used r6 instead of ar6
	add     a,r6
	mov	r6,a
	inc	r0
	mov	a,@r0
;       Peephole 236.b  used r7 instead of ar7
	addc    a,r7
	mov	r7,a
	inc	r0
	mov	a,@r0
;       Peephole 236.b  used r2 instead of ar2
	addc    a,r2
	mov	r2,a
	inc	r0
	mov	a,@r0
;       Peephole 236.b  used r3 instead of ar3
	addc    a,r3
;     genRet
;       Peephole 191    removed redundant mov
	mov     r3,a
	mov     dpl,r6
	mov     dph,r7
	mov     b,r2
00101$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
