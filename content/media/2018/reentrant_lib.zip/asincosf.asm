;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:46 2004
;--------------------------------------------------------
	.module asincosf
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _asincosf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'asincosf'
;------------------------------------------------------------
;isacos                    Allocated to stack - offset -4
;x                         Allocated to stack - offset 1
;y                         Allocated to stack - offset 5
;g                         Allocated to stack - offset 9
;r                         Allocated to registers r6 r7 r4 r5 
;i                         Allocated to stack - offset 13
;sloc0                     Allocated to stack - offset 15
;------------------------------------------------------------
;asincosf.c:42: float asincosf(const float x, const int isacos)
;	-----------------------------------------
;	 function asincosf
;	-----------------------------------------
_asincosf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x12
	mov	sp,a
;asincosf.c:50: y=fabsf(x);
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	_fabsf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;asincosf.c:51: i=isacos;
;     genAssign
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
	mov	a,_bp
	add	a,#0x0d
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
;asincosf.c:52: if (y < EPS) r=y;
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x39
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fslt
	mov	r4,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIfx
	mov	a,r4
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00107$
00125$:
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	ljmp	00108$
00107$:
;asincosf.c:55: if (y > 0.5)
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsgt
	mov	r4,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIfx
	mov	a,r4
;     genIfxJump
	jnz	00126$
	ljmp	00104$
00126$:
;asincosf.c:57: i=1-i;
;     genMinus
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
	mov	a,#0x01
	clr	c
	subb	a,@r0
	mov	@r0,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	subb	a,@r0
	mov	@r0,a
;asincosf.c:58: if (y > 1.0)
;     genIpush
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsgt
	mov	r4,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIfx
	mov	a,r4
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00127$:
;asincosf.c:60: errno=EDOM;
;     genAssign
;       Peephole 230    replaced inefficient 16 bit constant
	mov     dptr,#_errno
	mov     a,#0x21
	movx    @dptr,a
	inc     dptr
	clr     a
	movx    @dptr,a
	mov     dptr,#_errno
;asincosf.c:61: return 0.0;
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00117$
00102$:
;asincosf.c:63: g=(0.5-y)+0.5;
;     genIpush
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	mov	b,#0x80
	mov	a,#0x3F
	lcall	___fssub
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;asincosf.c:64: g=ldexpf(g,-1);
;     genIpush
	mov	a,#0xFF
	push	acc
	mov	a,#0xFF
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	_ldexpf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	dec	sp
	dec	sp
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;asincosf.c:65: y=sqrtf(g);
;     genCall
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	_sqrtf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;asincosf.c:66: y=-(y+y);
;     genIpush
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genUminus
;     genUminusFloat
	mov	a,r5
	cpl	acc.7
	mov	r5,a
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00105$
00104$:
;asincosf.c:70: g=y*y;
;     genIpush
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
00105$:
;asincosf.c:72: r=y+y*((P(g)*g)/Q(g));
;     genIpush
	mov	a,#0x65
	push	acc
	mov	a,#0x20
	push	acc
	mov	a,#0x01
	push	acc
	mov	a,#0xBF
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,#0x6B
	push	acc
	mov	a,#0x16
	push	acc
	mov	a,#0x6F
	push	acc
	mov	a,#0x3F
	push	acc
;     genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r2
	mov	a,r3
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsmul
	push	acc
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	pop	acc
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
	inc	r0
	mov	@r0,b
	inc	r0
	mov	@r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,#0x0B
	push	acc
	mov	a,#0x8D
	push	acc
	mov	a,#0xB1
	push	acc
	mov	a,#0xC0
	push	acc
;     genCall
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,r3
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,#0xF0
	push	acc
	mov	a,#0x50
	push	acc
	mov	a,#0xB3
	push	acc
	mov	a,#0x40
	push	acc
;     genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsdiv
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	ar6,r2
	mov	ar7,r3
00108$:
;asincosf.c:74: if (isacos)
;     genIfx
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
	mov	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
	jnz	00128$
	ljmp	00115$
00128$:
;asincosf.c:76: if (x < 0.0)
;     genIpush
	push	ar4
	push	ar5
	push	ar6
	push	ar7
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fslt
	mov	r2,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
;     genIfx
	mov	a,r2
;     genIfxJump
	jnz	00129$
	ljmp	00110$
00129$:
;asincosf.c:77: r=(b[i]+r)+b[i];
;     genLeftShift
;     genLeftShiftLiteral
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genlshTwo
	mov	ar2,@r0
	inc	r0
	mov	a,@r0
	xch	a,r2
	add	a,acc
	xch	a,r2
	rlc	a
	xch	a,r2
	add	a,acc
	xch	a,r2
	rlc	a
	mov	r3,a
;     genPlus
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,#_asincosf_b_1_1
	mov	dpl,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	addc	a,#(_asincosf_b_1_1 >> 8)
	mov	dph,a
;     genPointerGet
;     genCodePointerGet
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
;       Peephole 181    changed mov to clr
	clr     a
	movc	a,@a+dptr
	mov	@r0,a
	mov	a,#0x01
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
	mov	a,#0x02
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
	mov	a,#0x03
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
;     genIpush
	push	ar6
	push	ar7
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,r3
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	ar6,r2
	mov	ar7,r3
	ljmp	00116$
00110$:
;asincosf.c:79: r=(a[i]-r)+a[i];
;     genLeftShift
;     genLeftShiftLiteral
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genlshTwo
	mov	ar2,@r0
	inc	r0
	mov	a,@r0
	xch	a,r2
	add	a,acc
	xch	a,r2
	rlc	a
	xch	a,r2
	add	a,acc
	xch	a,r2
	rlc	a
	mov	r3,a
;     genPlus
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,#_asincosf_a_1_1
	mov	dpl,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	addc	a,#(_asincosf_a_1_1 >> 8)
	mov	dph,a
;     genPointerGet
;     genCodePointerGet
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
;       Peephole 181    changed mov to clr
	clr     a
	movc	a,@a+dptr
	mov	@r0,a
	mov	a,#0x01
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
	mov	a,#0x02
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
	mov	a,#0x03
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
;     genIpush
	push	ar6
	push	ar7
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fssub
	mov	r6,dpl
	mov	r7,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,r3
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	ar6,r2
	mov	ar7,r3
	ljmp	00116$
00115$:
;asincosf.c:83: r=(a[i]+r)+a[i];
;     genLeftShift
;     genLeftShiftLiteral
	mov	a,_bp
	add	a,#0x0d
	mov	r0,a
;     genlshTwo
	mov	ar2,@r0
	inc	r0
	mov	a,@r0
	xch	a,r2
	add	a,acc
	xch	a,r2
	rlc	a
	xch	a,r2
	add	a,acc
	xch	a,r2
	rlc	a
	mov	r3,a
;     genPlus
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	add	a,#_asincosf_a_1_1
	mov	dpl,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	addc	a,#(_asincosf_a_1_1 >> 8)
	mov	dph,a
;     genPointerGet
;     genCodePointerGet
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
;       Peephole 181    changed mov to clr
	clr     a
	movc	a,@a+dptr
	mov	@r0,a
	mov	a,#0x01
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
	mov	a,#0x02
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
	mov	a,#0x03
	movc	a,@a+dptr
	inc	r0
	mov	@r0,a
;     genIpush
	push	ar6
	push	ar7
	push	ar4
	push	ar5
;     genCall
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genIpush
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;     genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,r3
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;     genAssign
	mov	ar6,r2
	mov	ar7,r3
;asincosf.c:84: if (x<0.0) r=-r;
;     genIpush
	push	ar4
	push	ar5
	push	ar6
	push	ar7
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;       Peephole 181    changed mov to clr
	clr     a
	push	acc
;     genCall
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	inc	r0
	mov	a,@r0
	lcall	___fslt
	mov	r2,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
;     genIfx
	mov	a,r2
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00116$
00130$:
;     genUminus
;     genUminusFloat
	mov	a,r5
	cpl	acc.7
	mov	r5,a
00116$:
;asincosf.c:86: return r;
;     genRet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r4
	mov	a,r5
00117$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
_asincosf_a_1_1:
	.byte #0x00,#0x00,#0x00,#0x00
	.byte #0xDB,#0x0F,#0x49,#0x3F
_asincosf_b_1_1:
	.byte #0xDB,#0x0F,#0xC9,#0x3F
	.byte #0xDB,#0x0F,#0x49,#0x3F
	.area XINIT   (CODE)
