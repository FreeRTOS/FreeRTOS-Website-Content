;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:55 2004
;--------------------------------------------------------
	.module _divsint
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divsint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divsint'
;------------------------------------------------------------
;b                         Allocated to stack - offset -4
;a                         Allocated to registers r2 r3 
;r                         Allocated to registers r2 r3 
;sloc0                     Allocated to stack - offset 5
;------------------------------------------------------------
;_divsint.c:206: _divsint (int a, int b)
;	-----------------------------------------
;	 function _divsint
;	-----------------------------------------
__divsint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
;_divsint.c:211: (b < 0 ? -b : b));
;     genCmpLt
	mov	a,_bp
	add	a,#0xfc
;     genCmp
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	rlc	a
	clr	a
	rlc	a
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r4,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00106$
00113$:
;     genUminus
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
	clr	c
	clr	a
	subb	a,@r0
	mov	r5,a
	inc	r0
	clr	a
	subb	a,@r0
	mov	r6,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00107$
00106$:
;     genAssign
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
00107$:
;     genAssign
;_divsint.c:210: r = _divuint((a < 0 ? -a : a),
;     genCmpLt
;     genCmp
	mov	a,r3
	rlc	a
	clr	a
	rlc	a
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r7,a
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00108$
00114$:
;     genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
;       Peephole 112.b  changed ljmp to sjmp
;     genAssign
;       Peephole 201    removed redundant sjmp
00108$:
00109$:
;     genIpush
	push	ar4
	push	ar7
	push	ar5
	push	ar6
;     genCall
	mov	dpl,r2
	mov	dph,r3
	lcall	__divuint
	mov	r2,dpl
	mov	r3,dph
	dec	sp
	dec	sp
	pop	ar7
	pop	ar4
;     genAssign
;_divsint.c:212: if ( (a < 0) ^ (b < 0))
;     genXor
	mov	a,r4
;       Peephole 236.n  used r7 instead of ar7
	xrl     a,r7
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00102$
00115$:
;_divsint.c:213: return -r;
;     genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r4,a
	clr	a
	subb	a,r3
	mov	r5,a
;     genRet
	mov	dpl,r4
	mov	dph,r5
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00104$
00102$:
;_divsint.c:215: return r;
;     genRet
	mov	dpl,r2
	mov	dph,r3
00104$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
