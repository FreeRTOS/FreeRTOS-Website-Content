;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:46 2004
;--------------------------------------------------------
	.module _ulong2fs
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___ulong2fs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__ulong2fs'
;------------------------------------------------------------
;a                         Allocated to stack - offset 1
;exp                       Allocated to stack - offset 5
;fl                        Allocated to stack - offset 7
;sloc0                     Allocated to stack - offset 11
;------------------------------------------------------------
;_ulong2fs.c:27: float __ulong2fs (unsigned long a )
;	-----------------------------------------
;	 function __ulong2fs
;	-----------------------------------------
___ulong2fs:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x0a
	mov	sp,a
;_ulong2fs.c:32: if (!a)
;     genIfx
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	inc	r0
	orl	a,@r0
	inc	r0
	orl	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00115$
00119$:
;_ulong2fs.c:34: return 0.0;
;     genRet
	mov	dpl,#0x00
;       Peephole 3.a    changed mov to clr
;       Peephole 3.b    changed mov to clr
	clr     a
	mov     dph,a
	mov     b,a
	ljmp	00111$
;_ulong2fs.c:37: while (a & NORM) 
00115$:
;     genAssign
	mov	r6,#0x96
	mov	r7,#0x00
00103$:
;     genAnd
	mov	a,_bp
	add	a,#0x01
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00117$
00120$:
;_ulong2fs.c:40: a >>= 1;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x01
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	clr	c
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
	dec	r0
	mov	a,@r0
	rrc	a
	mov	@r0,a
;_ulong2fs.c:41: exp++;
;     genPlus
;     genPlusIncr
;	tail increment optimized
	inc	r6
	cjne	r6,#0x00,00103$
	inc	r7
;_ulong2fs.c:44: while (a < HIDDEN)
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00103$
00117$:
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
00106$:
;     genCmpLt
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genCmp
	clr	c
	mov	a,@r0
	subb	a,#0x00
	inc	r0
	mov	a,@r0
	subb	a,#0x00
	inc	r0
	mov	a,@r0
	subb	a,#0x80
	inc	r0
	mov	a,@r0
	subb	a,#0x00
	clr	a
	rlc	a
	mov	r6,a
;     genAssign
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genIfx
	mov	a,r6
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00108$
00121$:
;_ulong2fs.c:46: a <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genlshFour
	mov	a,@r0
	add	a,acc
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
	inc	r0
	mov	a,@r0
	rlc	a
	mov	@r0,a
;_ulong2fs.c:47: exp--;
;     genMinus
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00106$
00108$:
;_ulong2fs.c:51: if ((a&0x7fffff)==0x7fffff) {
;     genAnd
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	mov	a,#0x7F
	inc	r0
	anl	a,@r0
	mov	r2,a
	mov	r3,#0x00
;     genCmpEq
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 194    optimized misc jump sequence
	cjne    r6,#0xFF,00110$
	cjne    r7,#0xFF,00110$
	cjne    r2,#0x7F,00110$
	cjne    r3,#0x00,00110$
;00122$:
;       Peephole 200    removed redundant sjmp
00123$:
;_ulong2fs.c:52: a=0;
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	clr	a
	inc	r0
	inc	r0
	inc	r0
	mov	@r0,a
	dec	r0
	mov	@r0,a
	dec	r0
	mov	@r0,a
	dec	r0
	mov	@r0,a
;_ulong2fs.c:53: exp++;
;     genPlus
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	r4,a
;       Peephole 181    changed mov to clr
	clr     a
	inc	r0
	addc	a,@r0
	mov	r5,a
00110$:
;_ulong2fs.c:57: a &= ~HIDDEN ;
;     genAnd
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,#0x7F
	inc	r0
	inc	r0
	anl	a,@r0
	mov	@r0,a
;_ulong2fs.c:59: fl.l = PACK(0,(unsigned long)exp, a);
;     genAddrOf
	mov	a,_bp
	add	a,#0x07
	mov	r0,a
;     genCast
	mov	ar2,r4
	mov	ar3,r5
	mov	a,r5
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;     genLeftShift
;     genLeftShiftLiteral
;     genlshFour
	mov	ar4,r2
	mov	a,r3
	anl	a,#0x01
	mov	c,acc.0
	xch	a,r4
	rrc	a
	xch	a,r4
	rrc	a
	xch	a,r4
	mov	r5,a
;     genOr
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r3,a
	mov     r2,a
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	a,@r1
	orl	ar2,a
	inc	r1
	mov	a,@r1
	orl	ar3,a
	inc	r1
	mov	a,@r1
	orl	ar4,a
	inc	r1
	mov	a,@r1
	orl	ar5,a
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;_ulong2fs.c:61: return (fl.f);
;     genAddrOf
	mov	a,_bp
	add	a,#0x07
	mov	r0,a
;     genPointerGet
;     genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;     genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
00111$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
