;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:49 2004
;--------------------------------------------------------
	.module ldexpf
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ldexpf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ldexpf'
;------------------------------------------------------------
;pw2                       Allocated to stack - offset -4
;x                         Allocated to stack - offset 1
;fl                        Allocated to stack - offset 5
;e                         Allocated to stack - offset 9
;sloc0                     Allocated to stack - offset 13
;------------------------------------------------------------
;ldexpf.c:24: float ldexpf(const float x, const int pw2)
;	-----------------------------------------
;	 function ldexpf
;	-----------------------------------------
_ldexpf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	push	acc
	mov	a,sp
	add	a,#0x10
	mov	sp,a
;ldexpf.c:29: fl.f = x;
;     genAddrOf
	mov	a,_bp
	add	a,#0x05
	mov	r0,a
;     genPointerSet
;     genNearPointerSet
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	inc	r0
	inc	r1
	mov	a,@r1
	mov	@r0,a
	dec	r0
	dec	r0
	dec	r0
;ldexpf.c:31: e=(fl.l >> 23) & 0x000000ff;
;     genRightShift
;     genSignedRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0x01
;     genrshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r1,a
	mov	ar6,@r1
	inc	r1
	mov	a,@r1
	mov	c,acc.7
	xch	a,r6
	rlc	a
	xch	a,r6
	rlc	a
	xch	a,r6
	anl	a,#0x01
	jnb	acc.0,00103$
	orl	a,#0xfe
00103$:
	mov	r7,a
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genAnd
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	@r1,ar6
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
	inc	r1
	mov	@r1,#0x00
;ldexpf.c:32: e+=pw2;
;     genCast
	mov	a,_bp
	add	a,#0xfc
	mov	r1,a
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
	mov	a,@r1
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;     genPlus
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
;       Peephole 236.g  used r4 instead of ar4
	mov     a,r4
	add	a,@r1
	mov	@r1,a
;       Peephole 236.g  used r5 instead of ar5
	mov     a,r5
	inc	r1
	addc	a,@r1
	mov	@r1,a
;       Peephole 236.g  used r2 instead of ar2
	mov     a,r2
	inc	r1
	addc	a,@r1
	mov	@r1,a
;       Peephole 236.g  used r3 instead of ar3
	mov     a,r3
	inc	r1
	addc	a,@r1
	mov	@r1,a
;ldexpf.c:33: fl.l= ((e & 0xff) << 23) | (fl.l & 0x807fffff);
;     genAnd
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	ar2,@r1
	mov	r3,#0x00
;     genLeftShift
;     genLeftShiftLiteral
;       Peephole 3.c    changed mov to clr
	clr     a
	mov     r4,a
	mov     r5,a
	mov     a,_bp
	add	a,#0x0d
;     genlshFour
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r1,a
	mov	@r1,ar2
	mov	a,r3
	anl	a,#0x01
	mov	c,acc.0
	xch	a,@r1
	rrc	a
	xch	a,@r1
	rrc	a
	xch	a,@r1
	inc	r1
	mov	@r1,a
	dec	r1
	dec	r1
	mov	@r1,#0x00
	dec	r1
	mov	@r1,#0x00
;     genAssign
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	ar6,@r1
	inc	r1
	mov	ar7,@r1
	inc	r1
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
;     genAnd
	anl	ar2,#0x7F
	anl	ar3,#0x80
;     genOr
	mov	a,_bp
	add	a,#0x0d
	mov	r1,a
	mov	a,@r1
	orl	ar6,a
	inc	r1
	mov	a,@r1
	orl	ar7,a
	inc	r1
	mov	a,@r1
	orl	ar2,a
	inc	r1
	mov	a,@r1
	orl	ar3,a
;     genPointerSet
;     genNearPointerSet
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;ldexpf.c:35: return(fl.f);
;     genRet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,r3
00101$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
