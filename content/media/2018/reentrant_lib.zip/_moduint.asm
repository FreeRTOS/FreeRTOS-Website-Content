;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:56 2004
;--------------------------------------------------------
	.module _moduint
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __moduint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_moduint'
;------------------------------------------------------------
;b                         Allocated to stack - offset -4
;a                         Allocated to registers r2 r3 
;count                     Allocated to registers r4 
;------------------------------------------------------------
;_moduint.c:172: _moduint (unsigned int a, unsigned int b)
;	-----------------------------------------
;	 function _moduint
;	-----------------------------------------
__moduint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
;_moduint.c:174: unsigned char count = 0;
;     genAssign
	mov	r4,#0x00
;_moduint.c:177: while (!MSB_SET(b))
;     genAssign
	mov	r5,#0x00
00103$:
;     genGetHbit
	mov	a,_bp
	add	a,#0xfc
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	rl	a
	anl	a,#0x01
;     genIfx
;       Peephole 105    removed redundant mov
	mov     r6,a
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00117$
00119$:
;_moduint.c:179: b <<= 1;
;     genLeftShift
;     genLeftShiftLiteral
	mov	a,_bp
	add	a,#0xfc
;     genlshTwo
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	dec	r0
	xch	a,@r0
	add	a,acc
	xch	a,@r0
	rlc	a
	inc	r0
	mov	@r0,a
;_moduint.c:180: if (b > a)
;     genCmpGt
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 108    removed ljmp by inverse jump logic
	jnc     00102$
00120$:
;_moduint.c:182: b >>=1;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0xfc
;     genrshTwo
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	dec	r0
	clr	c
	rrc	a
	xch	a,@r0
	rrc	a
	xch	a,@r0
	inc	r0
	mov	@r0,a
;_moduint.c:183: break;
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00117$
00102$:
;_moduint.c:185: count++;
;     genPlus
;     genPlusIncr
	inc	r5
;     genAssign
	mov	ar4,r5
;_moduint.c:187: do
;       Peephole 112.b  changed ljmp to sjmp
	sjmp    00103$
00117$:
;     genAssign
00108$:
;_moduint.c:189: if (a >= b)
;     genCmpLt
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
;     genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	inc	r0
	subb	a,@r0
;     genIfxJump
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 160    removed sjmp by inverse jump logic
	jc      00107$
00121$:
;_moduint.c:190: a -= b;
;     genMinus
	mov	a,_bp
	add	a,#0xfc
	mov	r0,a
	mov	a,r2
	clr	c
	subb	a,@r0
	mov	r2,a
	mov	a,r3
	inc	r0
	subb	a,@r0
	mov	r3,a
00107$:
;_moduint.c:191: b >>= 1;
;     genRightShift
;     genRightShiftLiteral
	mov	a,_bp
	add	a,#0xfc
;     genrshTwo
;       Peephole 185    changed order of increment (acc incremented also!)
	inc     a
	mov     r0,a
	mov	a,@r0
	dec	r0
	clr	c
	rrc	a
	xch	a,@r0
	rrc	a
	xch	a,@r0
	inc	r0
	mov	@r0,a
;_moduint.c:193: while (count--);
;     genAssign
	mov	ar5,r4
;     genMinus
;     genMinusDec
	dec	r4
;     genIfx
	mov	a,r5
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00108$
00122$:
;_moduint.c:194: return a;
;     genRet
	mov	dpl,r2
	mov	dph,r3
00111$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
