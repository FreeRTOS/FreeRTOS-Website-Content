;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.4.1 (May  4 2004)
; This file generated Wed May 05 18:33:45 2004
;--------------------------------------------------------
	.module _strncmp
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strncmp
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area CSEG    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strncmp'
;------------------------------------------------------------
;last                      Allocated to stack - offset -5
;count                     Allocated to stack - offset -7
;first                     Allocated to registers r2 r3 r4 
;sloc0                     Allocated to stack - offset 1
;sloc1                     Allocated to stack - offset 3
;------------------------------------------------------------
;_strncmp.c:26: int strncmp (
;	-----------------------------------------
;	 function strncmp
;	-----------------------------------------
_strncmp:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
	inc	sp
	inc	sp
	inc	sp
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;_strncmp.c:32: if (!count)
;     genIfx
	mov	a,_bp
	add	a,#0xf9
	mov	r0,a
	mov	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
;       Peephole 109    removed ljmp by inverse jump logic
	jnz     00114$
00115$:
;_strncmp.c:33: return(0);
;     genRet
;       Peephole 182.b  used 16 bit load of dptr
	mov     dptr,#0x0000
	ljmp	00108$
;_strncmp.c:35: while (--count && *first && *first == *last) {
00114$:
;     genAssign
;     genAssign
	mov	a,_bp
	add	a,#0xfb
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
;     genAssign
	mov	a,_bp
	add	a,#0xf9
	mov	r0,a
;       Peephole 212    reduced add sequence to inc
	mov     r1,_bp
	inc     r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00105$:
;     genMinus
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
;     genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
;     genIfx
;       Peephole 212    reduced add sequence to inc
	mov     r0,_bp
	inc     r0
	mov	a,@r0
	inc	r0
	orl	a,@r0
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00107$
00116$:
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	lcall	__gptrget
	mov	@r0,a
;     genIfx
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	a,@r0
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00107$
00117$:
;     genIpush
	push	ar2
	push	ar3
	push	ar4
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
;     genCmpEq
	mov	a,_bp
	add	a,#0x03
	mov	r0,a
	mov	a,@r0
	cjne	a,ar2,00118$
	mov	a,#0x01
	sjmp	00119$
00118$:
	clr	a
00119$:
;     genIpop
	pop	ar4
	pop	ar3
	pop	ar2
;     genIfx
;     genIfxJump
;       Peephole 110    removed ljmp by inverse jump logic
	jz      00107$
00120$:
;_strncmp.c:36: first++;
;     genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00121$
	inc	r3
00121$:
;_strncmp.c:37: last++;
;     genPlus
;     genPlusIncr
	inc	r5
;       Peephole 112.b  changed ljmp to sjmp
;       Peephole 243    avoided branch to sjmp
	cjne    r5,#0x00,00105$
	inc     r6
00122$:
	sjmp    00105$      
00107$:
;_strncmp.c:40: return( *first - *last );
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;     genCast
;       Peephole 105    removed redundant mov
	mov     r2,a
	rlc	a
	subb	a,acc
	mov	r3,a
;     genPointerGet
;     genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
;     genCast
;       Peephole 105    removed redundant mov
	mov     r5,a
	rlc	a
	subb	a,acc
	mov	r4,a
;     genMinus
	mov	a,r2
	clr	c
;       Peephole 236.l  used r5 instead of ar5
	subb    a,r5
	mov	r2,a
	mov	a,r3
;       Peephole 236.l  used r4 instead of ar4
	subb    a,r4
	mov	r3,a
;     genRet
	mov	dpl,r2
	mov	dph,r3
00108$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area XINIT   (CODE)
