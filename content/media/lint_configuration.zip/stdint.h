#ifndef STDINT_INC
#define STDINT_INC

typedef unsigned long uint32_t;
typedef long int32_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef signed char int8_t;
typedef unsigned char uint8_t;

#endif

