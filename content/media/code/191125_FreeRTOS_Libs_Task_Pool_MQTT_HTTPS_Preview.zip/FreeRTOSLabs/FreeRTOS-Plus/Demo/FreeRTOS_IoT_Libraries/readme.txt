*** INTRODUCTION ***

Currently contains demos from the FreeRTOS task pool library, MQTT library, and
HTTPS Client library.

The pre-configured projects use the FreeRTOS kernel Windows port (often
called the Windows simulator) to enable their evaluation using the free Visual
Studio tools and without needing specific microcontroller hardware.

NOTE: At this time the projects ARE A WORK IN PROGRESS and will be released in
the main FreeRTOS kernel download following full review and completion of the
documentation.

*** INSTRUCTIONS ***

Instructions for configuring and using the libraries are at the following links,
respectively:

  + https://www.FreeRTOS.org/task-pool/
  + https://www.FreeRTOS.org/mqtt/
  + https://www.freertos.org/https/

*** LOCATING THE EXAMPLE PROJECTS ***

The Visual Studio projects for each of the FreeRTOS IoT library examples are
located in sub-directories of the following top-level directories:

  + /FreeRTOS-Plus/Demo/FreeRTOS_IoT_Libraries/utilities
  + /FreeRTOS-Plus/Demo/FreeRTOS_IoT_Libraries/mqtt
  + /FreeRTOS-Plus/Demo/FreeRTOS_IoT_Libraries/https

*** ADDITIONAL INFORMATION ***

See http://www.freertos.org/a00017.html for full details of the FreeRTOS
directory structure

See also -
http://www.freertos.org/FreeRTOS-quick-start-guide.html
http://www.freertos.org/FAQHelp.html
