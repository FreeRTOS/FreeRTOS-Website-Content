/*
    FreeRTOS V6.1.1 - Copyright (C) 2011 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public 
    License and the FreeRTOS license exception along with FreeRTOS; if not it 
    can be viewed here: http://www.freertos.org/a00114.html and also obtained 
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS web site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

/* FreeRTOS.org includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Demo includes. */
#include "basic_io.h"

/* The single hardware defined software interrupt is used by FreeRTOS itself, 
so is not available - therefore a 'pseudo software interrupt' is implemented 
by forcing the interrupt request bit of an unused peripheral into the set 
state.  This is done by the mainTRIGGER_INTERRUPT() macro. */
#define mainTRIGGER_INTERRUPT()	_IR( _CMT1_CMI1 ) = 1

/* Enable the interrupt of the peripheral used by the mainTRIGGER_INTERRUPT() 
macro. */
static void prvSetupInterrupt();

/* The tasks to be created. */
static void prvIntegerGenerator( void *pvParameters );
static void prvStringPrinter( void *pvParameters );

/* The service routine for the interrupt.  This is the interrupt that the
task will be synchronized with. */
static void prvInterruptHandler( void );

/*-----------------------------------------------------------*/

unsigned long ulNext = 0;
unsigned long ulCount;
unsigned long ul[ 100 ];

/* Declare two variables of type xQueueHandle.  One queue will be read from
within an ISR, the other will be written to from within an ISR. */
xQueueHandle xIntegerQueue, xStringQueue;

/*-----------------------------------------------------------*/

int main( void )
{
	/* The following line is just to break up the output to the console between
	successive executions of the application. */
	vPrintString( "\r\n\r\n" );
	
    /* Before a queue can be used it must first be created.  Create both queues
	used by this example.  One queue can hold variables of type unsigned long,
	the other queue can hold variables of type char*.  Both queues can hold a
	maximum of 10 items.  A real application should check the return values to
	ensure the queues have been successfully created. */
    xIntegerQueue = xQueueCreate( 10, sizeof( unsigned long ) );
	xStringQueue = xQueueCreate( 10, sizeof( char * ) );

	/* Enable the peripheral interrupt used by the mainTRIGGER_INTERRUPT()
	macro. */
	prvSetupInterrupt();

	/* Create the task that uses a queue to pass integers to the interrupt service
	routine.  The task is created at priority 1. */
	xTaskCreate( prvIntegerGenerator, "IntGen", 240, NULL, 1, NULL );

	/* Create the task that prints out the strings sent to it from the interrupt
	service routine.  This task is created at the higher priority of 2. */
	xTaskCreate( prvStringPrinter, "String", 240, NULL, 2, NULL );

	/* Start the scheduler so the created tasks start executing. */
	vTaskStartScheduler();

    /* If all is well we will never reach here as the scheduler will now be
    running the tasks.  If we do reach here then it is likely that there was
    insufficient heap memory available for a resource to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

static void prvIntegerGenerator( void *pvParameters )
{
portTickType xLastExecutionTime;
unsigned portLONG ulValueToSend = 0;
int i;

	/* Initialize the variable used by the call to vTaskDelayUntil(). */
	xLastExecutionTime = xTaskGetTickCount();

	for( ;; )
	{
		/* This is a periodic task.  Block until it is time to run again.
		The task will execute every 200ms. */
		vTaskDelayUntil( &xLastExecutionTime, 200 / portTICK_RATE_MS );

		/* Send an incrementing number to the queue five times.  These will be
		read from the queue by the interrupt service routine.  The interrupt
        service routine always empties the queue so this task is guaranteed to 
		be able to write all five values, so a block time is not required. */
		for( i = 0; i < 5; i++ )
		{
			xQueueSendToBack( xIntegerQueue, &ulValueToSend, 0 );
			ulValueToSend++;
		}

		/* Force an interrupt so the interrupt service routine can read the
		values from the queue. */
		vPrintString( "Generator task - About to generate an interrupt.\n" );
		mainTRIGGER_INTERRUPT();
		vPrintString( "Generator task - Interrupt generated.\n\n" );
	}
}
/*-----------------------------------------------------------*/

static void prvStringPrinter( void *pvParameters )
{
char *pcString;

	for( ;; )
	{
		/* Block on the queue to wait for data to arrive. */
		xQueueReceive( xStringQueue, &pcString, portMAX_DELAY );

		/* Print out the string received. */
		vPrintString( pcString );
	}
}
/*-----------------------------------------------------------*/

static void prvSetupInterrupt()
{
	/* The single hardware defined software interrupt is used by FreeRTOS itself, 
	so is not available - therefore a 'pseudo software interrupt' is implemented 
	by forcing the interrupt request bit of an unused peripheral into the set 
	state.
	
	CMT0/1 will be enabled when the kernel is started, because the CMT0 CMI0 
	interrupt is used to create the	tick interrupt.  CMI1 is free and is used 
	to force an interrupt from the mainTRIGGER_INTERRUPT() macro.  Enable the 
	interrupt... */
	_IEN( _CMT1_CMI1 ) = 1;

	/* ...and set its priority to the application defined kernel priority. */
	_IPR( _CMT1_CMI1 ) = configKERNEL_INTERRUPT_PRIORITY;
}
/*-----------------------------------------------------------*/

/* The pragma directive tells the compiler to build prvInterruptHandler() as an 
interrupt handler and install it in the relevant position of the interrupt 
vector table.  The 'enable' value causes interrupts to be automatically  
re-enabled as the function is entered.  This allows interrupts to nest at the
earliest possible time. */
#pragma interrupt ( prvInterruptHandler( vect = _VECT( _CMT1_CMI1 ), enable ) )
static void prvInterruptHandler( void )
{
portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
static unsigned long ulReceivedNumber;

/* The strings are declared static const to ensure they are not allocated to the
interrupt service routine stack, and exist even when the interrupt service routine
is not executing. */
static const char *pcStrings[] =
{
    "String 0\n",
    "String 1\n",
    "String 2\n",
    "String 3\n"
};

    /* Loop until the queue is empty. */
    while( xQueueReceiveFromISR( xIntegerQueue, &ulReceivedNumber, &xHigherPriorityTaskWoken ) != errQUEUE_EMPTY )
    {
        /* Truncate the received value to the last two bits (values 0 to 3 inc.), then
        send the string    that corresponds to the truncated value to the other
        queue. */
        ulReceivedNumber &= 0x03;
        xQueueSendToBackFromISR( xStringQueue, &pcStrings[ ulReceivedNumber ], &xHigherPriorityTaskWoken );
    }

    /* xHigherPriorityTaskWoken was initialised to pdFALSE.  It will have then
    been set to pdTRUE only if reading from or writing to a queue caused a task
    of equal or greater priority than the currently executing task to leave the
    Blocked state.  When this is the case a context switch should be performed.
    In all other cases a context switch is not necessary.

    NOTE: The syntax for forcing a context switch within an ISR varies between
    FreeRTOS ports.  The portYIELD_FROM_ISR() macro is provided as part of
    the RX600 port layer for this purpose. */
    portYIELD_FROM_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* This function will only be called if an API call to create a task, queue
	or semaphore fails because there is too little heap RAM remaining. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed char *pcTaskName )
{
	/* This function will only be called if a task overflows its stack.  Note
	that stack overflow checking does slow down the context switch
	implementation. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
	/* This example does not use the idle hook to perform any processing. */
}
/*-----------------------------------------------------------*/

void vApplicationTickHook( void )
{
	/* This example does not use the tick hook to perform any processing. */
}







