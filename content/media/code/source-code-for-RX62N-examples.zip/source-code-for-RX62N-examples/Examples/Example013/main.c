/*
    FreeRTOS V6.1.1 - Copyright (C) 2011 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public 
    License and the FreeRTOS license exception along with FreeRTOS; if not it 
    can be viewed here: http://www.freertos.org/a00114.html and also obtained 
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS web site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

/* FreeRTOS.org includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* Demo includes. */
#include "basic_io.h"

/* The single hardware defined software interrupt is used by FreeRTOS itself, 
so is not available - therefore a 'pseudo software interrupt' is implemented 
by forcing the interrupt request bit of an unused peripheral into the set 
state.  This is done by the mainTRIGGER_INTERRUPT() macro. */
#define mainTRIGGER_INTERRUPT()	_IR( _CMT1_CMI1 ) = 1

/* Enable the interrupt of the peripheral used by the mainTRIGGER_INTERRUPT() 
macro. */
static void prvSetupInterrupt();

/* The tasks to be created. */
static void vHandlerTask( void *pvParameters );
static void vPeriodicTask( void *pvParameters );

/* The service routine for the interrupt.  This is the interrupt that the
task will be synchronized with. */
static void prvInterruptHandler( void );

/*-----------------------------------------------------------*/

/* Declare a variable of type xSemaphoreHandle.  This is used to reference the
semaphore that is used to synchronize a task with an interrupt. */
xSemaphoreHandle xCountingSemaphore;

/*-----------------------------------------------------------*/

int main( void )
{
	/* The following line is just to break up the output to the console between
	successive executions of the application. */
	vPrintString( "\r\n\r\n" );
	
    /* Before a semaphore is used it must be explicitly created.  In this example
	a counting semaphore is created.  The semaphore is created to have a maximum
	count value of 10, and an initial count value of 0. */
    xCountingSemaphore = xSemaphoreCreateCounting( 10, 0 );

	/* Check the semaphore was created successfully. */
	if( xCountingSemaphore != NULL )
	{
    	/* Enable the peripheral interrupt used by the mainTRIGGER_INTERRUPT()
		macro. */
    	prvSetupInterrupt();

		/* Create the 'handler' task.  This is the task that will be synchronized
		with the interrupt.  The handler task is created with a high priority to
		ensure it runs immediately after the interrupt exits.  In this case a
		priority of 3 is chosen. */
		xTaskCreate( vHandlerTask, "Handler", 240, NULL, 3, NULL );

        /* Create the task that will periodically force the generation of an 
		interrupt.  This is created with a priority below the handler task to ensure 
		it will get preempted each time the handler task exits the Blocked state. */
		xTaskCreate( vPeriodicTask, "Periodic", 240, NULL, 1, NULL );

		/* Start the scheduler so the created tasks start executing. */
		vTaskStartScheduler();
	}

    /* If all is well we will never reach here as the scheduler will now be
    running the tasks.  If we do reach here then it is likely that there was
    insufficient heap memory available for a resource to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

static void vHandlerTask( void *pvParameters )
{
	/* As per most tasks, this task is implemented within an infinite loop. */
	for( ;; )
	{
		/* Use the semaphore to wait for the event.  The semaphore was created
		before the scheduler was started so before this task ran for the first
		time.  The task blocks indefinitely meaning this function call will only
		return once the semaphore has been successfully obtained - so there is no
		need to check the returned value. */
		xSemaphoreTake( xCountingSemaphore, portMAX_DELAY );

		/* To get here the event must have occurred.  Process the event (in this
		case we just print out a message). */
		vPrintString( "Handler task - Processing event.\n" );
	}
}
/*-----------------------------------------------------------*/

static void vPeriodicTask( void *pvParameters )
{
	/* As per most tasks, this task is implemented within an infinite loop. */
	for( ;; )
	{
        /* This task is just used to 'simulate' an interrupt.  This is done by
        periodically manually triggering a real interrupt. */
		vTaskDelay( 500 / portTICK_RATE_MS );

		/* Generate the interrupt, printing a message both before hand and
		afterwards so the sequence of execution is evident from the output. */
        vPrintString( "Periodic task - About to generate an interrupt.\n" );
        mainTRIGGER_INTERRUPT();
		vPrintString( "Periodic task - Interrupt generated.\n\n" );
	}
}
/*-----------------------------------------------------------*/

static void prvSetupInterrupt()
{
	/* The single hardware defined software interrupt is used by FreeRTOS itself, 
	so is not available - therefore a 'pseudo software interrupt' is implemented 
	by forcing the interrupt request bit of an unused peripheral into the set 
	state.
	
	CMT0/1 will be enabled when the kernel is started, because the CMT0 CMI0 
	interrupt is used to create the	tick interrupt.  CMI1 is free and is used 
	to force an interrupt from the mainTRIGGER_INTERRUPT() macro.  Enable the 
	interrupt... */
	_IEN( _CMT1_CMI1 ) = 1;

	/* ...and set its priority to the application defined kernel priority. */
	_IPR( _CMT1_CMI1 ) = configKERNEL_INTERRUPT_PRIORITY;
}
/*-----------------------------------------------------------*/

/* The pragma directive tells the compiler to build prvInterruptHandler() as an 
interrupt handler and install it in the relevant position of the interrupt 
vector table.  The 'enable' value causes interrupts to be automatically  
re-enabled as the function is entered.  This allows interrupts to nest at the
earliest possible time. */
#pragma interrupt ( prvInterruptHandler( vect = _VECT( _CMT1_CMI1 ), enable ) )
static void prvInterruptHandler( void )
{
portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	/* 'Give' the semaphore multiple times.  The first will unblock the handler
	task, the following 'gives' are to demonstrate that the semaphore latches
	the events to allow the handler task to process them in turn without any
	events getting lost.  This simulates multiple interrupts being taken by the
	processor, even though in this case the events are simulated within a single
	interrupt occurrence.*/
	xSemaphoreGiveFromISR( xCountingSemaphore, &xHigherPriorityTaskWoken );
	xSemaphoreGiveFromISR( xCountingSemaphore, &xHigherPriorityTaskWoken );
	xSemaphoreGiveFromISR( xCountingSemaphore, &xHigherPriorityTaskWoken );

    /* Giving the semaphore may have unblocked a task - if it did and the
    unblocked task has a priority equal to or above the currently executing
    task, then xHigherPriorityTaskWoken will have been set to pdTRUE and
    portYIELD_FROM_ISR() will force a context switch to the newly unblocked
    higher priority task.

    NOTE: The syntax for forcing a context switch within an ISR varies between
    FreeRTOS ports.  The portYIELD_FROM_ISR() macro is provided as part of
    the RX600 port layer for this purpose. */
    portYIELD_FROM_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* This function will only be called if an API call to create a task, queue
	or semaphore fails because there is too little heap RAM remaining. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed char *pcTaskName )
{
	/* This function will only be called if a task overflows its stack.  Note
	that stack overflow checking does slow down the context switch
	implementation. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
	/* This example does not use the idle hook to perform any processing. */
}
/*-----------------------------------------------------------*/

void vApplicationTickHook( void )
{
	/* This example does not use the tick hook to perform any processing. */
}







