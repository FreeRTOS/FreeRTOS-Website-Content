/*
    FreeRTOS V7.1.0 - Copyright (C) 2011 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public 
    License and the FreeRTOS license exception along with FreeRTOS; if not it 
    can be viewed here: http://www.freertos.org/a00114.html and also obtained 
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

/* MPLAB includes. */
#include <p32xxxx.h>
#include <plib.h>

/* FreeRTOS.org includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Demo includes. */
#include "basic_io.h"

/* PIC32 configuration. */
#pragma config FPLLODIV = DIV_1, FPLLMUL = MUL_20, FPLLIDIV = DIV_2
#pragma config FWDTEN = OFF, FPBDIV = DIV_2, POSCMOD = XT, FNOSC = PRIPLL, CP = OFF
#pragma config FSRSSEL = PRIORITY_7

/* Software interrupt bit used within the CAUSE register to generate an 
interrupt. */
#define mainSW1_CAUSE_BIT            ( 0x01UL << 9 )

/* The software interrupt bit within the Interrupt Flag Status Register. */
#define mainSW1_INT_BIT                ( 0x04UL )

/* Macro to force a software interrupt. */
#define mainTRIGGER_INTERRUPT()                 \
{                                               \
unsigned long ulStatus;                         \
                                                \
    /* Trigger software interrupt. */           \
    ulStatus = _CP0_GET_CAUSE();                \
    ulStatus |= mainSW1_CAUSE_BIT;              \
    _CP0_SET_CAUSE( ulStatus );                 \
}

/* Macro to clear the same software interrupt. */
#define mainCLEAR_INTERRUPT()                   \
{                                               \
unsigned long ulStatus;                         \
                                                \
    /* Trigger software interrupt. */           \
    ulStatus = _CP0_GET_CAUSE();                \
    ulStatus &= ~mainSW1_CAUSE_BIT;             \
    _CP0_SET_CAUSE( ulStatus );                 \
}

/* The tasks to be created. */
static void vIntegerGenerator( void *pvParameters );
static void vStringPrinter( void *pvParameters );

/* The service routine for the interrupt. The C compiler extensions are used to
indicate that this is an interrupt entry point to use for the 
_CORE_SOFTWARE_1_VECTOR vector location.  The assembly wrapper for the 
interrupt (vSW1_ISR_Wrapper()) is defined in ISR_Wrapper.S, the C portion of
the handler (vSW1_ISR_Handler()) is defined in this file.  Note that, because
this interrupt is using the FreeRTOS assembly wrapper, the IPL value used in
the following line of code has no effect.  The interrupt priority is set by the
call to mConfigIntCoreSW1() in the vSetupEnvironment() function. */
void __attribute__( (interrupt(ipl1), vector(_CORE_SOFTWARE_1_VECTOR))) vSW1_ISR_Wrapper( void );

/* Basic hardware and debug interface configuration. */
void vSetupEnvironment( void );

/*-----------------------------------------------------------*/

/* Declare two variables of type xQueueHandle.  One queue will be read from
within an ISR, the other will be written to from within an ISR. */
xQueueHandle xIntegerQueue, xStringQueue;

/*-----------------------------------------------------------*/

int main( void )
{
	/* Configure both the hardware and the debug interface. */
	vSetupEnvironment();

    /* Before a queue can be used it must first be created.  Create both queues
	used by this example.  One queue can hold variables of type unsigned long, 
	the other queue can hold variables of type char*.  Both queues can hold a 
	maximum of 10 items.  A real application should check the return values to 
	ensure the queues have been successfully created. */
    xIntegerQueue = xQueueCreate( 10, sizeof( unsigned long ) );
	xStringQueue = xQueueCreate( 10, sizeof( char * ) );

	/* Create the task that uses a queue to pass integers to the interrupt service
	routine.  The task is created at priority 1. */
	xTaskCreate( vIntegerGenerator, ( signed char * ) "IntGen", 240, NULL, 1, NULL );

	/* Create the task that prints out the strings sent to it from the interrupt
	service routine.  This task is created at the higher priority of 2. */
	xTaskCreate( vStringPrinter, ( signed char * ) "String", 240, NULL, 2, NULL );

	/* Start the scheduler so the created tasks start executing. */
	vTaskStartScheduler();
		
    /* If all is well we will never reach here as the scheduler will now be
    running the tasks.  If we do reach here then it is likely that there was 
    insufficient heap memory available for a resource to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

static void vIntegerGenerator( void *pvParameters )
{
portTickType xLastExecutionTime;
unsigned portLONG ulValueToSend = 0;
int i;

	/* Initialize the variable used by the call to vTaskDelayUntil(). */
	xLastExecutionTime = xTaskGetTickCount();

	for( ;; )
	{
		/* This is a periodic task.  Block until it is time to run again.
		The task will execute every 200ms. */
		vTaskDelayUntil( &xLastExecutionTime, 200 / portTICK_RATE_MS );

		/* Send an incrementing number to the queue five times.  These will be 
		read from the queue by the interrupt service routine.  A block time is 
		not specified. */
		for( i = 0; i < 5; i++ )
		{
			xQueueSendToBack( xIntegerQueue, &ulValueToSend, 0 );
			ulValueToSend++;
		}

		/* Force an interrupt so the interrupt service routine can read the
		values from the queue. */
		vPrintString( "Generator task - About to generate an interrupt.\n" );
		mainTRIGGER_INTERRUPT();
		vPrintString( "Generator task - Interrupt generated.\n\n" );
	}
}
/*-----------------------------------------------------------*/

static void vStringPrinter( void *pvParameters )
{
char *pcString;

	for( ;; )
	{
		/* Block on the queue to wait for data to arrive. */
		xQueueReceive( xStringQueue, &pcString, portMAX_DELAY );

		/* Print out the string received. */
		vPrintString( pcString );
	}
}
/*-----------------------------------------------------------*/

void vSW1_ISR_Handler( void )
{
portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
static unsigned long ulReceivedNumber;

/* The strings are declared static const to ensure they are not allocated to the
interrupt service routine stack, and exist even when the interrupt service routine
is not executing. */
static const char *pcStrings[] =
{
    "String 0\n",
    "String 1\n",
    "String 2\n",
    "String 3\n"
};

    /* Loop until the queue is empty. */
    while( xQueueReceiveFromISR( xIntegerQueue, &ulReceivedNumber, &xHigherPriorityTaskWoken ) != errQUEUE_EMPTY )
    {
        /* Truncate the received value to the last two bits (values 0 to 3 inc.), then
        send the string    that corresponds to the truncated value to the other
        queue. */
        ulReceivedNumber &= 0x03;
        xQueueSendToBackFromISR( xStringQueue, &pcStrings[ ulReceivedNumber ], &xHigherPriorityTaskWoken );
    }

    /* Clear the software interrupt flag. */
    mainCLEAR_INTERRUPT();

    /* Then clear the interrupt in the interrupt controller. */
    IFS0CLR = mainSW1_INT_BIT;

    /* xHigherPriorityTaskWoken was initialised to pdFALSE.  It will have then
    been set to pdTRUE only if reading from or writing to a queue caused a task
    of equal or greater priority than the currently executing task to leave the
    Blocked state.  When this is the case a context switch should be performed.
    In all other cases a context switch is not necessary.
    
    NOTE: The syntax for forcing a context switch within an ISR varies between 
    FreeRTOS ports.  The portEND_SWITCHING_ISR() macro is provided as part of
    the PIC32 port layer for this purpose.  taskYIELD() must never be called 
    from an ISR! */
    portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

void vSetupEnvironment( void )
{
	/* Setup the main clock for maximum performance, and the peripheral clock
	to equal the main clock divided by 2. */
	SYSTEMConfigPerformance( configCPU_CLOCK_HZ );
	mOSCSetPBDIV( OSC_PB_DIV_2 );
    
    /* Setup the software interrupt used by mainTRIGGER_INTERRUPT(). */
    mConfigIntCoreSW1( CSW_INT_ON | CSW_INT_PRIOR_1 | CSW_INT_SUB_PRIOR_0 );
	
	/* Enable global interrupt handling. */
	INTEnableSystemMultiVectoredInt();

	/* Initialise the debug utils library to enable strings printed from the
	demo source code to be displayed in the MPLAB IDE. */
	DBINIT();
	
	/* Set the console output to line buffered mode. */
	vSetIOBuffering();
}
/*-----------------------------------------------------------*/







