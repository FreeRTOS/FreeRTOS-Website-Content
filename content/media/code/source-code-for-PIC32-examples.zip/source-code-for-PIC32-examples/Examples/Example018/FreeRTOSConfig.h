/*
    FreeRTOS V7.1.0 - Copyright (C) 2011 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public 
    License and the FreeRTOS license exception along with FreeRTOS; if not it 
    can be viewed here: http://www.freertos.org/a00114.html and also obtained 
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/


/******************************************************************************
	See http://www.freertos.org/a00110.html for an explanation of the 
	definitions contained in this file.
******************************************************************************/

#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

#define configUSE_PREEMPTION					1
#define configTICK_RATE_HZ						( ( portTickType ) 1000 )
#define configPERIPHERAL_CLOCK_HZ				(40000000UL)
#define configCPU_CLOCK_HZ						(80000000UL)

#define configUSE_16_BIT_TICKS					0
#define configUSE_IDLE_HOOK						0
#define configUSE_TICK_HOOK						0
#define configUSE_TRACE_FACILITY				0
#define configUSE_COUNTING_SEMAPHORES			0
#define configUSE_MUTEXES						0

#define configMINIMAL_STACK_SIZE				( 240 )
#define configISR_STACK_SIZE					( 400 )
#define configKERNEL_INTERRUPT_PRIORITY			0x01
#define configMAX_SYSCALL_INTERRUPT_PRIORITY	0x04

#define configMAX_PRIORITIES					( ( unsigned portBASE_TYPE ) 6 )
#define configTOTAL_HEAP_SIZE					( ( size_t ) 0 ) /* Not used when heap_3 is included in the build. */
#define configMAX_TASK_NAME_LEN					( 8 )
#define configIDLE_SHOULD_YIELD					1
#define configCHECK_FOR_STACK_OVERFLOW			0
#define configGENERATE_RUN_TIME_STATS	1

/* Co-routine definitions. */
#define configUSE_CO_ROUTINES 					0
#define configMAX_CO_ROUTINE_PRIORITIES 		( 2 )

/* Set the following definitions to 1 to include the API function, or zero
to exclude the API function. */

#define INCLUDE_vTaskPrioritySet				0
#define INCLUDE_uxTaskPriorityGet				0
#define INCLUDE_vTaskDelete						0
#define INCLUDE_vTaskCleanUpResources			0
#define INCLUDE_vTaskSuspend					0
#define INCLUDE_vTaskDelayUntil					1
#define INCLUDE_vTaskDelay						0
#define INCLUDE_uxTaskGetStackHighWaterMark		0

	/* The following should not be included in asm files. */
	#ifdef __LANGUAGE_C__
	
		/* portCONFIGURE_TIMER_FOR_RUN_TIME_STATS() is defined to call the 
		function that sets up timer 2 (T2) as the time base for the run time 
		statistics.  T2 is a 16-bit timer and generates an interrupt when it
		overflows.
		
		portALT_GET_RUN_TIME_COUNTER_VALUE() is defined to set its parameter to
		the current run time stats counter/time value.  The returned timer value 
		is 32-bits long, and is formed by shifting the T2 overflow count into the 
		top two bytes of a 32-bit number, then bitwise ORing the result with the 
		current T2 count value. */
		void vSetupTimerForRunTimeStats( void );
		unsigned long ulGetRunTimeStatsCounterValue( void );
		#define portCONFIGURE_TIMER_FOR_RUN_TIME_STATS() vSetupTimerForRunTimeStats()
		
		/* T2 is 16-bits and generate an interrupt when it overflows.  The 
		number of overflows is stored in ulTMR2OverflowCount.  This	macro 
		combines the current 16-bit counter value with the number of overflows 
		to return a 32-bit timer value. */
		#define portALT_GET_RUN_TIME_COUNTER_VALUE( ulCountValue )				\
			{																	\
			extern volatile unsigned long ulTMR2OverflowCount;					\
																				\
				/* Disconnect the clock from the counter so it does not change  \
				while its value is being used. */								\
				T2CONCLR = T2_ON;												\
																				\
				/* The number of overflows is shifted into the most significant \
				two bytes of the returned 32-bit value. */						\
				ulCountValue = ( ulTMR2OverflowCount << 16UL );					\
																				\
				/* The current T2 counter value is used as the least 			\
				significant two bytes of the returned 32-bit value. */			\
				ulCountValue |= ( unsigned long ) ReadTimer2();					\
																				\
				/* Reconnect the clock to the counter. */						\
				T2CONSET = T2_ON;												\
			}

	#endif /* __LANGUAGE_C__ */

#endif /* FREERTOS_CONFIG_H */


