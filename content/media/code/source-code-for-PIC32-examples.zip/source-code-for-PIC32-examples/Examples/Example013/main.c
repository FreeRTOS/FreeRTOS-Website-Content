/*
    FreeRTOS V7.1.0 - Copyright (C) 2011 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public 
    License and the FreeRTOS license exception along with FreeRTOS; if not it 
    can be viewed here: http://www.freertos.org/a00114.html and also obtained 
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

/* MPLAB includes. */
#include <p32xxxx.h>
#include <plib.h>

/* FreeRTOS.org includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* Demo includes. */
#include "basic_io.h"

/* PIC32 configuration. */
#pragma config FPLLODIV = DIV_1, FPLLMUL = MUL_20, FPLLIDIV = DIV_2
#pragma config FWDTEN = OFF, FPBDIV = DIV_2, POSCMOD = XT, FNOSC = PRIPLL, CP = OFF
#pragma config FSRSSEL = PRIORITY_7

/* Software interrupt bit used within the CAUSE register to generate an 
interrupt. */
#define mainSW1_CAUSE_BIT            ( 0x01UL << 9 )

/* The software interrupt bit within the Interrupt Flag Status Register. */
#define mainSW1_INT_BIT                ( 0x04UL )

/* Macro to force a software interrupt. */
#define mainTRIGGER_INTERRUPT()                 \
{                                               \
unsigned long ulStatus;                         \
                                                \
    /* Trigger software interrupt. */           \
    ulStatus = _CP0_GET_CAUSE();                \
    ulStatus |= mainSW1_CAUSE_BIT;              \
    _CP0_SET_CAUSE( ulStatus );                 \
}

/* Macro to clear the same software interrupt. */
#define mainCLEAR_INTERRUPT()                   \
{                                               \
unsigned long ulStatus;                         \
                                                \
    /* Trigger software interrupt. */           \
    ulStatus = _CP0_GET_CAUSE();                \
    ulStatus &= ~mainSW1_CAUSE_BIT;             \
    _CP0_SET_CAUSE( ulStatus );                 \
}

/* The tasks to be created. */
static void vHandlerTask( void *pvParameters );
static void vPeriodicTask( void *pvParameters );

/* The service routine for the interrupt.  This is the interrupt that the 
task will be synchronized with.  The C compiler extensions are used to 
indicate that this is an interrupt entry point to use for the 
_CORE_SOFTWARE_1_VECTOR vector location.  The assembly wrapper for the 
interrupt (vSW1_ISR_Wrapper()) is defined in ISR_Wrapper.S, the C portion of
the handler (vSW1_ISR_Handler()) is defined in this file.  Note that, because
this interrupt is using the FreeRTOS assembly wrapper, the IPL value used in
the following line of code has no effect.  The interrupt priority is set by the
call to mConfigIntCoreSW1() in the vSetupEnvironment() function. */
void __attribute__( (interrupt(ipl1), vector(_CORE_SOFTWARE_1_VECTOR))) vSW1_ISR_Wrapper( void );

/* Basic hardware and debug interface configuration. */
void vSetupEnvironment( void );

/*-----------------------------------------------------------*/

/* Declare a variable of type xSemaphoreHandle.  This is used to reference the
semaphore that is used to synchronize a task with an interrupt. */
xSemaphoreHandle xCountingSemaphore;

/*-----------------------------------------------------------*/

int main( void )
{
	/* Configure both the hardware and the debug interface. */
	vSetupEnvironment();

    /* Before a semaphore is used it must be explicitly created.  In this example
	a counting semaphore is created.  The semaphore is created to have a maximum
	count value of 10, and an initial count value of 0. */
    xCountingSemaphore = xSemaphoreCreateCounting( 10, 0 );

	/* Check the semaphore was created successfully. */
	if( xCountingSemaphore != NULL )
	{
		/* Create the 'handler' task.  This is the task that will be synchronized
		with the interrupt.  The handler task is created with a high priority to
		ensure it runs immediately after the interrupt exits.  In this case a 
		priority of 3 is chosen. */
		xTaskCreate( vHandlerTask, ( signed char * ) "Handler", 240, NULL, 3, NULL );

		/* Create the task that will periodically generate a software interrupt. 
		This is created with a priority below the handler task to ensure it will
		get preempted each time the handler task exist the Blocked state. */
		xTaskCreate( vPeriodicTask, ( signed char * ) "Periodic", 240, NULL, 1, NULL );

		/* Start the scheduler so the created tasks start executing. */
		vTaskStartScheduler();
	}
		
    /* If all is well we will never reach here as the scheduler will now be
    running the tasks.  If we do reach here then it is likely that there was 
    insufficient heap memory available for a resource to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

static void vHandlerTask( void *pvParameters )
{
	/* As per most tasks, this task is implemented within an infinite loop. */
	for( ;; )
	{
		/* Use the semaphore to wait for the event.  The semaphore was created
		before the scheduler was started so before this task ran for the first
		time.  The task blocks indefinitely meaning this function call will only
		return once the semaphore has been successfully obtained - so there is no
		need to check the returned value. */
		xSemaphoreTake( xCountingSemaphore, portMAX_DELAY );

		/* To get here the event must have occurred.  Process the event (in this
		case we just print out a message). */
		vPrintString( "Handler task - Processing event.\n" );
	}
}
/*-----------------------------------------------------------*/

static void vPeriodicTask( void *pvParameters )
{
	/* As per most tasks, this task is implemented within an infinite loop. */
	for( ;; )
	{
		/* This task is just used to 'simulate' an interrupt.  This is done by
		periodically generating a software interrupt. */
		vTaskDelay( 500 / portTICK_RATE_MS );

		/* Generate the interrupt, printing a message both before hand and 
		afterwards so the sequence of execution is evident from the output. */
        vPrintString( "Periodic task - About to generate an interrupt.\n" );
        mainTRIGGER_INTERRUPT(); 
		vPrintString( "Periodic task - Interrupt generated.\n\n" );
	}
}
/*-----------------------------------------------------------*/

void vSW1_ISR_Handler( void )
{
portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	/* 'Give' the semaphore multiple times.  The first will unblock the handler
	task, the following 'gives' are to demonstrate that the semaphore latches
	the events to allow the handler task to process them in turn without any 
	events getting lost.  This simulates multiple interrupts being taken by the
	processor, even though in this case the events are simulated within a single
	interrupt occurrence.*/
	xSemaphoreGiveFromISR( xCountingSemaphore, &xHigherPriorityTaskWoken );
	xSemaphoreGiveFromISR( xCountingSemaphore, &xHigherPriorityTaskWoken );
	xSemaphoreGiveFromISR( xCountingSemaphore, &xHigherPriorityTaskWoken );

    /* Clear the software interrupt flag. */
    mainCLEAR_INTERRUPT();

    /* Then clear the interrupt in the interrupt controller. */
    IFS0CLR = mainSW1_INT_BIT;

    /* Giving the semaphore may have unblocked a task - if it did and the 
    unblocked task has a priority equal to or above the currently executing 
    task then xHigherPriorityTaskWoken will have been set to pdTRUE and
    portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
    higher priority task.
    
    NOTE: The syntax for forcing a context switch within an ISR varies between 
    FreeRTOS ports.  The portEND_SWITCHING_ISR() macro is provided as part of
    the PIC32 port layer for this purpose.  taskYIELD() must never be called 
    from an ISR! */
    portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

void vSetupEnvironment( void )
{
	/* Setup the main clock for maximum performance, and the peripheral clock
	to equal the main clock divided by 2. */
	SYSTEMConfigPerformance( configCPU_CLOCK_HZ );
	mOSCSetPBDIV( OSC_PB_DIV_2 );
    
    /* Setup the software interrupt used by mainTRIGGER_INTERRUPT(). */
    mConfigIntCoreSW1( CSW_INT_ON | CSW_INT_PRIOR_1 | CSW_INT_SUB_PRIOR_0 );
	
	/* Enable global interrupt handling. */
	INTEnableSystemMultiVectoredInt();

	/* Initialise the debug utils library to enable strings printed from the
	demo source code to be displayed in the MPLAB IDE. */
	DBINIT();

	/* Set the console output to line buffered mode. */
	vSetIOBuffering();
}
/*-----------------------------------------------------------*/







